// Class declaration for NumberListDouble class
