// Implementation of NumberListSingle class
