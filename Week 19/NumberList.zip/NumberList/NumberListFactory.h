// Factory function declaration for INumberList inherited classes

// Important note: don't include unnecessary header files here - we want to keep this file independent of the implemented types

// Use this enum to select the class to create
enum NumberListType
{
	Single,
	Double,
};

// Function signature here: