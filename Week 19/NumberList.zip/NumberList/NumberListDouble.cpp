// Implementation of NumberListDouble class
