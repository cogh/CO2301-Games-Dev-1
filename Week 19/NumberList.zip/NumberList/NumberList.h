// Class declaration for INumberList interface
