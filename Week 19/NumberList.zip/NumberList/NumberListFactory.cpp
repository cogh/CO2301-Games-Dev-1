// Factory function implementation for INumberList inherited classes
