// Helpers.cpp - various functions to help integrate TL-Engine with Bullet

#include "Helpers.h"


//**********************************************************
// TLMotionState class for transfering position/rotation 
// between TL-Engine models and Bullet physics bodies

// Array of floats for transferring matrices from Bullet <-> TL-Engine
// Bullet doesn't use the final 16th element (it is always 1), so set it here
float matrix[16] = { 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 1 };


// Constructor links to the TL-Engine model
TLMotionState::TLMotionState( IModel* model ) 
{
  m_Model = model;

  // Assume any scaling is already set and won't be changed again - see note in header file
  m_Model->GetMatrix(matrix);
  m_Scale = btVector3(sqrt(matrix[0]*matrix[0] + matrix[1]*matrix[1] + matrix[2] *matrix[2]),
                      sqrt(matrix[4]*matrix[4] + matrix[5]*matrix[5] + matrix[6] *matrix[6]),
	                    sqrt(matrix[8]*matrix[8] + matrix[9]*matrix[9] + matrix[10]*matrix[10]));

  // Get the centre of the model, which might be different than its origin. Set as a transform
  // so we can offset the origin for Bullet. See note in header file.
  m_CentreOffset.setIdentity();
  m_CentreOffset.setOrigin(GetModelCentre(model) * m_Scale);
}


// Get the TL-Engine's model position and set it in the given Bullet transform variable (i.e. send TL model position to Bullet)
void TLMotionState::getWorldTransform(btTransform& transform) const
{
	// Get matrix from TL-Engine, remove scaling, apply centre offset and send to Bullet (see notes in header file)
	m_Model->GetMatrix(matrix);
  transform.setFromOpenGLMatrix(matrix);
  transform.getBasis()[0] /= m_Scale.x();
  transform.getBasis()[1] /= m_Scale.y();
  transform.getBasis()[2] /= m_Scale.z();
  transform = transform * m_CentreOffset;
}


// Set the TL-Engine's model position from the given Bullet transform variable (i.e. get the TL model position from Bullet)
void TLMotionState::setWorldTransform(const btTransform& transform)
{
	// Get transform from Bullet, add scaling, remove centre offset and set TL-Engine matrix (see notes in header file)
  btTransform offsetTransform = transform * m_CentreOffset.inverse();
  offsetTransform.getBasis()[0] *= m_Scale.x();
  offsetTransform.getBasis()[1] *= m_Scale.y();
  offsetTransform.getBasis()[2] *= m_Scale.z();
  offsetTransform.getOpenGLMatrix(matrix);
  m_Model->SetMatrix(matrix); 
}



//********************************************************************
// Functions to prepare convex hull shapes for Bullet

// Complex shaped models can be handled in the physics engine as a "convex hull". We need to create these
// convex hulls using the vertices in the mesh. This function takes a model and creates a Bullet convex 
// hull to match its mesh. All we need to do is pass all the model vertices to Bullet, it will take care
// of calculating the surrounding convex hull
//
// Bullet bodies do not support scaling, so apply any model scaling to the vertices now. This assumes
// models are already scaled and will not be rescaled. Also offset the origin so it is at the centre of
// the model rather than at the artwork origin. See the notes in the header on TLMotionState about this
btConvexHullShape* MakeConvexHullFromModel( IModel* model )
{
  btVector3 centre = GetModelCentre(model);

  // Start with an empty convex hull shape
  btConvexHullShape* shape = new btConvexHullShape();

	// Can get a model's scaling from its (world) matrix: the lengths of the local x, y & z axes are the x, y & z scalings
	model->GetMatrix(matrix);
	btVector3 scale(sqrt(matrix[0]*matrix[0] + matrix[1]*matrix[1] + matrix[2] *matrix[2]),
	                sqrt(matrix[4]*matrix[4] + matrix[5]*matrix[5] + matrix[6] *matrix[6]),
	                sqrt(matrix[8]*matrix[8] + matrix[9]*matrix[9] + matrix[10]*matrix[10]));

	// Extract list of vertices contained in the model's mesh
	IMesh* mesh = model->GetMesh();
	mesh->BeginEnumVertices();
	btVector3 vertex;
	while (mesh->GetVertex(vertex))
	{
    // Offset so origin is at centre of model
    vertex -= centre;

		// Apply model scaling to the mesh vertices because Bullet does not support body scaling
		vertex *= scale;

    // Add each point to the convex hull
    shape->addPoint(vertex);
	}
	mesh->EndEnumVertices();

	// Finally return the convex hull shape
	return shape;
}


// Calculate the centre of a model. Ideally this would be the centre of mass, but for simplicity this is just
// the centre of the box surrounding the model. Bullet needs models to have their origin at the centre of mass
// However, models often have their origin in places convenient for gameplay or artwork. So this function is
// used so we can offset the positions used in Bullet
btVector3 GetModelCentre( IModel* model )
{
	btVector3 aabbMin, aabbMax, vertex, centre;

  // Get vertices from TL-Engine
	IMesh* mesh = model->GetMesh();
	mesh->BeginEnumVertices();
  if (!mesh->GetVertex(vertex))
  {
    // No vertices - not sure if this can even happen in a TL-Engine model, but better safe than sorry...
    centre = btVector3(0,0,0);
  }
  else
  {
    // Iterate through vertices, keeping track of the maximum and minimum coordinates
    aabbMin = aabbMax = vertex;
	  while (mesh->GetVertex(vertex))
	  {
      aabbMin.setMin(vertex);
      aabbMax.setMax(vertex);
	  }
    // Max and min coordinates are the corners of the axis-aligned bounding box (aabb). Average these to get centre
    centre = (aabbMin + aabbMax) / 2;
  }
  mesh->EndEnumVertices();

  return centre;
}


//*******************************************************************************
// Functions to get local axes from a model as a Bullet vector (normalised)

// Set the given Bullet vector to the local X direction of a model
void GetLocalXDir( IModel* model, btVector3& vector )
{
	model->GetMatrix(matrix);
	float scaleX = sqrt(matrix[0]*matrix[0] + matrix[1]*matrix[1] + matrix[2]*matrix[2]);
	vector.setX(matrix[0] / scaleX);
	vector.setY(matrix[1] / scaleX);
	vector.setZ(matrix[2] / scaleX);
}

// Set the given Bullet vector to the local Y direction of a model
void GetLocalYDir( IModel* model, btVector3& vector )
{
	model->GetMatrix(matrix);
	float scaleY = sqrt(matrix[4]*matrix[4] + matrix[5]*matrix[5] + matrix[6]*matrix[6]);
	vector.setX(matrix[4] / scaleY);
	vector.setY(matrix[5] / scaleY);
	vector.setZ(matrix[6] / scaleY);
}

// Set the given Bullet vector to the local Z direction of a model
void GetLocalZDir( IModel* model, btVector3& vector )
{
	model->GetMatrix(matrix);
	float scaleZ = sqrt(matrix[8]*matrix[8] + matrix[9]*matrix[9] + matrix[10]*matrix[10]);
	vector.setX(matrix[8]  / scaleZ);
	vector.setY(matrix[9]  / scaleZ);
	vector.setZ(matrix[10] / scaleZ);
}


//***************************************
// Miscellaneous

// Return random float from a to b (inclusive)
float Random( float a, float b )
{
	return a + (b - a) * (static_cast<float>(rand()) / RAND_MAX);
}

