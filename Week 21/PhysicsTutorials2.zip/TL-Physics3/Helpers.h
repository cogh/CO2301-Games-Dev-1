#ifndef _TL_PHYSICS3_HELPERS_H_
#define _TL_PHYSICS3_HELPERS_H_

#include <TL-Engine.h>	// TL-Engine include file and namespace
using namespace tle;

#include "btBulletDynamicsCommon.h"  // Bullet include file


//**********************************************************
// TLMotionState class for transfering position/rotation 
// between TL-Engine models and Bullet physics bodies

// Class inherited from Bullet motion state class that manages the copying of position and
// rotation (transform) between Bullet physics world and TL-Engine model locations
//
// This version of the class handles TL-Engine models that are scaled and whose origins are
// not at the centre of gravity. These extra details make this class the best one to use for
// your own physics projects:
//
// - Bullet doesn't support scaling of rigid bodies (most physics engines don't), so scaling
//   is applied to the collision shapes used and this class ensures scaling is removed from
//   any matrices sent to Bullet (without losing the scaling in TL-Engine). Note that this
//   assumes that models are scaled once immediately after loading and not scaled again. To
//   support physics on dynamically scaling objects, the collision shape used would need to
//   be continuously updated - no support for that in this project
//
// - Objects will freely rotate around their centre of gravity, which Bullet assumes is at the
//   origin of the model. However, the origin of the model is more often in a location useful
//   the game (e.g. on the floor below a character). So this class calculates the centre of
//   a model when constructed (using GetModelCentre) and offsets all positions sent to Bullet.
//   That allows Bullet and TL-Engine to have separate origins for the model. Note that the
//   collision shape used should have it's origin at the model centre too (so the function
//   below, MakeConvexHullFromModel, also uses the same offset)
// 
ATTRIBUTE_ALIGNED16(class) TLMotionState : public btMotionState
{
private: 
  IModel*     m_Model;
  btVector3   m_Scale;
  btTransform m_CentreOffset;

public:
  BT_DECLARE_ALIGNED_ALLOCATOR();
  
  // Constructor links to the TL-Engine model
  TLMotionState( IModel* model );

  // Get the TL-Engine's model position and set it in the given Bullet transform variable (i.e. send TL model position to Bullet)
  void getWorldTransform(btTransform& transform) const;

  // Set the TL-Engine's model position from the given Bullet transform variable (i.e. get the TL model position from Bullet)
  void setWorldTransform(const btTransform& transform);
};



//********************************************************************
// Functions to prepare convex hull shapes for Bullet

// Get the centre of a TL-Engine model (not necessarily the origin)
btVector3 GetModelCentre( IModel* model );

// Create a Bullet convex hull collision shape given a TL-Engine model. The origin of the 
// convex hull will be at the model centre not the artwork origin
btConvexHullShape* MakeConvexHullFromModel( IModel* model );


//*******************************************************************************
// Functions to get local axes from a model as a Bullet vector (normalised)

void GetLocalXDir( IModel* model, btVector3& vector );
void GetLocalYDir( IModel* model, btVector3& vector );
void GetLocalZDir( IModel* model, btVector3& vector );


//***************************************
// Miscellaneous

// Return random float from a to b (inclusive)
float Random( float a, float b );


#endif
