// spline1.cpp: A program using the TL-Engine

#include <TL-Engine.h>	// TL-Engine include file and namespace
using namespace tle;

const float kCameraMove = 0.10f; // distance for the direction keys x and z axis
const float kMouseWheelMove = 10.0f; // distance for wheel movement z axis
const float kMouseRotation = 0.3f; // distance (in degrees) for rotation of the camera

const float kScale = 0.005f;
const float kMove = 0.004f;

struct point
{
	float x;
	float y;
	IModel* model;
};

//Ignore the
void quarterSplines( point point1, point point2, point point3, point point4,
					point &quarter, point &half, point &threeQuarter )
{
	// calculate a quarter of the way along the set of points
	quarter.x = point1.x * -0.0703125f + point2.x * 0.8671875f +
			    point3.x * 0.2265625f + point4.x * -0.0234375f;
	quarter.y = point1.y * -0.0703125f + point2.y * 0.8671875f +
			    point3.y * 0.2265625f + point4.y * -0.0234375f;

	// calculate a half of the way along the set of points
	half.x = point1.x * -0.0625f + point2.x * 0.5625f +
			 point3.x * 0.5625f + point4.x * -0.0625f ;
	half.y = point1.y * -0.0625f + point2.y * 0.5625f +
			 point3.y * 0.5625f + point4.y * -0.0625f ;

	// calculate three-quarters of the way along the set of points
	threeQuarter.x = point1.x * -0.0234375f + point2.x * 0.2265625f + 
					 point3.x * 0.8671875f + point4.x * -0.0703125f;
	threeQuarter.y = point1.y * -0.0234375f + point2.y * 0.2265625f + 
					 point3.y * 0.8671875f + point4.y * -0.0703125f;
}

void InitialiseSpheres( point points[4], point path1[3], point path2[3], point path3[3], IMesh* sphereMesh )
{
	points[0].x = 0.5;
	points[0].y = 0.5;
	points[0].model = sphereMesh->CreateModel( points[0].x, points[0].y, 0 );;	
	points[0].model->Scale( kScale );

	points[1].x = 1.5;
	points[1].y = 1.5;
	points[1].model = sphereMesh->CreateModel( points[1].x, points[1].y, 0 );;	
	points[1].model->Scale( kScale );

	points[2].x = 2.5;
	points[2].y = 1.5;
	points[2].model = sphereMesh->CreateModel( points[2].x, points[2].y, 0 );;	
	points[2].model->Scale( kScale );

	points[3].x = 3.5;
	points[3].y = 0.5;
	points[3].model = sphereMesh->CreateModel( points[3].x, points[3].y, 0 );;	
	points[3].model->Scale( kScale );

	quarterSplines( points[0], points[0], points[1], points[2],
					path1[0], path1[1], path1[2] );

	path1[0].model = sphereMesh->CreateModel( path1[0].x, path1[0].y, 0 );;	
	path1[0].model->Scale( kScale );
	path1[0].model->SetSkin( "RedBall.jpg" );

	path1[1].model = sphereMesh->CreateModel( path1[1].x, path1[1].y, 0 );;	
	path1[1].model->Scale( kScale );
	path1[1].model->SetSkin( "RedBall.jpg" );

	path1[2].model = sphereMesh->CreateModel( path1[2].x, path1[2].y, 0 );;	
	path1[2].model->Scale( kScale );
	path1[2].model->SetSkin( "RedBall.jpg" );


	quarterSplines( points[0], points[1], points[2], points[3],
					path2[0], path2[1], path2[2] );

	path2[0].model = sphereMesh->CreateModel( path2[0].x, path2[0].y, 0 );;	
	path2[0].model->Scale( kScale );
	path2[0].model->SetSkin( "RedBall.jpg" );

	path2[1].model = sphereMesh->CreateModel( path2[1].x, path2[1].y, 0 );;	
	path2[1].model->Scale( kScale );
	path2[1].model->SetSkin( "RedBall.jpg" );

	path2[2].model = sphereMesh->CreateModel( path2[2].x, path2[2].y, 0 );;	
	path2[2].model->Scale( kScale );
	path2[2].model->SetSkin( "RedBall.jpg" );


	quarterSplines( points[1], points[2], points[3], points[3],
					path3[0], path3[1], path3[2] );

	path3[0].model = sphereMesh->CreateModel( path3[0].x, path3[0].y, 0 );;	
	path3[0].model->Scale( kScale );
	path3[0].model->SetSkin( "RedBall.jpg" );

	path3[1].model = sphereMesh->CreateModel( path3[1].x, path3[1].y, 0 );;	
	path3[1].model->Scale( kScale );
	path3[1].model->SetSkin( "RedBall.jpg" );

	path3[2].model = sphereMesh->CreateModel( path3[2].x, path3[2].y, 0 );;	
	path3[2].model->Scale( kScale );
	path3[2].model->SetSkin( "RedBall.jpg" );
}

void main()
{
	// Create a 3D engine (using Irrlicht engine here) and open a window for it
	I3DEngine* myEngine = New3DEngine( kIrrlicht );
	myEngine->StartWindowed();

	// Add default folder for meshes and other media
	myEngine->AddMediaFolder( "D:\\_USER-DATA\\Games-User\\Documents\\TL-Engine\\Media" );

	IMesh* sphereMesh = myEngine->LoadMesh( "sphere.x");
	point points[4];
	point path1[3];
	point path2[3];
	point path3[3];

	InitialiseSpheres( points, path1, path2, path3,sphereMesh );
	/**** Set up your scene here ****/

	ICamera* camera = myEngine->CreateCamera( kManual, 2, 1, -5 );

	// mouse capture
	myEngine->StartMouseCapture( );
	bool mouseCaptureActive = false; // state of mouse capture

	// The main game loop, repeat until engine is stopped
	while (myEngine->IsRunning())
	{
		// Draw the scene
		myEngine->DrawScene();

		/**** Update your scene each frame here ****/

		// MISSING SECTION 1
		// COMPLETE THE PROGRAM: KEY SETUP
		// Set up keys to move the known points
		// in other words: p1, p2, p3 and p3
		

		// MISSING SECTION 2
		// CALCULATE THE QUARTER POINTS
		// Derive the quarter points in between the main points


		/* --- other keyboard input --- */
		if( myEngine->KeyHit( Key_Escape ) )
		{
			myEngine->Stop();
		}

		/* ---- camera movement ---- */
		if( myEngine->KeyHeld( Key_Up ) )
		{
			camera->MoveLocalZ( kCameraMove );
		}
		if( myEngine->KeyHeld( Key_Down ) )
		{
			camera->MoveLocalZ( -kCameraMove );
		}
		if( myEngine->KeyHeld( Key_Right ) )
		{
			camera->MoveLocalX( kCameraMove );
		}
		if( myEngine->KeyHeld( Key_Left ) )
		{
			camera->MoveLocalX( -kCameraMove );
		}

		if( mouseCaptureActive )
		{
			int mouseMoveX = myEngine->GetMouseMovementX();
			camera->RotateY( mouseMoveX * kMouseRotation ); // the MouseRotation reduces the rotation speed

			int mouseMoveY = myEngine->GetMouseMovementY();
			camera->RotateX( mouseMoveY * kMouseRotation ); // the MouseRotation reduces the rotation speed

			float mouseMoveWheel = myEngine->GetMouseWheelMovement();
			camera->MoveLocalZ( mouseMoveWheel * kMouseWheelMove ); // the MouseRotation reduces the rotation speed
		}

		// toggle mouse capture
		if( myEngine->KeyHit( Key_Tab ) )
		{
			if( mouseCaptureActive )
			{
				myEngine->StopMouseCapture( );
				mouseCaptureActive = false;
			}
			else
			{
				myEngine->StartMouseCapture( );
				mouseCaptureActive = true;
			}
		}
	}


	// Delete the 3D engine now we are finished with it
	myEngine->Delete();
}
