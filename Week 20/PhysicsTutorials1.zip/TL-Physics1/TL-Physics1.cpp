// TL-Physics1.cpp: A program using the TL-Engine

#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

#include <TL-Engine.h>  // TL-Engine include file and namespace
using namespace tle;

#include "btBulletDynamicsCommon.h"  // Bullet include file


/*-----------------------------------------------------------------------------------------
  Constants
-----------------------------------------------------------------------------------------*/

// All measurements are in metres, seconds and kilograms

// Maximum update rate (tick) for physics calls
const float physicsTick = 1.0f / 60.0f;   // = 60 fps

// Acceleration vector due to gravity - standard value is -9.8 downwards, but switched off gravity for now (using Bullet btVector3 type)
const btVector3 gravity( 0.0f, 0.0f, 0.0f ); 

// Speed of camera movement / rotation
const float cameraMoveSpeed = 20.0f; // Using game loop timing, so this is in metres / second
const float cameraRotSpeed  =  0.3f; // How many pixels of mouse movement make 1 degree of rotation 
const float cameraRotSmooth = 30.0f; // Smoothing level for mouse movement, increasing the value decreases the amount of smoothing

const float MONITOR_REFRESH_RATE = 60.0f;  // In Hertz


/*-----------------------------------------------------------------------------------------
  Global variables
-----------------------------------------------------------------------------------------*/

//**** TL-Engine ****
I3DEngine* myEngine;

// Models
IMesh*   cubeMesh;
IModel*  cube;
ICamera* camera;
IFont*   uiFont;


//**** Bullet ****

// Physics engine subsystems created during initialisation
btDefaultCollisionConfiguration* CollisionConfiguration;
btCollisionDispatcher* Dispatcher;
btBroadphaseInterface* OverlappingPairCache;
btSequentialImpulseConstraintSolver* Solver;

// The physics world itself - we add bodies to this
btDiscreteDynamicsWorld* PhysicsWorld;

// The physics world maintains a list of physics bodies but not the collision shapes used.
// So we will keep our own list of collision shapes to make uninitialisation simpler
btAlignedObjectArray<btCollisionShape*> CollisionShapes;

// Bullet rigid bodies - the physics engine's view of the TL-Engine models
btRigidBody* cubeRigidBody;

// Array of floats for transferring matrices from Bullet <-> TL-Engine
// Bullet doesn't use the final 16th element (it is always 1), so add it now
float matrix[16] = { 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 1 };


/*-----------------------------------------------------------------------------------------
  Function prototypes
-----------------------------------------------------------------------------------------*/

// Overall program control
bool ProgramSetup();
void ProgramShutdown();

// Scene management
bool SceneSetup();
void SceneShutdown();
void SceneUpdate( float updateTime );

// Physics management
bool PhysicsSetup();
void PhysicsShutdown();
void PhysicsUpdate( float updateTime );


/*-----------------------------------------------------------------------------------------
  Main function
-----------------------------------------------------------------------------------------*/

void main()
{
  // Initialise program (TL-Engine etc.), quit program on failure
  if (!ProgramSetup())
  {
    return;
  }

  // Set up the scene, quit program on failure (remember to shutdown the program)
  if (!SceneSetup())
  {
    ProgramShutdown();
    return;
  }

  // Initialise and set up the physics, quit program on failure (remember to shutdown the scene and program)
  if (!PhysicsSetup())
  {
    SceneShutdown();
    ProgramShutdown();
    return;
  }

  // Reset timer before timing frames
  myEngine->Timer(); // Reset timer before timing frames

  // The main game loop, repeat until engine is stopped (window closed or escape pressed)
  while (myEngine->IsRunning() && !myEngine->KeyHit( Key_Escape ))
  {
    // Draw the scene
    myEngine->DrawScene();

    // Game loop timing. Wait for next monitor refresh (roughly) - approximation to vertical synchronisation
    float frameTime = myEngine->Timer();
    while (frameTime < 1 / MONITOR_REFRESH_RATE) frameTime += myEngine->Timer();

    // Update the physics, then the scene - pass time since last frame (variable timing)
    SceneUpdate( frameTime );
    PhysicsUpdate( frameTime );
  }

  // Shutdown the physics, scene and program before exiting
  PhysicsShutdown();
  SceneShutdown();
  ProgramShutdown();
}


/*-----------------------------------------------------------------------------------------
  Overall program control
-----------------------------------------------------------------------------------------*/

// One off setup for the entire program
bool ProgramSetup()
{
  // Create a 3D engine and open a window for it
  myEngine = New3DEngine( kTLX );
  if (!myEngine)
  {
    return false;
  }
  myEngine->StartWindowed(1280, 800);
  myEngine->StartMouseCapture();

  // Add default folders for meshes and other media
  myEngine->AddMediaFolder( "C:\\ProgramData\\TL-Engine\\Media" );

  return true;
}

// Final shutdown for the entire program
void ProgramShutdown()
{
  // Release the TL-Engine
  myEngine->Delete();
}


/*-----------------------------------------------------------------------------------------
  Scene Management
-----------------------------------------------------------------------------------------*/

// Initialise the scene (meshes, models, cameras etc)
bool SceneSetup()
{
  // Load resources: meshes & fonts
  cubeMesh = myEngine->LoadMesh( "Cube.x" );
  uiFont = myEngine->LoadFont( "Arial" );
  if (!cubeMesh || !uiFont)
  {
    return false;
  }

  // Create models
  cube = cubeMesh->CreateModel( 0, 6, 0 );

  // Create a camera
  camera = myEngine->CreateCamera( kManual, 0, 4, -12 );

  return true;
}

// Uninitialise scene resources
void SceneShutdown()
{
  // Remove font, camera and meshes (and hence their models)
  myEngine->RemoveFont( uiFont );
  myEngine->RemoveCamera( camera );
  myEngine->RemoveMesh( cubeMesh );
}

// Update the scene elements - pass the amount of time to update
void SceneUpdate( float updateTime )
{
  // Write out frame time
  stringstream outText;
  outText << "FPS: " << fixed << setprecision(1) << (1.0f / updateTime);
  uiFont->Draw( outText.str(), 0, 0 );

  // Move camera (variable timing)
  if (myEngine->KeyHeld(Key_Left) || myEngine->KeyHeld(Key_A))
  {
    camera->MoveLocalX( -cameraMoveSpeed * updateTime );
  }
  if (myEngine->KeyHeld(Key_Right) || myEngine->KeyHeld(Key_D))
  {
    camera->MoveLocalX( cameraMoveSpeed * updateTime );
  }
  if (myEngine->KeyHeld(Key_Up) || myEngine->KeyHeld(Key_W))
  {
    camera->MoveLocalZ( cameraMoveSpeed * updateTime );
  }
  if (myEngine->KeyHeld(Key_Down) || myEngine->KeyHeld(Key_S))
  {
    camera->MoveLocalZ( -cameraMoveSpeed * updateTime );
  }

  // Rotate camera with smoothing
  static float cameraRotX = 0.0f;
  static float cameraRotY = 0.0f;
  cameraRotX += myEngine->GetMouseMovementY() * cameraRotSpeed;
  cameraRotY += myEngine->GetMouseMovementX() * cameraRotSpeed;
  float smooth = 1.0f - pow( 0.5f, updateTime * cameraRotSmooth );
  camera->RotateLocalX( cameraRotX * smooth );
  camera->RotateY( cameraRotY * smooth );
  cameraRotX -= cameraRotX * smooth;
  cameraRotY -= cameraRotY * smooth;

  // Nothing else to do - model movement handled by physics engine
}


/*-----------------------------------------------------------------------------------------
  Physics Management
-----------------------------------------------------------------------------------------*/

// Initialise the physics engine, the physics world and the bodies in it
bool PhysicsSetup()
{
  // Initialise Bullet subsystems. These lines can be left the same for simple purposes
  CollisionConfiguration = new btDefaultCollisionConfiguration();
  Dispatcher =             new btCollisionDispatcher(CollisionConfiguration);
  OverlappingPairCache =   new btDbvtBroadphase();
  Solver =                 new btSequentialImpulseConstraintSolver;

  // Create the physics world from the components above
  PhysicsWorld = new btDiscreteDynamicsWorld( Dispatcher, OverlappingPairCache, Solver, CollisionConfiguration );

  // Specify gravity in the world
  PhysicsWorld->setGravity(gravity);


  //***************************************
  // Create physics bodies to match models
  
  btScalar mass;
  btVector3 inertialTensor;
  btDefaultMotionState* motionState;

  //////////
  // Cube

  // Create a box shape for the cube (must be centered on the origin). The cube is 2 x 2 x 2, but Bullet requires
  // half-sizes (the "radius" of the cube). Note that this doesn't actually create a physics body yet
  btCollisionShape* cubeShape = new btBoxShape(btVector3(1,1,1));
  CollisionShapes.push_back(cubeShape); // Add to list of shapes for easy deletion later

  // Set the initial position of the cube from the TL-Engine initial position
  btTransform cubeTransform;
  cubeTransform.setIdentity();
  cubeTransform.setOrigin(btVector3(cube->GetX(), cube->GetY(), cube->GetZ()));
  motionState = new btDefaultMotionState(cubeTransform);

  // Set the cube's physical properties
  mass = 1;  // When we give a body some mass it becomes dynamic - it can move and collide
  cubeShape->calculateLocalInertia( mass, inertialTensor ); // With non-zero mass the intertial tensor is needed (the distribution of mass around the centre of gravity)

  // Create the physics body and add to the world
  cubeRigidBody = new btRigidBody(btRigidBody::btRigidBodyConstructionInfo( mass, motionState, cubeShape, inertialTensor ));
  PhysicsWorld->addRigidBody(cubeRigidBody);

  cubeRigidBody->setAngularVelocity(btVector3(0,5,0));  // Give the cube physics body some angular velocity
  cubeRigidBody->setDamping( 0, 0.3f );                 // Always slow down the angular velocity, but don't affect linear velocity
  cubeRigidBody->setSleepingThresholds( 0.4f, 0.2f );   // If the body movement becomes very slow the engine "deactivates" it for perfomance - but it deactivates too easily without this line

  return true;
}


// Uninitialise the Bullet physics engine
void PhysicsShutdown()
{
  //****
  // This code is generic so there is no need to change it even if you change the collision shapes or bodies used

  // Remove all rigid bodies from the physics world and delete them
  for (int i = PhysicsWorld->getNumCollisionObjects()-1; i >= 0; i--)
  {
    btCollisionObject* obj = PhysicsWorld->getCollisionObjectArray()[i];
    btRigidBody* body = btRigidBody::upcast(obj);
    if (body && body->getMotionState())
    {
      delete body->getMotionState();
    }
    PhysicsWorld->removeCollisionObject( obj );
    delete obj;
  }

  // Delete collision shapes
  for (int i = 0; i < CollisionShapes.size(); i++)
  {
    btCollisionShape* shape = CollisionShapes[i];
    CollisionShapes[i] = nullptr;
    delete shape;
  }

  // Delete physics world
  delete PhysicsWorld;

  // Delete physics engine subsystems
  delete Solver;
  delete OverlappingPairCache;
  delete Dispatcher;
  delete CollisionConfiguration;
}


// Update the physics world by the given amount of time (using variable timing)
void PhysicsUpdate( float updateTime )
{
  PhysicsWorld->stepSimulation( updateTime, 10 );

  // Get the matrix from the physics cube body and set it in the TL-Engine for the cube model, so the model follows the physics simulation
  cubeRigidBody->getWorldTransform().getOpenGLMatrix(matrix);
  cube->SetMatrix(matrix); 
} 
