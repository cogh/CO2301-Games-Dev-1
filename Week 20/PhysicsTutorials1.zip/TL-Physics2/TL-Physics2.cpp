// TL-Physics2.cpp: A program using the TL-Engine

#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

#include <TL-Engine.h>	// TL-Engine include file and namespace
using namespace tle;

#include "btBulletDynamicsCommon.h"  // Bullet include file


/*-----------------------------------------------------------------------------------------
	Constants
-----------------------------------------------------------------------------------------*/

// All measurements are in metres, seconds and kilograms

// Fixed update rate (tick) for physics calls
const float physicsTick = 1.0f / 60.0f;   // = 60 fps

// Maximum physics ticks per frame - prevent physics from using too much CPU time
const int maxPhysicsTicks = 2;

// Acceleration vector due to gravity - standard value downwards here
const btVector3 gravity( 0.0f, -9.8f, 0.0f ); 

// Cube size and cube array size
const float cubeSize = 2.0f;
const int numCubesX  = 10;
const int numCubesY  = 3;

// Speed of camera movement / rotation
const float cameraMoveSpeed = 20.0f; // Using game loop timing, so this is in metres / second
const float cameraRotSpeed  =  0.3f; // How many pixels of mouse movement make 1 degree of rotation 
const float cameraRotSmooth = 30.0f; // Smoothing level for mouse movement, increasing the value decreases the amount of smoothing


/*-----------------------------------------------------------------------------------------
	Global variables
-----------------------------------------------------------------------------------------*/

//**** TL-Engine ****
I3DEngine* myEngine;

// Scene resources
IMesh* skyboxMesh;
IMesh* groundMesh;
IMesh* cubeMesh;
IModel* skybox;
IModel* ground;
IModel* cubes[numCubesX * numCubesY];
ILight* light;
ICamera* camera;
IFont* uiFont;


//**** Bullet ****

// Bullet rigid bodies - the physics engine's view of the TL-Engine models
btRigidBody* cubeRigidBodies[numCubesX * numCubesY];
btRigidBody* groundRigidBody; 

// Physics engine subsystems created during initialisation
btDefaultCollisionConfiguration* CollisionConfiguration;
btCollisionDispatcher* Dispatcher;
btBroadphaseInterface* OverlappingPairCache;
btSequentialImpulseConstraintSolver* Solver;

// The physics world itself - we add bodies to this
btDiscreteDynamicsWorld* PhysicsWorld;

// The physics world maintains a list of physics bodies but not the collision shapes used.
// So we will keep our own list of collision shapes to make uninitialisation simpler
btAlignedObjectArray<btCollisionShape*> CollisionShapes;



/*-----------------------------------------------------------------------------------------
  TLMotionState class - for copying position between TL-Engine and Bullet
-----------------------------------------------------------------------------------------*/

// Array of floats for transferring matrices from Bullet <-> TL-Engine
// Bullet doesn't use the final 16th element (it is always 1), so add it now
float matrix[16] = { 0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 0,   0, 0, 0, 1 };


// Class inherited from Bullet motion state class that manages the copying of position and
// rotation (transform) between Bullet physics world and TL-Engine model locations
ATTRIBUTE_ALIGNED16(class) TLMotionState : public btMotionState
{
private: 
  IModel* m_Model;

public:
  BT_DECLARE_ALIGNED_ALLOCATOR();
  
  // Constructor links to the TL-Engine model
  TLMotionState( IModel* model )
  {
    m_Model = model;
  }

  // Get the TL-Engine's model position and set it in the given Bullet transform variable (i.e. send TL model position to Bullet)
  void getWorldTransform(btTransform& transform) const
  {
	  m_Model->GetMatrix(matrix);
    transform.setFromOpenGLMatrix(matrix);
  }

  // Set the TL-Engine's model position from the given Bullet transform variable (i.e. get the TL model position from Bullet)
  void setWorldTransform(const btTransform& transform)
  {
    transform.getOpenGLMatrix(matrix);
    m_Model->SetMatrix(matrix); 
  }
};



/*-----------------------------------------------------------------------------------------
	Function prototypes
-----------------------------------------------------------------------------------------*/

// Overall program control
bool ProgramSetup();
void ProgramShutdown();

// Scene management
bool SceneSetup();
void SceneShutdown();
void SceneUpdate( float updateTime );

// Physics management
bool PhysicsSetup();
void PhysicsShutdown();
void PhysicsUpdate();


/*-----------------------------------------------------------------------------------------
	Main function
-----------------------------------------------------------------------------------------*/

void main()
{
	// Initialise program (TL-Engine etc.), quit program on failure
	if (!ProgramSetup())
	{
		return;
	}

	// Set up the scene, quit program on failure (remember to shutdown the program)
	if (!SceneSetup())
	{
		ProgramShutdown();
		return;
	}

	// Initialise and set up the physics, quit program on failure (remember to shutdown the scene and program)
	if (!PhysicsSetup())
	{
		SceneShutdown();
		ProgramShutdown();
		return;
	}

	// Amount of time to simulate in next physics call - using fixed timing for physics
	float physicsTime = 0.0f;
	myEngine->Timer(); // Reset timer before timing frames

	// The main game loop, repeat until engine is stopped (window closed or escape pressed)
	while (myEngine->IsRunning() && !myEngine->KeyHit( Key_Escape ))
	{
		// Draw the scene
		myEngine->DrawScene();

		// Get time since last frame and use the value to update the scene (variable update)
		float frameTime = myEngine->Timer();
		SceneUpdate( frameTime );

		// Add frame time onto amount of physics time that needs to be simulated
		physicsTime += frameTime;

		// As long as we have more than one physics tick to simulate
		int numTicks = 0;
		while (physicsTime > physicsTick)
		{
			// Perform one (fixed) physics tick of simulation
			PhysicsUpdate();
			physicsTime -= physicsTick;  // Subtract one tick from our accumulated time

			// Special code to limit the number of ticks/update
			// This will stop the physics engine using too much time in complex situations
			++numTicks;
			if (numTicks == maxPhysicsTicks)
			{
				physicsTime = 0; // Discard any further physics time - program will slow down if physics is too complex
				break;
			}
		}

    // Reset the scene by shutting everything down and restarting it
  	if (myEngine->KeyHit( Key_Space ))
		{
	    PhysicsShutdown();
	    SceneShutdown();
      SceneSetup();
      PhysicsSetup();
		}
  }

	// Shutdown the physics, scene and program before exiting
	PhysicsShutdown();
	SceneShutdown();
	ProgramShutdown();
}


/*-----------------------------------------------------------------------------------------
	Overall program control
-----------------------------------------------------------------------------------------*/

// One off setup for the entire program
bool ProgramSetup()
{
	// Create a 3D engine and open a window for it
	myEngine = New3DEngine( kTLX );
	if (!myEngine)
	{
		return false;
	}
	myEngine->StartWindowed(1280, 960);
	myEngine->StartMouseCapture();

	// Add default folders for meshes and other media
	myEngine->AddMediaFolder( "C:\\ProgramData\\TL-Engine\\Media" );

	return true;
}

// Final shutdown for the entire program
void ProgramShutdown()
{
	// Release the TL-Engine
	myEngine->Delete();
}


/*-----------------------------------------------------------------------------------------
	Scene Management
-----------------------------------------------------------------------------------------*/

// Initialise the scene (meshes, models, cameras etc)
bool SceneSetup()
{
	//// Load resources: meshes & fonts
	skyboxMesh = myEngine->LoadMesh( "Skybox.x" );
	groundMesh = myEngine->LoadMesh( "Ground.x" );
	cubeMesh = myEngine->LoadMesh( "Cube.x" );
	uiFont = myEngine->LoadFont( "Arial" );
	if (!skyboxMesh || !groundMesh || !cubeMesh || !uiFont)
	{
		return false;
	}

	// Create ground and sky models
	skybox = skyboxMesh->CreateModel(0, -500, 0);
	ground = groundMesh->CreateModel();

	// Create stacks of cube models
	int cube = 0;
	float x = -numCubesX * cubeSize; 
	for (int row = 0; row < numCubesX; ++row)
	{ 
		float y = cubeSize*4; 
		for (int stack = 0; stack < numCubesY; ++stack)
		{
			cubes[cube] = cubeMesh->CreateModel( x, y, 0.0f );
			++cube;
			y += cubeSize * 2.0f;
		}
		x += cubeSize * 2.0f;
	}

	camera = myEngine->CreateCamera( kManual, 0, 6, -32 );

	return true;
}

// Uninitialise scene resources
void SceneShutdown()
{
	// Remove font, camera and meshes (and hence their models)
	myEngine->RemoveFont( uiFont );
	myEngine->RemoveCamera( camera );
	myEngine->RemoveMesh( cubeMesh );
	myEngine->RemoveMesh( groundMesh );
	myEngine->RemoveMesh( skyboxMesh );
}

// Update the scene elements - pass the amount of time to update
void SceneUpdate( float updateTime )
{
	// Write out frame time
	stringstream outText;
	outText << "FPS: " << fixed << setprecision(1) << (1.0f / updateTime);
	uiFont->Draw( outText.str(), 0, 0 );

	// Move camera (variable timing)
	if (myEngine->KeyHeld(Key_Left) || myEngine->KeyHeld(Key_A))
	{
		camera->MoveLocalX( -cameraMoveSpeed * updateTime );
	}
	if (myEngine->KeyHeld(Key_Right) || myEngine->KeyHeld(Key_D))
	{
		camera->MoveLocalX( cameraMoveSpeed * updateTime );
	}
	if (myEngine->KeyHeld(Key_Up) || myEngine->KeyHeld(Key_W))
	{
		camera->MoveLocalZ( cameraMoveSpeed * updateTime );
	}
	if (myEngine->KeyHeld(Key_Down) || myEngine->KeyHeld(Key_S))
	{
		camera->MoveLocalZ( -cameraMoveSpeed * updateTime );
	}

	// Rotate camera with smoothing
	static float cameraRotX = 0.0f;
	static float cameraRotY = 0.0f;
	cameraRotX += myEngine->GetMouseMovementY() * cameraRotSpeed;
	cameraRotY += myEngine->GetMouseMovementX() * cameraRotSpeed;
	float smooth = 1.0f - pow( 0.5f, updateTime * cameraRotSmooth );
	camera->RotateLocalX( cameraRotX * smooth );
	camera->RotateY( cameraRotY * smooth );
	cameraRotX -= cameraRotX * smooth;
	cameraRotY -= cameraRotY * smooth;

	// Nothing else to do - model movement handled by physics engine
}


/*-----------------------------------------------------------------------------------------
	Physics Management
-----------------------------------------------------------------------------------------*/

// Initialise the physics engine, the physics world and the bodies in it
bool PhysicsSetup()
{
	//***************************************
	// Initialise the Bullet physics engine
  
  // Initialise Bullet subsystems. These lines can be left the same for simple purposes
  CollisionConfiguration = new btDefaultCollisionConfiguration();
  Dispatcher =             new btCollisionDispatcher(CollisionConfiguration);
  OverlappingPairCache =   new btDbvtBroadphase();
  Solver =                 new btSequentialImpulseConstraintSolver;


	//***************************************
	// Prepare the physics world

  // Create the physics world from the components above
  PhysicsWorld = new btDiscreteDynamicsWorld( Dispatcher, OverlappingPairCache, Solver, CollisionConfiguration );

  // Specify gravity in the world
  PhysicsWorld->setGravity(gravity);


	//***************************************
	// Create physics bodies to match models

  btScalar mass;
  btVector3 inertialTensor;
  btMotionState* motionState;

  ////////////
  // Ground
  
  // Static bodies have 0 mass and will not move due to forces or collisions and should not be repositioned by us either.

  // First create the collision shape
  btCollisionShape* groundShape = new btBoxShape(btVector3(400, 1, 400));
  CollisionShapes.push_back(groundShape);

  // Physics properties
  mass = 0;                          // Setting a 0 mass creates a "static" body in Bullet
  inertialTensor = btVector3(0,0,0); // Static objects should have 0 inertia

  // Connect motion of physics body with TL-Engine using class declared above
  motionState = new TLMotionState(ground);

  // Create rigid body and add to physics world
  btRigidBody* groundBody = new btRigidBody(btRigidBody::btRigidBodyConstructionInfo( mass, motionState, groundShape, inertialTensor ));
  PhysicsWorld->addRigidBody(groundBody);



	////////////
	// Cubes

  // Collision shape (common for all cubes)
  btCollisionShape* cubeShape = new btBoxShape(btVector3(1,1,1));
  CollisionShapes.push_back(cubeShape); // Add to list of shapes for easy deletion later

  // Set the cube's physical properties (common for all cubes)
  mass = 1;                                                 // Has some mass so this is a dynamic body
  cubeShape->calculateLocalInertia( mass, inertialTensor ); // Dynamic body needs inertial tensor calculated

	// Loop through each cube
	for (int i = 0; i < numCubesX * numCubesY; ++i)
	{
    // Connect motion of physics body with TL-Engine using class declared above
    motionState = new TLMotionState(cubes[i]);

    // Create the physics body and add to the world
    cubeRigidBodies[i] = new btRigidBody(btRigidBody::btRigidBodyConstructionInfo( mass, motionState, cubeShape, inertialTensor ));
    PhysicsWorld->addRigidBody(cubeRigidBodies[i]);

    cubeRigidBodies[i]->setSleepingThresholds( 0.4f, 0.2f );   // If the body movement becomes very slow the engine "deactivates" it for perfomance - but it deactivates too easily without this line
  }


	return true;
}


// Uninitialise the physics engine
void PhysicsShutdown()
{
  //****
  // This code is generic so there is no need to change it even if you change the collision shapes or bodies used

  // Remove all rigid bodies from the physics world and delete them
  for (int i = PhysicsWorld->getNumCollisionObjects()-1; i >= 0; i--)
  {
    btCollisionObject* obj = PhysicsWorld->getCollisionObjectArray()[i];
    btRigidBody* body = btRigidBody::upcast(obj);
    if (body && body->getMotionState())
    {
      delete body->getMotionState();
    }
    PhysicsWorld->removeCollisionObject( obj );
    delete obj;
  }

  // Delete collision shapes
  for (int i = 0; i < CollisionShapes.size(); i++)
  {
    btCollisionShape* shape = CollisionShapes[i];
    CollisionShapes[i] = nullptr;
    delete shape;
  }

  // Delete physics world
  delete PhysicsWorld;

  // Delete physics engine subsystems
  delete Solver;
  delete OverlappingPairCache;
  delete Dispatcher;
  delete CollisionConfiguration;
}


// Update the physics world by a fixed amount of time (using fixed tick update)
void PhysicsUpdate()
{
	PhysicsWorld->stepSimulation( physicsTick, 10 );
} 
