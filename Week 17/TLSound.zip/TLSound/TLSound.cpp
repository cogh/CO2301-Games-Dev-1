// TLSound.cpp: A program using the TL-Engine

#include <math.h>
#include <sstream>
using namespace std;

#include <windows.h>

#include <TL-Engine.h>	// TL-Engine include file and namespace
using namespace tle;


/////////////////////////////
// Game Constants

// Ship control
const float shipAccel = 15.0f;
const float shipMaxSpeed = 30.0f;
const float shipMaxSideSpeed = 10.0f;
const float shipMaxRotSpeed = 300;
const float shipDrag = 0.75f;        // Slow movement when no input
const float shipRotDrag = 0.02f;     // Slow rotational movement (has effect when no input)
const float shipRotDampSpeed = 1.0f; // Speed beyond which mouse input is damped
const float shipRotDamping = 2.0f;   // Maximum rotation damping applied at high speed
const int maxBullets = 40;
const float bulletSpeed = 6.0f;
const float bulletSize = 0.008f;

// Mouse sensitivity
const float mouseRotateSpeed = 0.5f;

// Chase camera position
const float cameraDist = 0.12f;   // Distance of camera behind ship
const float cameraHeight = 0.03f;  // Distance of camera above ship
const float cameraYAngle = 10.0f; // Angle of camera looking down on ship

// Maximum amount camera is allowed to lag behind the ship (rotational and movement lag)
// Actual amount of lag will increase with ship's movement/rotational speed
const float cameraMaxLagX = 0.025f;
const float cameraMaxLagZ = 0.1f;
const float cameraMaxLagRotX = 0.08f;
const float cameraMaxLagRotY = 0.16f;

// Amount of "look ahead" for the camera
const float lookAheadHoriz = 0.5f;
const float lookAheadVert = 0.6f;


/////////////////////////////
// Global variables

// Resources
I3DEngine* myEngine;
HWND hWnd;
IMesh* starsMesh;
IMesh* planetMesh;
IMesh* shipMesh;
IMesh* bulletMesh;
IModel* stars;
IModel* earth;
IModel* venus;
IModel* sun;
IModel* ship;
IModel* moon;
ICamera* camera;
ILight* sunlight; 
ILight* light1; 
ILight* light2; 
IFont* loadingFont;
IFont* frontEndFont;
IFont* gameFont;

// Mouse cursor position (doing mouse work directly in this project)
int mouseX;
int mouseY;
int mouseMovementX;
int mouseMovementY;

// Define a structure holding data for a single bullet
struct BulletData
{
	IModel* model;
	float xVel, yVel, zVel;
	float life;
};

// Define an array of bullet structures and an integer specifying how many are 
// actually used currently. The used bullets will always be at the start of the list
int numBullets = 0;
BulletData bullets[maxBullets];


// Ship sideward, forward and rotation speeds
float shipSpeedX = 0.0f;
float shipSpeedZ = 0.0f;
float shipSpeedRotX = 0.0f;
float shipSpeedRotY = 0.0f;

// Variables to calculate recent average speed (see UpdateScene for comments)
const float avgSamplePeriod = 0.1f; // Period of time (seconds) over which to average
const int maxAvgSamples = 100;      // Maximum number of recent frames to average speeds over
int currAvgSample = 0;              // Counter over number of frames above

// Structure holding the speeds sampled at a single frame
struct SpeedSample 
{
	float X, Z;
	float RotX, RotY;
};

// Array of speeds over the recent frames
SpeedSample recentSpeeds[maxAvgSamples];

// Average speed over recent frames
SpeedSample shipAvgSpeed = { 0.0f, 0.0f, 0.0f, 0.0f }; // Initialise all averages to 0

// World matrix (4x4 floats) used for some update code
float matrix[16];


/////////////////////////////
// Program setup/shutdown

// One off setup for the entire program. Returns true on success, false on failure
bool ProgramSetup()
{
	// Create a 3D engine (Irrlicht in this case) and open a window for it
	myEngine = New3DEngine( kIrrlicht );
	if (!myEngine)
	{
		return false;
	}
	myEngine->StartWindowed( 1280, 720 );
	hWnd = (HWND)myEngine->GetWindow(); // Window handle

	// Add folders for meshes and other media (for different locations)
	myEngine->AddMediaFolder( "C:\\ProgramData\\TL-Engine\\Media" );

	// Load a loading screen font - will keep this in memory all the time (i.e. don't remove it)
	loadingFont = myEngine->LoadFont( "Font2.bmp" );
	if (!loadingFont)
	{
		myEngine->Delete();
		return false;
	}

	return true;
}

// Final shutdown for the entire program
void ProgramShutdown()
{
	myEngine->Delete();
}


/////////////////////////////
// Front end functions

// Set up the front-end (load meshes & fonts and create models, cameras, lights etc)
// Returns true on success, false on failure
bool FrontEndSetup()
{
	// Load resources, returning on failure
	starsMesh = myEngine->LoadMesh( "Stars.x" );
	planetMesh = myEngine->LoadMesh( "Earth.x" );
	frontEndFont = myEngine->LoadFont( "Font1.bmp" );
	if (!starsMesh || !planetMesh || !frontEndFont)
	{
		// Should really release those that were successfully loaded
		return false;
	}

	// Create environment
	stars = starsMesh->CreateModel();
	stars->SetSkin( "StarCloudsHi.jpg" );
	moon = planetMesh->CreateModel();
	moon->SetSkin( "MoonHi.jpg" );

	camera = myEngine->CreateCamera( kManual, 0.0f, 50.0f, -180.0f );
	camera->RotateX( 18.0f );

	myEngine->SetAmbientLight( 0.4f, 0.1f, 0.1f ); // Background redish light
	light1 = myEngine->CreatePointLight( 100.0f, 100.0f, -100.0f,  1.0f, 0.3f, 0.3f,  300.0f );
	light2 = myEngine->CreatePointLight( -200.0f, -200.0f, 80.0f,  0.6f, 0.0f, 0.0f,  1000.0f );
	moon->EnableLighting();

	// Initialise timer (used for variable timing in front-end and game loops)
	myEngine->Timer();

	return true;
}

// Update the front-end, move models & cameras, draw text etc. Pass a float to specify the
// time passed since the last update (frame) - allows us to use the variable timing method
void FrontEndUpdate( float updateTime )
{
	// Text (with shadows)
	frontEndFont->Draw( "Generic Space Game II", 638, 118, kGrey, kCentre );
	frontEndFont->Draw( "Generic Space Game II", 638, 122, kGrey, kCentre );
	frontEndFont->Draw( "Generic Space Game II", 642, 118, kGrey, kCentre );
	frontEndFont->Draw( "Generic Space Game II", 642, 122, kGrey, kCentre );
	frontEndFont->Draw( "Generic Space Game II", 640, 120, kWhite, kCentre );
	frontEndFont->Draw( "Press P to Play", 642, 222, kBlack, kCentre );
	frontEndFont->Draw( "Press P to Play", 640, 220, kYellow, kCentre );
	frontEndFont->Draw( "Press Q to Quit", 642, 322, kBlack, kCentre );
	frontEndFont->Draw( "Press Q to Quit", 640, 320, kRed, kCentre );

	stars->RotateY( 1.0f * updateTime );
	moon->RotateY( 2.0f * updateTime );
}

// Shutdown the front-end, remove everything created in the setup function
void FrontEndShutdown()
{
	myEngine->RemoveCamera( camera );
	myEngine->RemoveLight( light2 );
	myEngine->RemoveLight( light1 );
	myEngine->RemoveFont( frontEndFont );
	myEngine->RemoveMesh( planetMesh );
	myEngine->RemoveMesh( starsMesh );
}


/////////////////////////////
// Game loop functions

bool GameSetup()
{
	// Load meshes
	starsMesh = myEngine->LoadMesh( "Stars.x" );
	planetMesh = myEngine->LoadMesh( "Earth.x" );
	shipMesh = myEngine->LoadMesh( "HawkStarfighter.x" );
	bulletMesh = myEngine->LoadMesh( "Flare.x" );
	gameFont = myEngine->LoadFont( "Font2.bmp" );
	if (!starsMesh || !planetMesh || !shipMesh || !bulletMesh || !gameFont)
	{
		// Should really release those that were successfully loaded
		return false;
	}

	// Create environment
	earth = planetMesh->CreateModel();
	earth->RotateZ( 15.0f );

	venus = planetMesh->CreateModel( 300.0f, 100.0f, 300.0f );
	venus->SetSkin( "Venus.jpg" );
	venus->RotateZ( -5.0f );

	sun = planetMesh->CreateModel( 10000.0f, 3000.0f, -6000.0f );
	sun->SetSkin( "Sun.jpg" );
	sun->Scale( 5.0f );

	stars = starsMesh->CreateModel();
	stars->SetSkin( "StarsHi.jpg" );
	stars->Scale( 20.0f );

	// Create ship and reset number of bullets
	ship = shipMesh->CreateModel( 0.0f, 0.0f, -200.0f );
	numBullets = 0;
	
	// Create camera - based on ship's position plus constants from above
	camera = myEngine->CreateCamera( kManual, ship->GetX(), ship->GetY() + cameraHeight,
	                                          ship->GetZ() - cameraDist );
	camera->RotateX( cameraYAngle );
	camera->SetNearClip( 0.05f );    // Change near and far viewing distance...
	camera->SetFarClip( 50000.0f );  // ...for camera to suit a space game

	// Set up lighting
	myEngine->SetAmbientLight( 0.2f, 0.2f, 0.3f ); // Background blueish light
	sunlight = myEngine->CreatePointLight( sun->GetX(), sun->GetY(), sun->GetZ(), 
	                                       1.0f, 0.9f, 0.5f, sun->GetX() * 2.0f ); // Sun light
	earth->EnableLighting();
	venus->EnableLighting();
	ship->EnableLighting();

	// Mouse capture is not working properly for this kind of project so do mouse work directly with Windows calls 
	SetCapture(hWnd);
	ShowCursor(false);
	RECT rect0 = { 0 };
	GetWindowRect(hWnd, &rect0);
	mouseX = rect0.left + (rect0.right - rect0.left) / 2;
	mouseY = rect0.top + (rect0.bottom - rect0.top) / 2;
	SetCursorPos(mouseX, mouseY);

	// Initialise timer (used for variable timing in front-end and game loops)
	myEngine->Timer();

	return true;
}

// Update the game, move models & cameras, draw text etc. Pass a float to specify the
// time passed since the last update (frame) - allows us to use the variable timing method
void GameUpdate( float updateTime )
{
	stringstream outText;
	outText << "FPS: " << 1.0f / updateTime;    // Can't use endl with TL fonts...
	gameFont->Draw( outText.str(), 0, 0, kWhite ); // ...use multiple draw calls instead
	outText.str(""); // How to clear outText for further draw calls


	////////////////////////
	// Planet update

	// Rotate planets - use variable timing
	earth->RotateY( 5.0f * updateTime );
	venus->RotateY( -2.5f * updateTime );
	sun->RotateY( 2.5f * updateTime );


	////////////////////////
	// Bullet update

	// Bullet movement - loop through each bullet and update it
	for (int i = 0; i < numBullets; i++)
	{
		// Move bullet
		bullets[i].model->Move( bullets[i].xVel * updateTime, bullets[i].yVel * updateTime,
		                        bullets[i].zVel * updateTime );
		
		// Decrease life and see if bullet is dead
		bullets[i].life -= updateTime;
		if (bullets[i].life <= 0)
		{
			// Destroy bullet
			bulletMesh->RemoveModel( bullets[i].model );

			// Copy last bullet into this dead slot to keep all live bullets in one block
			bullets[i].model = bullets[numBullets-1].model;
			bullets[i].xVel = bullets[numBullets-1].xVel;
			bullets[i].yVel = bullets[numBullets-1].yVel;
			bullets[i].zVel = bullets[numBullets-1].zVel;
			bullets[i].life = bullets[numBullets-1].life;

			// Decrease number of bullets
			numBullets--;
		}
	}

	// Shooting - create two new bullets when fire is pressed
	if ((myEngine->KeyHit( Key_Space ) || myEngine->KeyHit( Mouse_LButton )) &&
	    numBullets < maxBullets)
	{
		//*******************************
		// Play shooting sound here
		//*******************************

		// Create bullet 1
		float x = ship->GetX() - 0.015f * matrix[0] + 0.01f * matrix[8];
		float y = ship->GetY() - 0.015f * matrix[1] + 0.01f * matrix[9];
		float z = ship->GetZ() - 0.015f * matrix[2] + 0.01f * matrix[10];
		bullets[numBullets].model = bulletMesh->CreateModel( x, y, z );
		bullets[numBullets].model->Scale( bulletSize );

		// Get ship direction from matrix (x and z axes)
		ship->GetMatrix( matrix );
		float bulletSpeedX = shipSpeedX;
		float bulletSpeedZ = shipSpeedZ + bulletSpeed;
		bullets[numBullets].xVel = bulletSpeedX * matrix[0] + bulletSpeedZ * matrix[8];
		bullets[numBullets].yVel = bulletSpeedX * matrix[1] + bulletSpeedZ * matrix[9];
		bullets[numBullets].zVel = bulletSpeedX * matrix[2] + bulletSpeedZ * matrix[10];

		// Length of bullet's life measured in seconds
		bullets[numBullets].life = 1.5f;
		numBullets++;

		// Create bullets in pairs - enough space for one more bullet?
		if (numBullets < maxBullets)
		{
			// Create bullet 2
			x = ship->GetX() + 0.015f * matrix[0] + 0.01f * matrix[8];
			y = ship->GetY() + 0.015f * matrix[1] + 0.01f * matrix[9];
			z = ship->GetZ() + 0.015f * matrix[2] + 0.01f * matrix[10];
			bullets[numBullets].model = bulletMesh->CreateModel( x, y, z );
			bullets[numBullets].model->Scale( bulletSize );

			// Get ship direction from matrix (x and z axes)
			bullets[numBullets].xVel = bulletSpeedX * matrix[0] + bulletSpeedZ * matrix[8];
			bullets[numBullets].yVel = bulletSpeedX * matrix[1] + bulletSpeedZ * matrix[9];
			bullets[numBullets].zVel = bulletSpeedX * matrix[2] + bulletSpeedZ * matrix[10];

			// Length of bullet's life measured in seconds
			bullets[numBullets].life = 1.5f;
			numBullets++;
		}
	}


	//---------------------------------------------------------------------------------
	// The ship and camera in this program are carefully controlled and smoothed for
	// a better interface. This is advanced work that you don't need to understand in
	// full to follow the worksheet. Still it might give you ideas for your project
	//---------------------------------------------------------------------------------

	////////////////////////
	// Ship Control

	// Ship forward movement
	if (myEngine->KeyHeld( Key_W )) // Forward
	{
		// Increase basic ship speed using constant acceleration and check speed limit
		shipSpeedZ += shipAccel * updateTime;
		if (shipSpeedZ > shipMaxSpeed)
		{
			shipSpeedZ = shipMaxSpeed;
		}
	}
	else if (myEngine->KeyHeld( Key_S )) // Backward
	{
		// Decrease basic ship speed using constant acceleration and check speed limit
		shipSpeedZ -= shipAccel * updateTime;
		if (shipSpeedZ < -shipMaxSpeed/4.0f) // Slower in reverse
		{
			shipSpeedZ = -shipMaxSpeed/4.0f;
		}
	}

	// Ship sideways movement
	if (myEngine->KeyHeld( Key_D )) // Right
	{
		// Change basic ship speed using constant acceleration and check speed limit
		shipSpeedX += shipAccel * updateTime;
		if (shipSpeedX > shipMaxSideSpeed)
		{
			shipSpeedX = shipMaxSideSpeed;
		}
	}
	else if (myEngine->KeyHeld( Key_A )) // Left
	{
		// Change basic ship speed using constant acceleration and check speed limit
		shipSpeedX -= shipAccel * updateTime;
		if (shipSpeedX < -shipMaxSideSpeed)
		{
			shipSpeedX = -shipMaxSideSpeed;
		}
	}

	// Apply drag to speed - if not pressing a key
	// As we are multiplying, need to use pow for variable timing method
	float drag = pow( shipDrag, updateTime );
	shipSpeedX *= drag;
	shipSpeedZ *= drag;

	// Use speeds set above to move ship forwards/backwards & left/right
	ship->MoveLocalX( shipSpeedX * updateTime );
	ship->MoveLocalZ( shipSpeedZ * updateTime );


	// Get mouse input - don't need to scale this by updateTime
	//**** Can make either of these negative to invert the mouse control
	float mouseMoveX = mouseMovementX * mouseRotateSpeed;
	float mouseMoveY = mouseMovementY * mouseRotateSpeed;

	// If ship forward speed is high..
	if (abs( shipSpeedZ ) > shipRotDampSpeed)
	{
		// ...damp the rotation input (reduce its sensitivity) - tricky
		float dampingScale = (abs( shipSpeedZ ) - shipRotDampSpeed) / 
		                     (shipMaxSpeed      - shipRotDampSpeed);
		float sensitivityAdjust = 1.0f + shipRotDamping * dampingScale;
		mouseMoveX /= sensitivityAdjust;
		mouseMoveY /= sensitivityAdjust;
	}


	// Update ship's rotational speeds based on mouse movement, ensure maximum rotational speed is not exceeded
	shipSpeedRotX += mouseMoveY; // X mouse movement makes Y ship rotation and vice versa - think about it
	shipSpeedRotY += mouseMoveX; // --"--
	if (shipSpeedRotX > shipMaxRotSpeed)
	{
		shipSpeedRotX = shipMaxRotSpeed;
	}
	else if (shipSpeedRotX < -shipMaxRotSpeed)
	{
		shipSpeedRotX = -shipMaxRotSpeed;
	}
	if (shipSpeedRotY > shipMaxRotSpeed)
	{
		shipSpeedRotY = shipMaxRotSpeed;
	}
	else if (shipSpeedRotY < -shipMaxRotSpeed)
	{
		shipSpeedRotY = -shipMaxRotSpeed;
	}

	// Apply drag to rotational speed, so ship's rotation smoothly stops when mouse stops moving
	float rotDrag = pow( shipRotDrag, updateTime );
	shipSpeedRotX *= rotDrag;
	shipSpeedRotY *= rotDrag;

	// Rotate ship - use variable timing
	ship->RotateX( shipSpeedRotX * updateTime );
	ship->RotateY( shipSpeedRotY * updateTime );


	//////////////////////////////
	// Calculate Average Speed

	// The ships movement above is not smoothed (this would make the control "laggy")
	// However the chase camera movement is heavily smoothed. This makes the look
	// of the game smoother and also allows the camera to "look ahead" of the ship
	// Lots of tinkering required to perfect this kind of thing. One key requirement
	// is to have the camera follow the *recent average speed* of the ship rather 
	// than the *current actual speed*. The following code keeps track of this average
	// over recent frames

	// Find average of recently sampled speeds. Uses a quick way to update a running average - remove the 
	// oldest sample, then add in the newest - saves using a for loop over the whole array
	int numAvgSamples = (int)(avgSamplePeriod / updateTime); // Approx number of frames that occured in the sample period
	if (numAvgSamples == 0) numAvgSamples = 1;
	if (numAvgSamples > maxAvgSamples) numAvgSamples = maxAvgSamples;
	int oldAvgSample = (currAvgSample - numAvgSamples + maxAvgSamples) % maxAvgSamples; // Get oldest sample index
	shipAvgSpeed.X = (shipAvgSpeed.X * numAvgSamples - recentSpeeds[oldAvgSample].X + shipSpeedX) / numAvgSamples;
	shipAvgSpeed.Z = (shipAvgSpeed.Z * numAvgSamples - recentSpeeds[oldAvgSample].Z + shipSpeedZ) / numAvgSamples;
	shipAvgSpeed.RotX = (shipAvgSpeed.RotX * numAvgSamples - recentSpeeds[oldAvgSample].RotX + shipSpeedRotX) / numAvgSamples;
	shipAvgSpeed.RotY = (shipAvgSpeed.RotY * numAvgSamples - recentSpeeds[oldAvgSample].RotY + shipSpeedRotY) / numAvgSamples;
	recentSpeeds[currAvgSample].X = shipSpeedX;
	recentSpeeds[currAvgSample].Z = shipSpeedZ;
	recentSpeeds[currAvgSample].RotX = shipSpeedRotX;
	recentSpeeds[currAvgSample].RotY = shipSpeedRotY;

	// Step to next sample
	currAvgSample = (currAvgSample + 1) % maxAvgSamples;


	//////////////////////////////
	// Camera Movement

	// Camera is allowed to lag behind it's exact chase position behind the ship (both rotational
	// and movement lag). The amount of lag increases with ship's movement/rotational speed

	// Calculate amount to lag behind in rotation
	static float cameraLagRotX = 0.0f;
	static float cameraLagRotY = 0.0f;
	float cameraLagAdjustRotX = -cameraLagRotX;
	float cameraLagAdjustRotY = -cameraLagRotY;
	cameraLagRotX = cameraMaxLagRotX * -shipAvgSpeed.RotX / shipMaxRotSpeed;
	cameraLagRotY = cameraMaxLagRotY * -shipAvgSpeed.RotY / shipMaxRotSpeed;
	cameraLagAdjustRotX += cameraLagRotX;
	cameraLagAdjustRotY += cameraLagRotY;

	// Rotate same as ship, but with adjustment for lag
	camera->RotateX( shipSpeedRotX * updateTime + cameraLagAdjustRotX );
	camera->RotateY( shipSpeedRotY * updateTime + cameraLagAdjustRotY );


	// Calculate amount to lag behind movement
	float cameraLagX = cameraMaxLagX * -shipAvgSpeed.X / shipMaxSideSpeed;
	float cameraLagY = 0;
	float cameraLagZ = cameraMaxLagZ * -shipAvgSpeed.Z / shipMaxSpeed;
	cameraLagX -= cameraLagRotY * lookAheadHoriz; // Allow camera to "look ahead" of ship by adding "forward lag" based on rotation...
	cameraLagY -= -cameraLagRotX * lookAheadVert;

	// Camera will follow a chase position fixed behind the ship, but with some lag as described above
	// Use matrix work to get chase position - extracting X,Y and Z axes from world matrix - recall Computer Graphics
	ship->GetMatrix( matrix );
	//              Ship position + side lag in X-Axis     + up a little in Y-axis                   + set back & lag in Z-Axis
	float cameraPosX = matrix[12] + cameraLagX * matrix[0] + (cameraLagY + cameraHeight) * matrix[4] + (cameraLagZ - cameraDist) * matrix[8];
	float cameraPosY = matrix[13] + cameraLagX * matrix[1] + (cameraLagY + cameraHeight) * matrix[5] + (cameraLagZ - cameraDist) * matrix[9];
	float cameraPosZ = matrix[14] + cameraLagX * matrix[2] + (cameraLagY + cameraHeight) * matrix[6] + (cameraLagZ - cameraDist) * matrix[10];
	camera->SetPosition( cameraPosX, cameraPosY, cameraPosZ );
}

// Shutdown the game, remove everything created in the setup function
void GameShutdown()
{
	// Put engine back to original state - remove all lights, models and meshes
	//myEngine->StopMouseCapture();
	myEngine->RemoveFont( gameFont );
	myEngine->RemoveLight( sunlight );
	myEngine->RemoveCamera( camera );
	shipMesh->RemoveModel( ship );
	planetMesh->RemoveModel( sun );
	planetMesh->RemoveModel( venus );
	planetMesh->RemoveModel( earth );
	starsMesh->RemoveModel( stars );
	myEngine->RemoveMesh( shipMesh );
	myEngine->RemoveMesh( planetMesh );
	myEngine->RemoveMesh( starsMesh );
}



/////////////////////////////
// Main function

// This main function contains a much more realistic structure than those we have seen before
// It contains a front-end loop, and a game loop, and has full error checking. All the actual
// set-up, shutdown and update code has been removed to functions above
void main()
{
	// Initialise program (TL-Engine etc.), quit program on failure
	if (!ProgramSetup())
	{
		return;
	}

	// Loop to return to the front-end. while (true) would loop forever, but the return
	// statements inside will exit this loop (and the function/program)
	while (true)
	{
		///////////////////////////////////
		// Front End

		// Set up the game (load meshes, create models etc), quit program on failure
		if (!FrontEndSetup())
		{
			ProgramShutdown();
			return;
		}

		// The front-end loop, repeat until user presses 'P' to play
		while (!myEngine->KeyHit( Key_P ))
		{
			// Draw the scene
			myEngine->DrawScene();

			// Call FrontEndUpdate passing the latest frame time (time since last frame)
			// Allows us to use the variable timing method
			float frameTime = myEngine->Timer();
			FrontEndUpdate( frameTime );

			// Program exit required (user pressed Q, closed window or pressed Alt-F4)
			if (myEngine->KeyHit( Key_Q ) || !myEngine->IsRunning())
			{
				ProgramShutdown();
				return;
			}
		}

		// Shutdown the front end
		FrontEndShutdown();


		///////////////////////////////////
		// Loading screen

		// Draw loading screen text
		loadingFont->Draw( "Loading - Please Wait", 640, 360, kBlack, kCentre );
		myEngine->DrawScene();


		///////////////////////////////////
		// Game

		// Set up the game (load meshes, create models etc), quit program on failure
		if (!GameSetup())
		{
			ProgramShutdown();
			return;
		}

		// The game loop, repeat until user presses 'Escape'
		while (!myEngine->KeyHit( Key_Escape ))
		{
			// Doing mouse work manually in this project, get motion and then set mouse to centre of window every frame
			POINT mousePt;
			GetCursorPos(&mousePt);
			mouseMovementX = mousePt.x - mouseX;
			mouseMovementY = mousePt.y - mouseY;
			RECT rect = { 0 };
			GetWindowRect(hWnd, &rect);
			mouseX = rect.left + (rect.right - rect.left) / 2;
			mouseY = rect.top + (rect.bottom - rect.top) / 2;
			SetCursorPos(mouseX, mouseY);

			// Draw the scene
			myEngine->DrawScene();

			// Call GameUpdate passing the latest frame time (time since last frame)
			// Allows us to use the variable timing method
			float frameTime = myEngine->Timer();
			GameUpdate( frameTime );

			// Immediate program exit required (user closed window or pressed Alt-F4)
			if (!myEngine->IsRunning())
			{
				ProgramShutdown();
				return;
			}
		}

		// Shutdown the front end
		GameShutdown();
	}
}
