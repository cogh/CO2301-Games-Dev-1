/*******************************************
	PlayerEntity.h

	Player entity template and entity classes
********************************************/

#pragma once

#include <string>
using namespace std;

#include "Defines.h"
#include "CVector3.h"
#include "Entity.h"

namespace gen
{

/*-----------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
	Player Template Class
-------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------*/

// A player template inherits the type, name and mesh from the base template and adds further
// player specifications
class CPlayerTemplate : public CEntityTemplate
{
/////////////////////////////////////
//	Constructors/Destructors
public:
	// Player entity template constructor sets up the player specifications - speed, acceleration and
	// turn speed and passes the other parameters to construct the base class
	CPlayerTemplate
	(
		const string& type, const string& name, const string& meshFilename,
		TFloat32 maxSpeed, TUInt32 maxHP, TUInt32 hitDamage
	) : CEntityTemplate( type, name, meshFilename )
	{
		// Set player template values
		m_MaxSpeed = maxSpeed;
		m_MaxHP = maxHP;
		m_HitDamage = hitDamage;
	}

	// No destructor needed (base class one will do)


/////////////////////////////////////
//	Public interface
public:

	/////////////////////////////////////
	//	Getters

	TFloat32 GetMaxSpeed()
	{
		return m_MaxSpeed;
	}

	TInt32 GetMaxHP()
	{
		return m_MaxHP;
	}

	TInt32 GetHitDamage()
	{
		return m_HitDamage;
	}


/////////////////////////////////////
//	Private interface
private:

	// Common statistics for this player type (template)
	TFloat32 m_MaxSpeed;        // Maximum speed for this kind of player
	TUInt32  m_MaxHP;           // Maximum (initial) HP for this kind of player
	TUInt32  m_HitDamage;     // HP damage caused by hits from this kind of player
};



/*-----------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
	Player Entity Class
-------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------*/

// A player entity inherits the ID/positioning/rendering support of the base entity class
// and adds instance and state data. It overrides the update function to perform the player
// entity behaviour
class CPlayerEntity : public CEntity
{
/////////////////////////////////////
//	Constructors/Destructors
public:
	// Player constructor intialises player-specific data and passes its parameters to the base
	// class constructor
	CPlayerEntity
	(
		CPlayerTemplate*  playerTemplate,
		TEntityUID      UID,
		const string&   name = "",
		const CVector3& position = CVector3::kOrigin, 
		const CVector3& rotation = CVector3( 0.0f, 0.0f, 0.0f ),
		const CVector3& scale = CVector3( 1.0f, 1.0f, 1.0f )
	);

	// No destructor needed


/////////////////////////////////////
//	Public interface
public:

	/////////////////////////////////////
	// Getters

	TInt32 GetHP()
	{
		return m_HP;
	}

	TInt32 GetScore()
	{
		return m_Score;
	}

	string GetState()
	{
		switch (m_State)
		{
			case Inactive: return "Inactive"; break;
			case Run: return "Run"; break;
			case StockUp: return "StockUp"; break;
		}
		return "?";
	}

	/////////////////////////////////////
	// Update

	// Update the player - controls its behaviour.
	// Return false if the entity is to be destroyed
	virtual bool Update( TFloat32 updateTime );
	

/////////////////////////////////////
//	Private interface
private:

	/////////////////////////////////////
	// Types

	// States available for a player
	enum EState
	{
		Inactive,
		Run,
		StockUp,
	};


	/////////////////////////////////////
	// Data

	// The template holding common data for all player entities
	CPlayerTemplate* m_PlayerTemplate;

	// Player data
	TInt32 m_HP;    // Current hit points for the player
	TInt32 m_Score; // Current player score 

	// Player state
	EState   m_State;
	TUInt32  m_CurrentBuilding; // Building (0 or 1) that player must reach next
	TFloat32 m_StockUpTime;     // Countdown when player reaches building - can't move during this time
};


} // namespace gen
