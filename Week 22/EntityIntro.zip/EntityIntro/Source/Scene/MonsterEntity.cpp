/*******************************************
	MonsterEntity.cpp

	Monster entity template and entity classes
********************************************/

#include "MonsterEntity.h"
#include "EntityManager.h"
#include "Messenger.h"

namespace gen
{

//***| INFO |*************************************************/
// Entity manager allows look up of entities by name, UID etc. 
// Example, get the entity called "Bob", then get its UID:
//    CEntity* entity = EntityManager.GetEntity( "Bob" );
//    TEntityUID uid = entity->GetUID();
//
// More usefully, get the given UID's position:
//    CVector3 targetPos = EntityManager.GetEntity( targetUID )->Position();
//
// Complex example, make the entity called "Bob" face this entity's position:
//    EntityManager.GetEntity( "Bob" )->Matrix().FaceTarget( Position() );
//************************************************************/
extern CEntityManager EntityManager;

//***| INFO |*************************************************/
// Messenger class for sending/receiving messages to and from other entities
// Example: Send a hit message to enemyUID
//    SMessage msg;
//    msg.type = Msg_Hit;
//    msg.value = 10;
//    msg.from = GetUID();
//    Messenger.SendMessage( enemyUID, msg );
//************************************************************/
extern CMessenger Messenger;



/*-----------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
	Monster Entity Class
-------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------*/

// Monster constructor intialises monster-specific data and passes its parameters to the base
// class constructor
CMonsterEntity::CMonsterEntity
(
	CMonsterTemplate*  monsterTemplate,
	TEntityUID      UID,
	const string&   name /*=""*/,
	const CVector3& position /*= CVector3::kOrigin*/, 
	const CVector3& rotation /*= CVector3( 0.0f, 0.0f, 0.0f )*/,
	const CVector3& scale /*= CVector3( 1.0f, 1.0f, 1.0f )*/
) : CEntity( monsterTemplate, UID, name, position, rotation, scale )
{
	m_MonsterTemplate = monsterTemplate;

	// Initialise other monster data and state
	m_HP = m_MonsterTemplate->GetMaxHP();
	m_State = Inactive;
}


//***| INFO |*************************************************/
// Update the monster - controls its behaviour.
//************************************************************/
// Return false if the entity is to be destroyed
bool CMonsterEntity::Update( TFloat32 updateTime )
{
	//********************************************************/
	// Message handling
	//********************************************************/
	// Fetch any messages. The Messenger class handles the collection and delivery - we just enter
	// a loop collecting any pending messages, acting accordingly
	SMessage msg;
	while (Messenger.FetchMessage( GetUID(), &msg ))
	{
		// Update monster state based on messages received
		switch (msg.type)
		{
			// Start message: starts the game - the monster begins to wander
			case Msg_Start:
				m_State = Wander;
				// Choose random point to wander towards
				m_WanderPoint = CVector3( Random(-30.0f,30.0f), 0.0f, Random(-20.0f,20.0f) );
				break;

			// Hit message: the monster loses some HP, and dies if HP < 0
			case Msg_Hit:
				/*****MISSING - lose HP depending on value sent in message */
				if (m_HP <= 0)
				{
					// Monster has died, return false - the entity manager will take care of removing it
					return false;
				}
				break;

			// Stop message: the monster becomes inactive
			case Msg_Stop:
				/*****MISSING - one line, read comment above*/
				break;
		}
	}

	//********************************************************/
	// Monster behaviour
	//********************************************************/
	// Behaviour for monster depends on its "state"

	//---------------------------------------------------------
	// Wander state: move from random point to random point
	//---------------------------------------------------------
	if (m_State == Wander)
	{
		// Face wander point and move forwards towards it. Move at 3/4 maximum speed
		Matrix().FaceTarget( m_WanderPoint );
		Matrix().MoveLocalZ( m_MonsterTemplate->GetMaxSpeed() * 0.75f * updateTime );

		// When reached the wander point choose a new random one
		if (Distance( Position(), m_WanderPoint ) < 2.0f)
		{
			m_WanderPoint = CVector3( Random(-30.0f,30.0f), 0.0f, Random(-20.0f,20.0f) );
		}

		// Get the player entity, checking if it exists first (player might be dead)
		CEntity* player = EntityManager.GetEntity( "Player" );
		if (player != 0)
		{
			// If near the player, then start to chase
			if (0/*****MISSING - (not 0) check if distance from monster position to player position 
				                 is less than 15.0f. Look how the distance check above was done*/)
			{
				// Enter the chase state, initialise tired countdown and recharge time (see chase state)
				m_State = Chase;
				m_TiredTime = 5.0f;
				m_RechargeTime = 0.0f;
			}
		}
	}

	//---------------------------------------------------------
	// Chase state: chase the player and hit them when near
	// Monster must recharge between hits. Tires eventually
	//---------------------------------------------------------
	else if (m_State == Chase)
	{
		// Get player entity - if it doesn't exist then the player is dead - return to wander state
		CEntity* player = EntityManager.GetEntity( "Player" );
		if (player == 0)
		{
			m_State = Wander;
			/*****MISSING - going back to wander state, choose a random wander point (see how
			                it was done above*/
		}
		else
		{
			// Decrease recharge time, can only hit player when it is <= 0
			m_RechargeTime -= updateTime;

			// If close to player then hit them
			if (Distance( Position(), player->Position() ) < 2.0f)
			{
				// Can only hit if not recharging
				if (m_RechargeTime <= 0.0f)
				{
					// Send a message to player indicating they've been hit
					SMessage msg;
					//msg.type = /*****MISSING - uncomment line, look at the message types received*/;
					msg.from = GetUID(); // Who is sending the message
					msg.value = m_MonsterTemplate->GetHitDamage();  // Additional message info
					Messenger.SendMessage( player->GetUID(), msg ); // Send the message

					// Reset recharge time - can't hit again for a while
					m_RechargeTime = 1.5f;
				}
			}
			else
			{
				// If can't hit player, then face them and move forward (at full speed)
				Matrix().FaceTarget( player->Position() );
				Matrix().MoveLocalZ( m_MonsterTemplate->GetMaxSpeed() * updateTime );
			}

			// Countdown to tired
			m_TiredTime -= updateTime;
			if (m_TiredTime <= 0.0f)
			{
				// Enter tired state, reset the tired timer
				m_State = Tired;
				m_TiredTime = 3.0f;
				Matrix().RotateLocalX( ToRadians(30.0f) ); // Lean forward to indicate tiredness (!)
			}
		}
	}

	//---------------------------------------------------------
	// Tired state: pause a while before returning to wandering
	//---------------------------------------------------------
	else if (m_State == Tired)
	{
		// Countdown tired time again, finished being tired when it reaches 0
		/*****MISSING - code to perform comment above*/
		{
			// No longer tired, return to wander state & reset tired timer
			Matrix().RotateLocalX( -ToRadians(30.0f) ); // Stand up straight again
			/*****MISSING - go back to wander state*/
			m_TiredTime = 3.0f;
		}
	}


	// Only return false when this entity has died
	return true; 
}


} // namespace gen
