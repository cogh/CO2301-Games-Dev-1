/*******************************************
	PlayerEntity.cpp

	Player entity template and entity classes
********************************************/

#include "PlayerEntity.h"
#include "EntityManager.h"
#include "Messenger.h"
#include "Input.h"

namespace gen
{

//***| INFO |*************************************************/
// See MonsterEntity.cpp for information on these variables
//************************************************************/

// Entity manager allows look up of entities by name, UID etc. 
extern CEntityManager EntityManager;

// Messenger class for sending/receiving messages to and from other entities
extern CMessenger Messenger;


/*-----------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
	Player Entity Class
-------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------*/

// Player constructor intialises player-specific data and passes its parameters to the base
// class constructor
CPlayerEntity::CPlayerEntity
(
	CPlayerTemplate*  playerTemplate,
	TEntityUID      UID,
	const string&   name /*=""*/,
	const CVector3& position /*= CVector3::kOrigin*/, 
	const CVector3& rotation /*= CVector3( 0.0f, 0.0f, 0.0f )*/,
	const CVector3& scale /*= CVector3( 1.0f, 1.0f, 1.0f )*/
) : CEntity( playerTemplate, UID, name, position, rotation, scale )
{
	m_PlayerTemplate = playerTemplate;

	// Initialise other player data
	m_HP = m_PlayerTemplate->GetMaxHP();
	m_Score = 0;
	m_CurrentBuilding = 0;
	m_StockUpTime = 2.0f;
	m_State = Inactive;
}


// Update the player - controls its behaviour.
// Return false if the entity is to be destroyed
bool CPlayerEntity::Update( TFloat32 updateTime )
{
	//********************************************************/
	// Message handling
	//********************************************************/
	// Fetch any messages. The Messenger class handles the collection and delivery - we just enter
	// a loop collecting any pending messages, acting accordingly
	SMessage msg;
	while (Messenger.FetchMessage( GetUID(), &msg ))
	{
		// Update player state based on messages received
		switch (msg.type)
		{
			// Start message: starts the game - the player enters run state
			case Msg_Start:
				m_State = Run;
				m_StockUpTime = 2.0f; // Reset stock up timer
				break;

			// Hit message: the player loses some HP, and dies if HP < 0
			case Msg_Hit:
				/*****MISSING - lose HP depending on value sent in message */
				if (m_HP <= 0)
				{
					// Player has died, return false - the entity manager will take care of removing it
					return false;
				}
				break;

			// Stop message: the game stops, the player becomes inactive
			case Msg_Stop:
				m_State = Inactive;
				break;
		}
	}

	//********************************************************/
	// Player state & movement
	//********************************************************/

	// See if player has reached current building
	CEntity* building0 = 0;/*****MISSING - not 0, Use the entity manager to get the CEntity* for */
	CEntity* building1 = 0;/*              each building. See the example at the top of the file */
						   /*              MonsterEntity.cpp. Find the building names in EntityIntro.cpp */
	                       /*              Uncomment code below when done */
	//if ((m_CurrentBuilding == 0 && Distance( Position(), building0->Position() ) < 10.0f) || 
	//    (m_CurrentBuilding == 1 && Distance( Position(), building1->Position() ) < 10.0f))
	//{
	//	// Gain 10 HP & 1 score
	//	m_HP += 10;
	//	if (m_HP > m_PlayerTemplate->GetMaxHP())
	//	{
	//		m_HP = m_PlayerTemplate->GetMaxHP();
	//	}
	//	m_Score = m_Score + 1;

	//	// Switch current building then enter StockUp state
	//	m_CurrentBuilding = 1 - m_CurrentBuilding;
	//	m_State = StockUp;
	//}
	
	// Stock-up state: cannot move for a fixed period of time
	if (m_State == StockUp)
	{
		// Countdown stock-up time until 0, then switch back to run state
		m_StockUpTime -= updateTime;
		if (m_StockUpTime <= 0.0f)
		{
			m_StockUpTime = 2.0f;
			m_State = Run;
		}
	}

	// Run state: movement allowed
	else if (m_State == Run)
	{
		// Local movement, backward and sideward movement is slower than forwards
		if (KeyHeld( Key_W ))
		{
			Matrix().MoveLocalZ( m_PlayerTemplate->GetMaxSpeed() * updateTime );
		}
		if (KeyHeld( Key_S ))
		{
			Matrix().MoveLocalZ( -m_PlayerTemplate->GetMaxSpeed() * 0.5f * updateTime );
		}
		if (KeyHeld( Key_A ))
		{
			Matrix().MoveLocalX( -m_PlayerTemplate->GetMaxSpeed() * 0.5f * updateTime );
		}
		if (KeyHeld( Key_D ))
		{
			Matrix().MoveLocalX( m_PlayerTemplate->GetMaxSpeed() * 0.5f * updateTime );
		}

		// Don't allow movement outside the area
		if (Position().x < -35.0f) Position().x = -35.0f;
		if (Position().x > 35.0f) Position().x = 35.0f;
		if (Position().z < -45.0f) Position().z = -45.0f;
		if (Position().z > 45.0f) Position().z = 45.0f;
	}

	// Can rotate in any state
	if (KeyHeld( Key_Right ))
	{
		Matrix().RotateY( ToRadians(90.0f) * updateTime );
	}
	if (KeyHeld( Key_Left ))
	{
		Matrix().RotateY( -ToRadians(90.0f) * updateTime );
	}

	// Only return false when this entity has died
	return true; 
}


} // namespace gen
