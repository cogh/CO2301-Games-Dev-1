/*******************************************
	EntityIntro.cpp

	Shell scene and game functions
********************************************/

#include <sstream>
#include <string>
using namespace std;

#include <d3d9.h>
#include <d3dx9.h>

#include "Defines.h"
#include "CVector3.h"
#include "Camera.h"
#include "Light.h"
#include "EntityManager.h"
#include "Messenger.h"
#include "EntityIntro.h"

namespace gen
{

//-----------------------------------------------------------------------------
// Game / scene constants
//-----------------------------------------------------------------------------

// Control speed
const float CameraRotSpeed = 2.0f;
float CameraMoveSpeed = 40.0f;


//-----------------------------------------------------------------------------
// Global system variables
//-----------------------------------------------------------------------------

// Get reference to global DirectX variables from another source file
extern LPDIRECT3DDEVICE9 g_pd3dDevice;
extern LPD3DXFONT        g_pFont;

// Actual viewport dimensions (fullscreen or windowed)
extern TUInt32 ViewportWidth;
extern TUInt32 ViewportHeight;

// Current mouse position
extern TInt32 MouseX;
extern TInt32 MouseY;

// Messenger class for sending messages to and between entities
extern CMessenger Messenger;


//-----------------------------------------------------------------------------
// Global game/scene variables
//-----------------------------------------------------------------------------

// Entity manager
CEntityManager EntityManager;

// Entity UIDs
const int NumMonsters = 7;
TEntityUID Monsters[NumMonsters];
TEntityUID Player;

// Other scene elements
const int NumLights = 1;
SColourRGBA AmbientLight;
CLight* Lights[NumLights];
CCamera* MainCamera;


//-----------------------------------------------------------------------------
// Scene management
//-----------------------------------------------------------------------------

// Creates the scene geometry
bool SceneSetup()
{
	//////////////////////////////////////////
	// Create scenery templates and entities

	// Create scenery templates (equivalent of meshes)
	// Template type, template name, mesh name
	EntityManager.CreateTemplate( "Scenery", "Skybox", "Skybox.x" );
	EntityManager.CreateTemplate( "Scenery", "Floor", "Floor.x" );
	EntityManager.CreateTemplate( "Scenery", "Building", "Building.x" );
	EntityManager.CreateTemplate( "Scenery", "Tree", "Tree.x" );

	// Creates scenery entities (equivalent of models)
	// Type (template name), entity name, position, rotation, scale
	EntityManager.CreateEntity( "Skybox", "Skybox", CVector3(0.0f, -1000.0f, 0.0f) );
	EntityManager.CreateEntity( "Floor", "Floor" );
	EntityManager.CreateEntity( "Building", "Building0", CVector3(-20.0f, 0.0f, -40.0f),
	                                                     CVector3(0.0f, ToRadians(180.0f), 0.0f) );
	EntityManager.CreateEntity( "Building", "Building1", CVector3(20.0f, 0.0f, 40.0f) );

	for (int tree = 0; tree < 50; ++tree)
	{
		EntityManager.CreateEntity( "Tree", "Tree", 
		                            CVector3(Random( -40.0f, 40.0f ), 0.0f, Random(50.0f, 80.0f) ), 
									CVector3(0.0f, Random(0.0f, ToRadians(360.0f)), 0.0f ) );
		EntityManager.CreateEntity( "Tree", "Tree", 
		                            CVector3(Random( -40.0f, 40.0f ), 0.0f, Random(-80.0f, -50.0f) ), 
									CVector3(0.0f, Random(0.0f, ToRadians(360.0f)), 0.0f ) );
		EntityManager.CreateEntity( "Tree", "Tree", 
		                            CVector3(Random( -70.0f, -40.0f ), 0.0f, Random(-80.0f, 80.0f) ), 
									CVector3(0.0f, Random(0.0f, ToRadians(360.0f)), 0.0f ) );
		EntityManager.CreateEntity( "Tree", "Tree", 
		                            CVector3(Random( 40.0f, 70.0f ), 0.0f, Random(-80.0f, 80.0f) ), 
									CVector3(0.0f, Random(0.0f, ToRadians(360.0f)), 0.0f ) );
	}

	
	/////////////////////////////////
	// Create entity templates

	// Monster/player templates (equivalent of meshes, but with embedded game data)
	// Template type, template name, mesh name, speed, max HP and hit damage
	EntityManager.CreateMonsterTemplate( "NPC",   "Orc Basher",  "Troll1.x",  14.0f, 200, 20 );
	EntityManager.CreateMonsterTemplate( "NPC",   "Orc Speeder", "Troll3.x",  16.0f, 100,  5 );
	EntityManager.CreatePlayerTemplate( "Player", "Human",       "Soldier.x", 18.0f, 150, 10 );


	////////////////////////////////
	// Create entities

	// Monster/player entities (equivalent of models, but with embedded game data)
	// Type (template name), monster name, position
	Monsters[0] = EntityManager.CreateMonster( "Orc Basher", "Oberg",  CVector3(-30.0f, 0.0f, -20.0f) );
	Monsters[1] = EntityManager.CreateMonster( "Orc Basher", "Kadish", CVector3(-10.0f, 0.0f, -20.0f) );
	Monsters[2] = EntityManager.CreateMonster( "Orc Basher", "Brug",   CVector3( 10.0f, 0.0f, -20.0f) );
	Monsters[3] = EntityManager.CreateMonster( "Orc Basher", "Gark",   CVector3( 30.0f, 0.0f, -20.0f) );
	Monsters[4] = EntityManager.CreateMonster( "Orc Speeder", "Dom",   CVector3(-15.0f, 0.0f, -10.0f) );
	Monsters[5] = EntityManager.CreateMonster( "Orc Speeder", "Runt",  CVector3(  0.0f, 0.0f, -10.0f) );
	Monsters[6] = EntityManager.CreateMonster( "Orc Speeder", "Vida",  CVector3( 15.0f, 0.0f, -10.0f) );
	// Need to increase NumMonsters near top of file if you want to add more monsters

	Player = EntityManager.CreatePlayer( "Human", "Player",  CVector3( 0.0f, 0.0f, 20.0f),
	                                                         CVector3(0.0f, ToRadians(180.0f), 0.0f) );


	/////////////////////////////
	// Camera / light setup

	// Set camera position and clip planes
	MainCamera = new CCamera( CVector3( 0.0f, 30.0f, -100.0f ),
	                          CVector3(ToRadians(15.0f), 0, 0) );
	MainCamera->SetNearFarClip( 0.1f, 10000.0f ); 


	// Ambient light level
	AmbientLight = SColourRGBA( 0.6f, 0.6f, 0.6f, 1.0f );

	// Sunlight
	Lights[0] = new CLight( CVector3( -1000.0f, 800.0f, -2000.0f),
	                        SColourRGBA(1.0f, 0.9f, 0.2f), 4000.0f );

	// Set light information for render methods
	SetAmbientLight( AmbientLight );
	SetLights( &Lights[0] );

	return true;
}


// Release everything in the scene
void SceneShutdown()
{
	// Release render methods
	ReleaseMethods();

	// Release lights
	for (int light = NumLights - 1; light >= 0; --light)
	{
		delete Lights[light];
	}

	// Release camera
	delete MainCamera;

	// Destroy all entities / templates
	EntityManager.DestroyAllEntities();
	EntityManager.DestroyAllTemplates();
}


//-----------------------------------------------------------------------------
// Game loop functions
//-----------------------------------------------------------------------------

// Draw one frame of the scene
void RenderScene( float updateTime )
{
    // Begin the scene
    if (SUCCEEDED(g_pd3dDevice->BeginScene()))
    {
		// Clear the z buffer & stencil buffer - no need to clear back-buffer 
		// as the skybox will always fill the background
		g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0, 1.0f, 0 );

		// Prepare camera
		MainCamera->CalculateMatrices();

		// Render all entities
		EntityManager.RenderAllEntities( MainCamera );

		// Draw on-screen text
		RenderSceneText( updateTime );

		// End the scene
        g_pd3dDevice->EndScene();
    }

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}


// Render a single text string at the given position in the given colour, may optionally centre it
void RenderText( const string& text, int X, int Y, float r, float g, float b, bool centre = false )
{
	RECT rect;
	if (!centre)
	{
		SetRect( &rect, X, Y, 0, 0 );
		g_pFont->DrawText( NULL, text.c_str(), -1, &rect, DT_NOCLIP, D3DXCOLOR( r, g, b, 1.0f ) );
	}
	else
	{
		SetRect( &rect, X - 100, Y, X + 100, 0 );
		g_pFont->DrawText( NULL, text.c_str(), -1, &rect, 
		                   DT_CENTER | DT_NOCLIP, D3DXCOLOR( r, g, b, 1.0f ) );
	}
}

// Render on-screen text each frame
void RenderSceneText( float updateTime )
{
	// Write FPS text string
	stringstream outText;
	outText << "Frame Time: " << updateTime * 1000.0f << "ms" << endl << "FPS:" << 1.0f / updateTime;
	RenderText( outText.str(), 0, 0, 1.0f, 1.0f, 0.0f );
	outText.str("");

	// Write type, name & state next to each monster
	for (int i = 0; i < NumMonsters; ++i)
	{
		// Get monster entity (ensure it exists), then its world position
		CEntity* entity = EntityManager.GetEntity( Monsters[i] );
		if (entity)
		{
			CMonsterEntity* monsterEntity = static_cast<CMonsterEntity*>( entity );
			CVector3 monsterPt = monsterEntity->Position();

			// Convert monster world position to pixel coordinate (picking in Camera class)
			int X, Y;
			if (MainCamera->PixelFromWorldPt( monsterPt, ViewportWidth, ViewportHeight, &X, &Y ))
			{
				// Only output text if monster is visible
				outText << monsterEntity->Template()->GetName().c_str() << ": " 
				        << monsterEntity->GetName().c_str();
				RenderText( outText.str(), X, Y, 1.0f, 0.6f, 0.6f, true );
				outText.str("");
				outText << monsterEntity->GetState().c_str();
				RenderText( outText.str(), X, Y + 8, 1.0f, 0.6f, 0.6f, true );
				outText.str("");
			}
		}
	}

	// Similar process for player
	CEntity* entity = EntityManager.GetEntity( Player );
	if (entity)
	{
		CPlayerEntity* playerEntity = static_cast<CPlayerEntity*>( entity );
		CVector3 playerPt = playerEntity->Position();

		// Convert monster world position to pixel coordinate (picking in Camera class)
		int X, Y;
		if (MainCamera->PixelFromWorldPt( playerPt, ViewportWidth, ViewportHeight, &X, &Y ))
		{
			// Only output text if monster is visible
			outText << playerEntity->Template()->GetName().c_str() << ": " 
			        << playerEntity->GetName().c_str();
			RenderText( outText.str(), X, Y, 0.6f, 0.6f, 1.0f, true );
			outText.str("");
			outText << playerEntity->GetState().c_str();
			RenderText( outText.str(), X, Y + 8, 0.6f, 0.6f, 1.0f, true );
			outText.str("");
			outText << playerEntity->GetHP() << "HP  Score " << playerEntity->GetScore();
			RenderText( outText.str(), X, Y + 16, 0.6f, 0.6f, 1.0f, true );
			outText.str("");
		}
	}
}


// Update the scene between rendering
void UpdateScene( float updateTime )
{
	// Call all entity update functions
	EntityManager.UpdateAllEntities( updateTime );

	// Start / stop - send message to all monsters and player
	if (KeyHit( Key_1 )) 
	{
		SMessage msg;
		msg.type = Msg_Start;
		msg.from = SystemUID;
		for (int i = 0; i < NumMonsters; ++i)
		{
			Messenger.SendMessage( Monsters[i], msg );
		}
		Messenger.SendMessage( Player, msg );
	}
	if (KeyHit( Key_2 )) 
	{
		SMessage msg;
		msg.type = Msg_Stop;
		msg.from = SystemUID;
		for (int i = 0; i < NumMonsters; ++i)
		{
			Messenger.SendMessage( Monsters[i], msg );
		}
		Messenger.SendMessage( Player, msg );
	}

	// Set camera speeds
	// Key F1 used for full screen toggle
	if (KeyHit( Key_F2 )) CameraMoveSpeed = 5.0f;
	if (KeyHit( Key_F3 )) CameraMoveSpeed = 40.0f;

	// Set the camera to chase player (if alive)
	CEntity* player = EntityManager.GetEntity( Player );
	if (player)
	{
		// Take camera position from player, moved backwards and upwards
		MainCamera->Position() = player->Position() - player->Matrix().ZAxis() * 12.0f +
		                                              player->Matrix().YAxis() * 5.0f;
		// Face camera towards point above player
		MainCamera->Matrix().FaceTarget( player->Position() + CVector3(0, 3.0f, 0) );
	}
	else
	{
		// Player is dead - free camera
		MainCamera->Control( Key_Up, Key_Down, Key_Left, Key_Right, Key_W, Key_S, Key_A, Key_D, 
		                     CameraMoveSpeed * updateTime, CameraRotSpeed * updateTime );
	}
}


} // namespace gen
