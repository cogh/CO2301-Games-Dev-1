/**********************************************
	Model.cpp

	Implementation of model class for DirectX
***********************************************/

/***| INFO |**************************************************************************
// For a multi-part model, we create a hierarchy of models with a single root.
// An imported mesh has a depth-first node list as described in the lecture.
// However, it has a *seperate* sub-mesh list - a list of geometry pieces, each
// attached to a single hierarchy node. This means that each node can have zero,
// one, or many pieces of geometry attached. A node with no sub-meshes is just
// helping define the hierachy (e.g. a common invisible node to control several
// visible pieces of geometry - game students recall dummy models from TL work).
// A node may have several sub-meshes if it uses multiple materials / textures.
// Ignoring this second case here - assuming zero or one sub-mesh per node. See
// the section marked "Model Hierarchy" below
*************************************************************************************/

#include "Defines.h"
#include "Model.h"

///////////////////////////////
// Constructors / Destructors

// Model constructor
CModel::CModel()
{
	// Initialise member variables
	m_VertexBuffer = NULL;
	m_NumVertices = 0;
	m_VertexSize = 0;
	m_pVertexDeclaration = NULL;
	m_VertexFVF = 0;

	m_IndexBuffer = NULL;
	m_NumIndices = 0;

	m_HasGeometry = false;

	m_Position = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	m_Rotation = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	m_Scale = 1.0f;

	m_NumChildren = 0;
}

// Model destructor
CModel::~CModel()
{
	ReleaseResources();
}

// Release resources used by model
void CModel::ReleaseResources()
{
	// Delete any child models
	for (int child = 0; child < m_NumChildren; ++child)
	{
		delete m_Children[child];
	}
	m_NumChildren = 0;

	// Using a DirectX helper macro to simplify code here - look it up in Defines.h
	SAFE_RELEASE( m_IndexBuffer );
	SAFE_RELEASE( m_VertexBuffer );
	SAFE_RELEASE( m_pVertexDeclaration );
	m_HasGeometry = false;
}


/////////////////////////////
// Model Loading / Creation

// Create the model geometry from arrays of vertices and indices. To describe the elements in
// a vertex (position, normal etc.) can pass an FVF code (legacy style) or pointer to vertex
// element structures (shader style). Pass a 0 FVF code if using the vertex element structures
bool CModel::CreateGeometry
(
	void*        vertices,         // Pointer to vertex array (void* because we allow custom types)
	unsigned int numVertices,      // Number of vertices in the model mesh
	DWORD              vertexFVF,  // DirectX FVF code describing the vertex format (0 if not using)
	D3DVERTEXELEMENT9* vertexElts, // Array of vertex elements describing the vertex format
	WORD*        indices,          // Pointer to index array (assuming 2-byte values, WORD in DirectX)
	unsigned int numIndices        // Number of indices in the model mesh
)
{
	// Release any existing geometry
	ReleaseResources();

	// Passed FVF or vertex elements?
	if (vertexFVF)
	{
		// Store FVF (vertex format descriptor) and use it to get size of a single vertex
		m_VertexFVF = vertexFVF;
		m_VertexSize = D3DXGetFVFVertexSize( m_VertexFVF );

		// Get vertex declaration from FVF
		D3DXDeclaratorFromFVF( m_VertexFVF, m_VertexElts ); // DirectX helper function for this
	}
	else
	{
		// Copy vertex element list and use it to get size of a single vertex
		int elt = 0;
		while (vertexElts[elt].Stream != 0xff)
		{
			memcpy( &m_VertexElts[elt], &vertexElts[elt], sizeof(D3DVERTEXELEMENT9) );
			++elt;
		}
		memcpy( &m_VertexElts[elt], &vertexElts[elt], sizeof(D3DVERTEXELEMENT9) );
		m_VertexSize = D3DXGetDeclVertexSize( m_VertexElts, 0 );

		// Get vertex FVF - a description of vertex elements when not using shaders
		// This line is not needed when using shaders, and can cause warnings, so commented out
//		D3DXFVFFromDeclarator( m_VertexElts, &m_VertexFVF ); // DirectX helper function for this
	}
	g_pd3dDevice->CreateVertexDeclaration( m_VertexElts, &m_pVertexDeclaration );


	// Create the vertex buffer
	unsigned int bufferSize = numVertices * m_VertexSize;
    if (FAILED(g_pd3dDevice->CreateVertexBuffer( bufferSize, D3DUSAGE_WRITEONLY, 0,
                                                 D3DPOOL_DEFAULT, &m_VertexBuffer, NULL )))
    {
        return false;
    }
	m_NumVertices = numVertices;

    // "Lock" the vertex buffer so we can write to it
    void* bufferData;
    if (FAILED(m_VertexBuffer->Lock( 0, bufferSize, (void**)&bufferData, 0 )))
	{
        return false;
	}

	// Copy the vertex data
    memcpy( bufferData, vertices, bufferSize );

	// Unlock the vertex buffer again so it can be used for rendering
    m_VertexBuffer->Unlock();


    // Create the index buffer - assuming 2-byte (WORD) index data
	bufferSize = numIndices * sizeof(WORD);
    if (FAILED(g_pd3dDevice->CreateIndexBuffer( bufferSize, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                                D3DPOOL_DEFAULT, &m_IndexBuffer, NULL )))
    {
        return false;
    }
	m_NumIndices = numIndices;

    // "Lock" the index buffer so we can write to it
    if (FAILED(m_IndexBuffer->Lock( 0, bufferSize, (void**)&bufferData, 0 )))
	{
        return false;
	}

	// Copy the index data
    memcpy( bufferData, indices, bufferSize );

	// Unlock the index buffer again so it can be used for rendering
    m_IndexBuffer->Unlock();

	m_HasGeometry = true;
	return true;
}


// Load the model geometry from a file. If given a hierarchical model, will generate
// child models as appropriate. This model class only supports a single material per
// model. Real world models often use several materials for different parts of the
// geometry. This function only reads the geometry using the first material in the
// file, so multi-material models will load but will have parts missing
bool CModel::Load( const string& fileName )
{
	// Use CImportXFile class (from another application) to load the given file
	// The import code is wrapped in the namespace 'gen'
	gen::CImportXFile mesh;
	if (mesh.ImportFile( fileName.c_str() ) != gen::kSuccess)
	{
		return false;
	}

	// If only one sub-mesh create a non-hierarchical model
	if (mesh.GetNumSubMeshes() == 1)
	{
		// Just use first sub-mesh from loaded file
		gen::SSubMesh subMesh;
		if (mesh.GetSubMesh( 0, &subMesh ) != gen::kSuccess)
		{
			return false;
		}
		if (!CreateFromSubMesh( &subMesh ))
		{
			ReleaseResources();
			return false;
		}
		return true;
	}


	//*************************************
	// Model Hierarchy
	//*************************************
	// Multi-part model - create a hierarchy of models with this as the root

	// Array of model ptrs for each node - in the imported data the first node defines
	// the parent of the model root so is set to null (root has no parent)
	CModel** nodeModels = new CModel*[mesh.GetNumNodes()];
	nodeModels[0] = 0;

	// Walk through nodes (ignoring first one - root's parent) and meshes. Create a
	// model for every node, but only create geometry for a node if it is referenced
	// by a mesh. Result is a correct hierarchy of models, but with some models having
	// no geometry in them. If a node has multiple sub-meshes, only one is used
	unsigned int currMesh = 0; // First mesh
	for (unsigned int node = 1; node < mesh.GetNumNodes(); ++node) // For each node...
	{
		gen::SMeshNode meshNode;
		mesh.GetNode( node, &meshNode );

		// Create a new model for all except the first node (the root - this object - already created)
		CModel* pNodeModel;
		if (node == 1)
		{
			pNodeModel = this;
		}
		else
		{
			// Attach new model to (already created) parent model
			CModel* pParent = nodeModels[meshNode.parent];
			pNodeModel = pParent->CreateNewChild();
		}
		nodeModels[node] = pNodeModel;

		// Get initial position and rotation for model from node matrix
		// Using helper maths classes provided with import code
		gen::CVector3 position, rotation, scale;
		meshNode.positionMatrix.DecomposeAffineEuler( &position, &rotation, &scale );
		pNodeModel->SetPosition( position.x, position.y, position.z );
		pNodeModel->SetRotation( rotation.x, rotation.y, rotation.z );
		pNodeModel->SetScale( (scale.x + scale.y + scale.z) / 3.0f ); // Using single scale value - use average

		// If this node is refered by next sub-mesh, then it has geometry
		if (currMesh < mesh.GetNumSubMeshes())
		{
			gen::SSubMesh subMesh;
			if (mesh.GetSubMesh( currMesh, &subMesh ) != gen::kSuccess)
			{
				ReleaseResources();
				delete[] nodeModels;
				return false;
			}
			if (subMesh.node == node)
			{
				// Create the geometry for this node
				if (!pNodeModel->CreateFromSubMesh( &subMesh ))
				{
					ReleaseResources();
					delete[] nodeModels;
					return false;
				}

				// Skip over any additional sub-meshes using this node - not allowing multi-material nodes
				++currMesh;
				while (currMesh < mesh.GetNumSubMeshes())
				{
					gen::SSubMesh subMesh;
					if (mesh.GetSubMesh( currMesh, &subMesh ) != gen::kSuccess)
					{
						ReleaseResources();
						delete[] nodeModels;
						return false;
					}
					if (subMesh.node != node) break;
					++currMesh;
				} 
			}
		}
	}
	delete[] nodeModels;

	return true;
}


// Create this model using a CMesh class sub-mesh. Helper function for LoadModel above
bool CModel::CreateFromSubMesh( const gen::SSubMesh* subMesh )
{
	// Release any existing geometry
	ReleaseResources();

	// Create vertex element list & declaration
	unsigned int iElt = 0;
	unsigned int iOffset = 0;
	m_VertexElts[iElt].Stream = 0;
	m_VertexElts[iElt].Offset = iOffset;
	m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT3;
	m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
	m_VertexElts[iElt].Usage = D3DDECLUSAGE_POSITION;
	m_VertexElts[iElt].UsageIndex = 0;
	iOffset += 12;
	++iElt;
	if (subMesh->hasNormals)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT3;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_NORMAL;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 12;
		++iElt;
	}
	if (subMesh->hasTangents)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT3;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_TANGENT;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 12;
		++iElt;
	}
	if (subMesh->hasTextureCoords)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT2;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_TEXCOORD;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 8;
		++iElt;
	}
	if (subMesh->hasVertexColours)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_D3DCOLOR;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_COLOR;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 4;
		++iElt;
	}
	D3DVERTEXELEMENT9 endElt = D3DDECL_END();
	memcpy( &m_VertexElts[iElt], &endElt, sizeof(D3DVERTEXELEMENT9) );
	m_VertexSize = D3DXGetDeclVertexSize( m_VertexElts, 0 );
	g_pd3dDevice->CreateVertexDeclaration( m_VertexElts, &m_pVertexDeclaration );

	// Get vertex FVF - a description of vertex elements when not using shaders
	// This line is not needed when using shaders, and can cause warnings, so commented out
//	D3DXFVFFromDeclarator( m_VertexElts, &m_VertexFVF ); // DirectX helper function for this

	// Create the vertex buffer
	m_NumVertices = subMesh->numVertices;
	unsigned int bufferSize = m_NumVertices * m_VertexSize;
    if (FAILED(g_pd3dDevice->CreateVertexBuffer( bufferSize, D3DUSAGE_WRITEONLY, 0,
                                                 D3DPOOL_DEFAULT, &m_VertexBuffer, NULL )))
    {
        return false;
    }

    // "Lock" the vertex buffer so we can write to it
    void* bufferData;
    if (FAILED(m_VertexBuffer->Lock( 0, bufferSize, (void**)&bufferData, 0 )))
	{
        return false;
	}

	// Copy the vertex data from the sub-mesh
	memcpy( bufferData, subMesh->vertices, bufferSize );

	// Unlock the vertex buffer again so it can be used for rendering
    m_VertexBuffer->Unlock();


    // Create the index buffer - assuming 2-byte (WORD) index data
	m_NumIndices = static_cast<unsigned int>(subMesh->numFaces) * 3;
	bufferSize = m_NumIndices * sizeof(WORD);
    if (FAILED(g_pd3dDevice->CreateIndexBuffer( bufferSize, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                                D3DPOOL_DEFAULT, &m_IndexBuffer, NULL )))
    {
        return false;
    }

    // "Lock" the index buffer so we can write to it
    if (FAILED(m_IndexBuffer->Lock( 0, bufferSize, (void**)&bufferData, 0 )))
	{
        return false;
	}

	// Copy the vertex data from the sub-mesh
	memcpy( bufferData, subMesh->faces, bufferSize );

	// Unlock the index buffer again so it can be used for rendering
    m_IndexBuffer->Unlock();

	m_HasGeometry = true;
	return true;
}


/////////////////////////////
// Model Usage

// Calculate the model's world matrix from its current position, orientation and scale
// Don't send matrix to DirectX (with SetTransform) as using a vertex shader for matrix work
void CModel::CalculateMatrix()
{
	// Build the matrix for the model from its position, rotation and scaling
	D3DXMATRIXA16 MatScale, MatRotX, MatRotY, MatRotZ, MatTrans;
	D3DXMatrixScaling( &MatScale, m_Scale, m_Scale, m_Scale );
	D3DXMatrixRotationX( &MatRotX, m_Rotation.x );
	D3DXMatrixRotationY( &MatRotY, m_Rotation.y );
	D3DXMatrixRotationZ( &MatRotZ, m_Rotation.z );
	D3DXMatrixTranslation( &MatTrans, m_Position.x, m_Position.y, m_Position.z );
	m_Matrix = MatScale * MatRotZ * MatRotX * MatRotY * MatTrans;
}

// Render the model (using current material)
void CModel::Render()
{
	// Don't render if no geometry
	if (!m_HasGeometry)
	{
		return;
	}

	// Tell DirectX the vertex buffer to use and indicate its type (using the FVF code)
	g_pd3dDevice->SetStreamSource( 0, m_VertexBuffer, 0, m_VertexSize );
	g_pd3dDevice->SetVertexDeclaration( m_pVertexDeclaration ); // When using shaders
	//g_pd3dDevice->SetFVF( m_VertexFVF ); // Legacy style of above line

	// Now tell DirectX the index buffer to use
	g_pd3dDevice->SetIndices( m_IndexBuffer );


	// Draw the primitives from the vertex buffer - a triangle list
	g_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,  // Primitive type - usually tri-list or strip
										0,                   // Offset to add to all indices (0 in simple cases)
										0,                   // Minimum index used (allows for optimisation) 
										m_NumVertices,       // Range of vertices refered to, effectively =
															 //     maximum index - minimum index + 1
										0,                   // Position to start at in index buffer
										m_NumIndices / 3 );  // Number of primitives to render (triangles)
}


// Control the model using keys
void CModel::Control( EKeyCode turnUp, EKeyCode turnDown,
					  EKeyCode turnLeft, EKeyCode turnRight,  
					  EKeyCode turnCW, EKeyCode turnCCW,
					  EKeyCode moveForward, EKeyCode moveBackward )
{
	if (KeyHeld( turnDown ))
	{
		m_Rotation.x += RotSpeed;
	}
	if (KeyHeld( turnUp ))
	{
		m_Rotation.x -= RotSpeed;
	}
	if (KeyHeld( turnRight ))
	{
		m_Rotation.y += RotSpeed;
	}
	if (KeyHeld( turnLeft ))
	{
		m_Rotation.y -= RotSpeed;
	}
	if (KeyHeld( turnCW ))
	{
		m_Rotation.z += RotSpeed;
	}
	if (KeyHeld( turnCCW ))
	{
		m_Rotation.z -= RotSpeed;
	}

	// Local Z movement - move in the direction of the Z axis, get axis from world matrix
	if (KeyHeld( moveForward ))
	{
		m_Position.x += m_Matrix._31 * MoveSpeed;
		m_Position.y += m_Matrix._32 * MoveSpeed;
		m_Position.z += m_Matrix._33 * MoveSpeed;
	}
	if (KeyHeld( moveBackward ))
	{
		m_Position.x -= m_Matrix._31 * MoveSpeed;
		m_Position.y -= m_Matrix._32 * MoveSpeed;
		m_Position.z -= m_Matrix._33 * MoveSpeed;
	}
}


