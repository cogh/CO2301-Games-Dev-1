/*********************************************
	ParticleSystem.cpp

	Developing simple particle-based systems
**********************************************/

#include <string>
#include <list>
using namespace std;

// General definitions used across all the project source files
#include "Defines.h"

// Declarations for supporting source files
#include "Model.h"    // Model class
#include "Camera.h"   // Camera class
#include "Shader.h"   // Vertex / pixel shader support
#include "Input.h"    // Input support

#include "Resource.h" // Resource file (used to add icon for application)


//-----------------------------------------------------------------------------
// Particle Structures
//-----------------------------------------------------------------------------

//*********************************************
// Data and code to be added here for tutorial

struct Particle
{
	// Content to be added
};

// List of particles in the particle system
list<Particle> Particles;

// Further data / functions to be added here



//-----------------------------------------------------------------------------
// Constants
//-----------------------------------------------------------------------------

const D3DXCOLOR BackgroundColour( 0.5f, 0.5f, 0.5f, 1.0f );

// Move / rotation speed constants in Defines.h


//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------

// DirectX interface
LPDIRECT3D9        g_pD3D       = 0;        // Used to create the D3DDevice
LPDIRECT3DDEVICE9  g_pd3dDevice = 0;        // Our rendering device

// Viewport width and height
int ViewportWidth;
int ViewportHeight;

// Cameras
CCamera* MainCamera;

// Models
CModel* ParticleModel  = 0;
CModel* GroundModel = 0;

// Textures for models
LPDIRECT3DTEXTURE9 GroundTexture;

// Lights
const int   NumLights = 2;
CModel*     LightModels[NumLights];     // Each light has a model attached in this exercise
D3DXCOLOR   AmbientColour;              // Background light level
D3DXVECTOR3 LightPositions[NumLights];  // Point light positions
D3DXCOLOR   LightColours[NumLights];    // Point light colours
float       LightBrightness[NumLights]; // Point light brightness
float       SpecularPower = 256.0f;     // Specular power (shininess) of materials,
                                        // same for all models in this exercise
const float LightOrbit = 50.0f; // Controls orbiting light
const float LightSpeed = 0.75f;  // -"-

// Shader variables, more shaders in this example
LPDIRECT3DVERTEXSHADER9 VS_XformOnly,         VS_LightingTex;
LPD3DXCONSTANTTABLE     VS_XformOnlyConsts,   VS_LightingTexConsts;
LPDIRECT3DPIXELSHADER9  PS_PlainColour,       PS_LightingTex;
LPD3DXCONSTANTTABLE     PS_PlainColourConsts, PS_LightingTexConsts;
                                                   

//-----------------------------------------------------------------------------
// Light functions
//-----------------------------------------------------------------------------

// Initialise a light model for each light in the scene
bool InitialiseLightModels()
{
	for (int light = 0; light < NumLights; ++light)
	{
		LightModels[light] = new CModel();
		if (!LightModels[light]->Load( "Sphere.x" ))
		{
			return false;
		}
		LightModels[light]->SetScale( 0.3f );
	}
	return true;
}

// Release light models
void UninitialiseLightModels()
{
	for (int light = 0; light < NumLights; ++light)
	{
		delete LightModels[light];
	}
}

// Set the ambient colour for the whole scene
void SetAmbientColour( float r, float g, float b )
{
	AmbientColour = D3DXCOLOR( r, g, b, 1.0f );
}


// Create a point light given position, colour and brightness
void SetPointLight( int lightNum,  float posX, float posY, float posZ,  float r, float g, float b,
                    float bright )
{
	LightPositions[lightNum] = D3DXVECTOR3( posX, posY, posZ );
	LightColours[lightNum] = D3DXCOLOR( r, g, b, 1.0f );
	LightModels[lightNum]->SetPosition( posX, posY, posZ );
	LightBrightness[lightNum] = bright;
}


// Set the given point light's position only
void SetPointLightPos( int lightNum,  float x, float y, float z )
{
	LightPositions[lightNum] = D3DXVECTOR3( x, y, z );
	LightModels[lightNum]->SetPosition( x, y, z ); // Match light model position to light
}


//-----------------------------------------------------------------------------
// Texture functions
//-----------------------------------------------------------------------------

// Load a texture
LPDIRECT3DTEXTURE9 LoadTexture( const string& fileName )
{
    LPDIRECT3DTEXTURE9 texture = 0;
    
	// Create the texture
	if (FAILED(D3DXCreateTextureFromFile( g_pd3dDevice, fileName.c_str(), &texture )))
    {
		MessageBox(NULL, "Could not find texture map", "CO2409 Lab 23: Particle Systems", MB_OK);
    }

	return texture;
}

// Set a texture to use for subsequent rendering
// Can select which texture to set - for shaders that use multiple textures
void SetTexture( int textureNum, LPDIRECT3DTEXTURE9 texture )
{
    g_pd3dDevice->SetTexture( textureNum, texture );
}


//-----------------------------------------------------------------------------
// Scene management
//-----------------------------------------------------------------------------

// Creates the scene geometry
bool SceneSetup()
{
	// Create camera
	MainCamera = new CCamera();
	MainCamera->SetPosition( 90.0f, 60.0f, 90.0f );
	MainCamera->SetRotation( ToRadians(12.0f), ToRadians(-125.0f), 0.0f );

	// Load models from files
	ParticleModel = new CModel;
	GroundModel = new CModel;
	if (!GroundModel->Load( "Hills.x" ) || !ParticleModel->Load( "Cube.x" ))
	{
		return false;  // Return on failure
	}
	GroundModel->SetPosition( -40, 0, 0 );
	ParticleModel->SetScale( 0.1f );

	// Load textures to apply to models
	GroundTexture = LoadTexture( "GrassDiffuseSpecular.tga" );
	if (!GroundTexture)
	{
		return false;
	}
 	
	// Create lights
	if (!InitialiseLightModels())
	{
		return false;
	}
	SetAmbientColour( 0.4f, 0.4f, 0.4f );
	SetPointLight( 0,  LightOrbit, 35.0f, 0.0f,   1.0f, 1.0f, 1.0f,  10.0f );
	SetPointLight( 1,  -60.0f,     60.0f, 60.0f,  1.0f, 0.9f, 0.2f,  100.0f );

	// Load and compile shaders. Two shader pairs here, a pixel lighting effect for the main 
	// models and a simple plain colour effect for the light models
	if (!LoadVertexShader( "XformOnly.vsh", &VS_XformOnly, &VS_XformOnlyConsts ) ||
	    !LoadVertexShader( "PixelLitTex.vsh", &VS_LightingTex, &VS_LightingTexConsts ) ||
	    !LoadPixelShader( "PlainColour.psh", &PS_PlainColour, &PS_PlainColourConsts ) ||
	    !LoadPixelShader( "PixelLitTex.psh", &PS_LightingTex, &PS_LightingTexConsts ))
	{
		return false;
	}

	return true;
}

// Release everything in the scene
void SceneShutdown()
{
	// Release DirectX allocated objects
	SAFE_RELEASE( PS_LightingTexConsts );
	SAFE_RELEASE( PS_LightingTex );
	SAFE_RELEASE( PS_PlainColourConsts );
	SAFE_RELEASE( PS_PlainColour );
	SAFE_RELEASE( VS_LightingTexConsts );
	SAFE_RELEASE( VS_LightingTex );
	SAFE_RELEASE( VS_XformOnlyConsts );
	SAFE_RELEASE( VS_XformOnly );
	SAFE_RELEASE( GroundTexture );

	// Release light models
	UninitialiseLightModels();

	// Delete dynamically allocated objects. Our own types - no need to use DirectX release code
	delete GroundModel;
	delete ParticleModel;
	delete MainCamera; 
}


//-----------------------------------------------------------------------------
// Game loop functions
//-----------------------------------------------------------------------------

// Render the main models in the scene with given camera
void RenderModels( CCamera* camera )
{
	// Common model settings
	// Select shaders
	SetVertexShader( VS_LightingTex );
	SetPixelShader( PS_LightingTex );

	// Calculate the view and projection matrices for the camera, then pass combined
	// view-projection matrix to the vertex shader
	camera->CalculateMatrices();
	D3DXMATRIXA16 viewProjMatrix = camera->GetViewProjectionMatrix();
	VS_LightingTexConsts->SetMatrix( g_pd3dDevice, "ViewProjMatrix", &viewProjMatrix );
	
	// Pass lighting information to pixel shader
	PS_LightingTexConsts->SetFloatArray( g_pd3dDevice, "AmbientColour", (float*)&AmbientColour, 3 );
	PS_LightingTexConsts->SetFloatArray( g_pd3dDevice, "Light1Position", (float*)&LightPositions[0], 3 );
	PS_LightingTexConsts->SetFloatArray( g_pd3dDevice, "Light1Colour", (float*)&LightColours[0], 3 );
	PS_LightingTexConsts->SetFloat( g_pd3dDevice, "Light1Brightness", LightBrightness[0] );
	PS_LightingTexConsts->SetFloatArray( g_pd3dDevice, "Light2Position", (float*)&LightPositions[1], 3 );
	PS_LightingTexConsts->SetFloatArray( g_pd3dDevice, "Light2Colour", (float*)&LightColours[1], 3 );
	PS_LightingTexConsts->SetFloat( g_pd3dDevice, "Light2Brightness", LightBrightness[1] );
	PS_LightingTexConsts->SetFloatArray( g_pd3dDevice, "CameraPosition", (float*)&camera->GetPosition(), 3 );
	PS_LightingTexConsts->SetFloat( g_pd3dDevice, "SpecularPower", SpecularPower );


	// Ground rendering
	// Calculate world matrix for floor and pass it to the vertex shader
	GroundModel->CalculateMatrix();
	D3DXMATRIXA16 worldMatrix = GroundModel->GetWorldMatrix();
	VS_LightingTexConsts->SetMatrix( g_pd3dDevice, "WorldMatrix", &worldMatrix );

	// Select a texture for the floor and render it
	SetTexture( 0, GroundTexture );
	GroundModel->Render();
}


// Render scene lights with given camera. This does not mean calculate
// lighting - just draw a sphere for each light
void RenderLights( CCamera* camera )
{
	// Lights are rendered with the most basic shaders - all pixels a single colour

	// Calculate the view and projection matrices for the camera
	camera->CalculateMatrices();
	D3DXMATRIXA16 viewProjMatrix = camera->GetViewProjectionMatrix();

	// Select shaders - light models are rendering in plain colour
	SetVertexShader( VS_XformOnly );
	SetPixelShader( PS_PlainColour );
	
	// Render each light in turn
	for (int light = 0; light < NumLights; ++light)
	{
		// Calculate world matrix for current light and combine into a single matrix before
		// passing to the light's vertex shader
		LightModels[light]->CalculateMatrix();
		D3DXMATRIXA16 worldViewProjMatrix = LightModels[light]->GetWorldMatrix() * viewProjMatrix;
		VS_XformOnlyConsts->SetMatrix( g_pd3dDevice, "WorldViewProjMatrix", &worldViewProjMatrix );

		// Use light colour for model plain colour - set in pixel shader
		PS_PlainColourConsts->SetFloatArray( g_pd3dDevice, "Colour", (float*)&LightColours[light], 3 );

		LightModels[light]->Render();
	}
}


//*************************************
// Particle Rendering
//*************************************
// Code for particle rendering is almost complete - simply iterates through the list of particles and renders
// each one as a normal model
void RenderParticles( CCamera* camera )
{
	// Calculate the view and projection matrices for the camera
	camera->CalculateMatrices();
	D3DXMATRIXA16 viewProjMatrix = camera->GetViewProjectionMatrix();

	// Select shaders - particles rendered in plain colour
	SetVertexShader( VS_XformOnly );
	SetPixelShader( PS_PlainColour );
	
	// Fixed colour for all particles at first
	float particleColour[3] = { 1.0f, 0.0f, 0.0f };
	PS_PlainColourConsts->SetFloatArray( g_pd3dDevice, "Colour", particleColour, 3 );

	list<Particle>::iterator itParticle = Particles.begin();
	while (itParticle != Particles.end())
	{
		// Set new position and calculate world matrix for each particle, then render it
		//**** Update the line below to use the variables you defined for the particle position
		//ParticleModel->SetPosition( (*itParticle).px, (*itParticle).py, (*itParticle).pz );
		ParticleModel->CalculateMatrix();
		D3DXMATRIXA16 worldViewProjMatrix = ParticleModel->GetWorldMatrix() * viewProjMatrix;
		VS_XformOnlyConsts->SetMatrix( g_pd3dDevice, "WorldViewProjMatrix", &worldViewProjMatrix );
		ParticleModel->Render();

		itParticle++;
	}
}


// Overall rendering process
void RenderScene()
{
    // Clear the back-buffer and the z-buffer / stencil
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL,
	                     BackgroundColour, 1.0f, 0 );

    // Begin the scene
    if (SUCCEEDED(g_pd3dDevice->BeginScene()))
    {
		// Render scene elements
		RenderModels( MainCamera );
		RenderLights( MainCamera );
		RenderParticles( MainCamera );

       // End the scene
        g_pd3dDevice->EndScene();
	}

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}


// Update the scene between rendering. The function is passed the time since the last frame
void UpdateScene( float updateTime )
{
	// Move the camera with keys
	// Keys in order - rotation: up,down,left,right then movement: forward,backward,left,right
	MainCamera->Control( Key_Up, Key_Down, Key_Left, Key_Right, Key_W, Key_S, Key_A, Key_D );

	// One light follows an orbit
	static float Rotate = 0.0f;
	SetPointLightPos( 0, cos(Rotate) * LightOrbit, 35.0f, sin(Rotate) * LightOrbit  );
	Rotate -= LightSpeed * updateTime;


	//*************************************
	// Particle Update
	//*************************************
	// Move each particle, and emit new particles. Code to be added for the tutorial

}


//-----------------------------------------------------------------------------
// D3D management
//-----------------------------------------------------------------------------

// Initialise Direct3D
bool D3DSetup( HWND hWnd )
{
 	// Get client window dimensions - the size of the viewport window
	RECT clientRect;
	GetClientRect( hWnd, &clientRect );
	ViewportWidth = clientRect.right;
	ViewportHeight = clientRect.bottom;

	// Create the D3D object.
    g_pD3D = Direct3DCreate9( D3D_SDK_VERSION );
	if (!g_pD3D)
	{
        return false;
	}

    // Set up the structure used to create the D3DDevice
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;               // Use desktop pixel format (windowed mode)
    d3dpp.BackBufferCount = 1;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;  // Wait for vertical sync
    d3dpp.EnableAutoDepthStencil = TRUE;         // Create depth buffer (Z)
    d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8; // Allow 24 bits of depth buffer, 8 bits of stencil

    // Create the D3DDevice
    if (FAILED(g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                     D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                     &d3dpp, &g_pd3dDevice )))
    {
        return false;
    }

	// Turn on tri-linear filtering for everything
    g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );

	return true;
}


// Uninitialise D3D
void D3DShutdown()
{
	// Release D3D interfaces
    SAFE_RELEASE( g_pd3dDevice );
    SAFE_RELEASE( g_pD3D );
}


//-----------------------------------------------------------------------------
// Windows functions
//-----------------------------------------------------------------------------

// Window message handler
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_DESTROY:
            PostQuitMessage( 0 );
            return 0;

		case WM_KEYDOWN:
			KeyDownEvent( static_cast<EKeyState>(wParam) );
			break;

		case WM_KEYUP:
			KeyUpEvent( static_cast<EKeyState>(wParam) );
			break;
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}


// Windows main function
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    // Register the window class (adding our own icon to this window)
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
                      GetModuleHandle(NULL), LoadIcon( hInst, MAKEINTRESOURCE(IDI_TL) ),
					  LoadCursor( NULL, IDC_ARROW ), NULL, NULL,
                      "ParticleSystem", NULL };
    RegisterClassEx( &wc );

    // Create the application's window - ensure the visible viewport starts at a given size
	RECT initSize = { 0, 0, 1280, 960 };
	DWORD windowStyle = WS_OVERLAPPEDWINDOW;
	AdjustWindowRect( &initSize, windowStyle, FALSE );
	HWND hWnd = CreateWindow( "ParticleSystem", "CO2301: Particle Systems",
	                          windowStyle, 100, 100, initSize.right - initSize.left,
							  initSize.bottom - initSize.top, NULL, NULL, wc.hInstance, NULL );

    // Initialize Direct3D
    if (D3DSetup( hWnd ))
    {
        // Prepare the scene
        if (SceneSetup())
        {
            // Show the window
            ShowWindow( hWnd, SW_SHOWDEFAULT );
            UpdateWindow( hWnd );

			// Will time each frame in this app - use simple Windows timer
			DWORD oldTime = timeGetTime();

            // Enter the message loop
            MSG msg;
            ZeroMemory( &msg, sizeof(msg) );
            while( msg.message != WM_QUIT )
            {
                if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
                {
                    TranslateMessage( &msg );
                    DispatchMessage( &msg );
                }
                else
				{
					// Calculate time (in seconds) since last frame
					DWORD newTime = timeGetTime();
					float updateTime = static_cast<float>(newTime - oldTime) / 1000.0f;
					oldTime = newTime;

					// Render and update the scene
                    RenderScene();
					UpdateScene( updateTime );
					if (KeyHeld( Key_Escape )) // Allow user to quit with escape key
					{
						DestroyWindow( hWnd );
					}
				}
            }
        }
	    SceneShutdown();
    }
	D3DShutdown();

	UnregisterClass( "ParticleSystem", wc.hInstance );
    return 0;
}
