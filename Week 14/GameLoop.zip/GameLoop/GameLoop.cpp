// GameLoop.cpp: A program using the TL-Engine

#include <math.h>
#include <sstream>
using namespace std;

#include <windows.h>

#include <TL-Engine.h>	// TL-Engine include file and namespace
using namespace tle;


/////////////////////////////
// Game Constants

// Ship control
const float shipAccel = 15.0f;
const float shipMaxSpeed = 30.0f;
const float shipMaxSideSpeed = 10.0f;
const float shipMaxRotSpeed = 300;
const float shipDrag = 0.75f;        // Slow movement when no input
const float shipRotDrag = 0.02f;     // Slow rotational movement (has effect when no input)
const float shipRotDampSpeed = 1.0f; // Speed beyond which mouse input is damped
const float shipRotDamping = 2.0f;   // Maximum rotation damping applied at high speed

// Mouse sensitivity
const float mouseRotateSpeed = 0.5f;

// Chase camera position
const float cameraDist = 0.12f;   // Distance of camera behind ship
const float cameraHeight = 0.03f;  // Distance of camera above ship
const float cameraYAngle = 0.1f; // Angle of camera looking down on ship

// Maximum amount camera is allowed to lag behind the ship (rotational and movement lag)
// Actual amount of lag will increase with ship's movement/rotational speed
const float cameraMaxLagX = 0.025f;
const float cameraMaxLagZ = 0.1f;
const float cameraMaxLagRotX = 0.08f;
const float cameraMaxLagRotY = 0.16f;

// Amount of "look ahead" for the camera
const float lookAheadHoriz = 0.5f;
const float lookAheadVert = 0.6f;

// World matrix (4x4 floats) used for some update code
float matrix[16];


/////////////////////////////
// Global variables

// Resources
I3DEngine* myEngine;
HWND hWnd;
IMesh* starsMesh;
IMesh* planetMesh;
IMesh* shipMesh;
IModel* stars;
IModel* earth;
IModel* venus;
IModel* sun;
IModel* ship;
ICamera* camera;
ILight* sunlight;
IFont* gameFont;

// Mouse cursor position (doing mouse work directly in this project)
int mouseX;
int mouseY;
int mouseMovementX;
int mouseMovementY;

// Ship sideward, forward and rotation speeds
float shipSpeedX = 0.0f;
float shipSpeedZ = 0.0f;
float shipSpeedRotX = 0.0f;
float shipSpeedRotY = 0.0f;

// Variables to calculate recent average speed (see UpdateScene for comments)
const float avgSamplePeriod = 0.1f; // Period of time (seconds) over which to average
const int maxAvgSamples = 100;      // Maximum number of recent frames to average speeds over
int currAvgSample = 0;              // Counter over number of frames above

// Structure holding the speeds sampled at a single frame
struct SpeedSample
{
	float X, Z;
	float RotX, RotY;
};

// Array of speeds over the recent frames
SpeedSample recentSpeeds[maxAvgSamples];

// Average speed over recent frames
SpeedSample shipAvgSpeed = { 0.0f, 0.0f, 0.0f, 0.0f }; // Initialise all averages to 0


/////////////////////////////
// Front end functions

void FrontEndSetup()
{
}
void FrontEndUpdate()
{
}
void FrontEndShutdown()
{
}


/////////////////////////////
// Game loop functions

void GameSetup()
{
	// Put game setup code here
}

void GameUpdate()
{
	// Put game update code here
}

void GameShutdown()
{
	// Put game shutdown code here
}


// Temporary function used in UpdateScene to force the frame rate to a given one
// Used prior to the adding of proper variable timing later in the exercises
void ForceFrameTime(float tick)
{
	float time = myEngine->Timer();
	while (time < tick)
	{
		time += myEngine->Timer();
	}
}


/////////////////////////////
// Main function

// Will to simplify this by copying the code into the functions above
void main()
{
	// Create a 3D engine (Irrlicht in this case) and open a window for it
	myEngine = New3DEngine(kIrrlicht);
	myEngine->StartWindowed(1280, 960);
	hWnd = (HWND)myEngine->GetWindow(); // Window handle

	// Add default folder for meshes and other media - can provide several folders here for different locations
	myEngine->AddMediaFolder("C:\\ProgramData\\TL-Engine\\Media");


	/**************************/
	/**** Game Set-up Area ****/

	// Load meshes
	starsMesh = myEngine->LoadMesh("Stars.x");
	planetMesh = myEngine->LoadMesh("Earth.x");
	shipMesh = myEngine->LoadMesh("HawkStarfighter.x");

	// Create environment
	earth = planetMesh->CreateModel();
	earth->RotateZ(15.0f);

	venus = planetMesh->CreateModel(300.0f, 100.0f, 300.0f);
	venus->SetSkin("Venus.jpg");
	venus->RotateZ(-5.0f);

	sun = planetMesh->CreateModel(10000.0f, 3000.0f, -6000.0f);
	sun->SetSkin("Sun.jpg");
	sun->Scale(5.0f);

	stars = starsMesh->CreateModel();
	stars->SetSkin("StarsHi.jpg");
	stars->Scale(20.0f);

	// Create ship
	ship = shipMesh->CreateModel(0.0f, 0.0f, -200.0f);

	// Create camera - based on ship's position plus constants from above
	camera = myEngine->CreateCamera(kManual, ship->GetX(), ship->GetY() + cameraHeight,
		ship->GetZ() - cameraDist);
	camera->RotateX(cameraYAngle);
	camera->SetNearClip(0.05f);    // Change near and far viewing distance...
	camera->SetFarClip(50000.0f);  // ...for camera to suit a space game

	// Set up lighting
	myEngine->SetAmbientLight(0.2f, 0.2f, 0.3f); // Background blueish light
	sunlight = myEngine->CreatePointLight(sun->GetX(), sun->GetY(), sun->GetZ(), 1.0f, 0.9f, 0.5f, sun->GetX() * 2.0f); // Sun light
	earth->EnableLighting();
	venus->EnableLighting();
	ship->EnableLighting();

	// Load a font
	gameFont = myEngine->LoadFont("Font2.bmp");

	// Mouse capture is not working properly for this kind of project so do mouse work directly with Windows calls 
	SetCapture(hWnd);
	ShowCursor(false);
	RECT rect0 = { 0 };
	GetWindowRect(hWnd, &rect0);
	mouseX = rect0.left + (rect0.right  - rect0.left) / 2;
	mouseY = rect0.top  + (rect0.bottom - rect0.top ) / 2;
	SetCursorPos(mouseX, mouseY);

	// Initialise all the average speed samples to 0 (see SceneUpdate for code/comment)
	// Simple way to clear all elements of an array to 0 - use with caution and understanding :)
	memset(recentSpeeds, 0, sizeof(recentSpeeds));


	/**** End of Game Set-up Area ****/
	/*********************************/


	// The main game loop, repeat until engine is stopped
	while (myEngine->IsRunning())
	{
		// Doing mouse work manually in this project, get motion and then set mouse to centre of window every frame
		POINT mousePt;
		GetCursorPos(&mousePt);
		mouseMovementX = mousePt.x - mouseX;
		mouseMovementY = mousePt.y - mouseY;
		RECT rect = { 0 };
		GetWindowRect(hWnd, &rect);
		mouseX = rect.left + (rect.right - rect.left) / 2;
		mouseY = rect.top  + (rect.bottom - rect.top ) / 2;
		SetCursorPos(mouseX, mouseY);

		// Draw the scene
		myEngine->DrawScene();

		/**************************/
		/**** Game Update Area ****/

		// 'updateTime' is a value to specify much time has passed since the last frame. This
		// will allow us to use variable timing for the game loop. This variable is used 
		// throughout the game code, but it is currently initialised to a constant, so you must
		// update this line to enable game loop timing 
		// Notice how some uses of updateTime are trivial, but others involve tricky maths.
		// If the maths overhead becomes too tricky or inefficient, we can shift to the fixed
		// timing method. Then we could remove this variable and just call the update code
		// several times (see lecture notes)
		float updateTime = 1 / 60.0f; // Currently set to a constant - 1/60 second per frame (= 60 fps)

		// Temporary line to force frame rate to the update given below - comment this out when you start adding variable timing
		ForceFrameTime(updateTime);

		stringstream outText;
		outText << "Frame Time: " << updateTime;    // Can't use endl with TL fonts...
		gameFont->Draw(outText.str(), 0, 0, kWhite); // ...use multiple draw calls instead
		outText.str(""); // How to clear outText for further draw calls


		////////////////////////
		// Planet update

		// Rotate planets - should use variable timing
		earth->RotateY(0.05f);
		venus->RotateY(-0.025f);
		sun->RotateY(0.025f);


		//---------------------------------------------------------------------------------
		// The ship and camera in this program are carefully controlled and smoothed for
		// a better interface. This is advanced work that you don't need to understand in
		// full to follow the worksheet. Still it might give you ideas for your project
		//---------------------------------------------------------------------------------

		////////////////////////
		// Ship Control

		// Ship forward movement
		if (myEngine->KeyHeld(Key_W)) // Forward
		{
			// Increase basic ship speed using constant acceleration and check speed limit
			shipSpeedZ += shipAccel * updateTime;
			if (shipSpeedZ > shipMaxSpeed)
			{
				shipSpeedZ = shipMaxSpeed;
			}
		}
		else if (myEngine->KeyHeld(Key_S)) // Backward
		{
			// Decrease basic ship speed using constant acceleration and check speed limit
			shipSpeedZ -= shipAccel * updateTime;
			if (shipSpeedZ < -shipMaxSpeed / 4.0f) // Slower in reverse
			{
				shipSpeedZ = -shipMaxSpeed / 4.0f;
			}
		}

		// Ship sideways movement
		if (myEngine->KeyHeld(Key_D)) // Right
		{
			// Change basic ship speed using constant acceleration and check speed limit
			shipSpeedX += shipAccel * updateTime;
			if (shipSpeedX > shipMaxSideSpeed)
			{
				shipSpeedX = shipMaxSideSpeed;
			}
		}
		else if (myEngine->KeyHeld(Key_A)) // Left
		{
			// Change basic ship speed using constant acceleration and check speed limit
			shipSpeedX -= shipAccel * updateTime;
			if (shipSpeedX < -shipMaxSideSpeed)
			{
				shipSpeedX = -shipMaxSideSpeed;
			}
		}

		// Apply drag to speed - if not pressing a key
		// As we are multiplying, need to use pow for variable timing method
		float drag = pow(shipDrag, updateTime);
		shipSpeedX *= drag;
		shipSpeedZ *= drag;

		// Use speeds set above to move ship forwards/backwards & left/right
		ship->MoveLocalX(shipSpeedX * updateTime);
		ship->MoveLocalZ(shipSpeedZ * updateTime);


		// Get mouse input - don't need to scale this by updateTime
		//**** Can make either of these negative to invert the mouse control
		float mouseMoveX = mouseMovementX * mouseRotateSpeed;
		float mouseMoveY = mouseMovementY * mouseRotateSpeed;

		// If ship forward speed is high..
		if (abs(shipSpeedZ) > shipRotDampSpeed)
		{
			// ...damp the rotation input (reduce its sensitivity) - tricky
			float dampingScale = (abs(shipSpeedZ) - shipRotDampSpeed) /
				(shipMaxSpeed - shipRotDampSpeed);
			float sensitivityAdjust = 1.0f + shipRotDamping * dampingScale;
			mouseMoveX /= sensitivityAdjust;
			mouseMoveY /= sensitivityAdjust;
		}


		// Update ship's rotational speeds based on mouse movement, ensure maximum rotational speed is not exceeded
		shipSpeedRotX += mouseMoveY; // X mouse movement makes Y ship rotation and vice versa - think about it
		shipSpeedRotY += mouseMoveX; // --"--
		if (shipSpeedRotX > shipMaxRotSpeed)
		{
			shipSpeedRotX = shipMaxRotSpeed;
		}
		else if (shipSpeedRotX < -shipMaxRotSpeed)
		{
			shipSpeedRotX = -shipMaxRotSpeed;
		}
		if (shipSpeedRotY > shipMaxRotSpeed)
		{
			shipSpeedRotY = shipMaxRotSpeed;
		}
		else if (shipSpeedRotY < -shipMaxRotSpeed)
		{
			shipSpeedRotY = -shipMaxRotSpeed;
		}

		// Apply drag to rotational speed, so ship's rotation smoothly stops when mouse stops moving
		float rotDrag = pow(shipRotDrag, updateTime);
		shipSpeedRotX *= rotDrag;
		shipSpeedRotY *= rotDrag;

		// Rotate ship - use variable timing
		ship->RotateX(shipSpeedRotX * updateTime);
		ship->RotateY(shipSpeedRotY * updateTime);


		//////////////////////////////
		// Calculate Average Speed

		// The ships movement above is not smoothed (this would make the control "laggy")
		// However the chase camera movement is heavily smoothed. This makes the look
		// of the game smoother and also allows the camera to "look ahead" of the ship
		// Lots of tinkering required to perfect this kind of thing. One key requirement
		// is to have the camera follow the *recent average speed* of the ship rather 
		// than the *current actual speed*. The following code keeps track of this average
		// over recent frames

		// Find average of recently sampled speeds. Uses a quick way to update a running average - remove the 
		// oldest sample, then add in the newest - saves using a for loop over the whole array
		int numAvgSamples = (int)(avgSamplePeriod / updateTime); // Approx number of frames that occured in the sample period
		if (numAvgSamples == 0) numAvgSamples = 1;
		if (numAvgSamples > maxAvgSamples) numAvgSamples = maxAvgSamples;
		int oldAvgSample = (currAvgSample - numAvgSamples + maxAvgSamples) % maxAvgSamples; // Get oldest sample index
		shipAvgSpeed.X = (shipAvgSpeed.X * numAvgSamples - recentSpeeds[oldAvgSample].X + shipSpeedX) / numAvgSamples;
		shipAvgSpeed.Z = (shipAvgSpeed.Z * numAvgSamples - recentSpeeds[oldAvgSample].Z + shipSpeedZ) / numAvgSamples;
		shipAvgSpeed.RotX = (shipAvgSpeed.RotX * numAvgSamples - recentSpeeds[oldAvgSample].RotX + shipSpeedRotX) / numAvgSamples;
		shipAvgSpeed.RotY = (shipAvgSpeed.RotY * numAvgSamples - recentSpeeds[oldAvgSample].RotY + shipSpeedRotY) / numAvgSamples;
		recentSpeeds[currAvgSample].X = shipSpeedX;
		recentSpeeds[currAvgSample].Z = shipSpeedZ;
		recentSpeeds[currAvgSample].RotX = shipSpeedRotX;
		recentSpeeds[currAvgSample].RotY = shipSpeedRotY;

		// Step to next sample
		currAvgSample = (currAvgSample + 1) % maxAvgSamples;


		//////////////////////////////
		// Camera Movement

		// Camera is allowed to lag behind it's exact chase position behind the ship (both rotational
		// and movement lag). The amount of lag increases with ship's movement/rotational speed

		// Calculate amount to lag behind in rotation
		static float cameraLagRotX = 0.0f;
		static float cameraLagRotY = 0.0f;
		float cameraLagAdjustRotX = -cameraLagRotX;
		float cameraLagAdjustRotY = -cameraLagRotY;
		cameraLagRotX = cameraMaxLagRotX * -shipAvgSpeed.RotX / shipMaxRotSpeed;
		cameraLagRotY = cameraMaxLagRotY * -shipAvgSpeed.RotY / shipMaxRotSpeed;
		cameraLagAdjustRotX += cameraLagRotX;
		cameraLagAdjustRotY += cameraLagRotY;

		// Rotate same as ship, but with adjustment for lag
		camera->RotateX(shipSpeedRotX * updateTime + cameraLagAdjustRotX);
		camera->RotateY(shipSpeedRotY * updateTime + cameraLagAdjustRotY);


		// Calculate amount to lag behind movement
		float cameraLagX = cameraMaxLagX * -shipAvgSpeed.X / shipMaxSideSpeed;
		float cameraLagY = 0;
		float cameraLagZ = cameraMaxLagZ * -shipAvgSpeed.Z / shipMaxSpeed;
		cameraLagX -= cameraLagRotY * lookAheadHoriz; // Allow camera to "look ahead" of ship by adding "forward lag" based on rotation...
		cameraLagY -= -cameraLagRotX * lookAheadVert;

		// Camera will follow a chase position fixed behind the ship, but with some lag as described above
		// Use matrix work to get chase position - extracting X,Y and Z axes from world matrix - recall Computer Graphics
		ship->GetMatrix(matrix);
		//              Ship position + side lag in X-Axis     + up a little in Y-axis                   + set back & lag in Z-Axis
		float cameraPosX = matrix[12] + cameraLagX * matrix[0] + (cameraLagY + cameraHeight) * matrix[4] + (cameraLagZ - cameraDist) * matrix[8];
		float cameraPosY = matrix[13] + cameraLagX * matrix[1] + (cameraLagY + cameraHeight) * matrix[5] + (cameraLagZ - cameraDist) * matrix[9];
		float cameraPosZ = matrix[14] + cameraLagX * matrix[2] + (cameraLagY + cameraHeight) * matrix[6] + (cameraLagZ - cameraDist) * matrix[10];
		camera->SetPosition(cameraPosX, cameraPosY, cameraPosZ);

		/**** End of Game Update Area ****/
		/*********************************/


		// Quit from game loop if 'Escape' is pressed
		// Note that this just quits the while loop - it does not stop the 
		// engine as it did in previous TL-Projects
		if (myEngine->KeyHit(Key_Escape))
		{
			break;
		}
	}


	/****************************/
	/**** Game Shutdown Area ****/

	// Put engine back to original state - remove all lights, models and meshes
	myEngine->RemoveFont(gameFont);
	myEngine->RemoveLight(sunlight);
	myEngine->RemoveCamera(camera);
	shipMesh->RemoveModel(ship);
	planetMesh->RemoveModel(sun);
	planetMesh->RemoveModel(venus);
	planetMesh->RemoveModel(earth);
	starsMesh->RemoveModel(stars);
	myEngine->RemoveMesh(shipMesh);
	myEngine->RemoveMesh(planetMesh);
	myEngine->RemoveMesh(starsMesh);

	SetCapture(NULL);
	ShowCursor(true);

	/**** End of Game Shutdown Area ****/
	/***********************************/


	// Delete the 3D engine now we are finished with it
	myEngine->Delete();
}
