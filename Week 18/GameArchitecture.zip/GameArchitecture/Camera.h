/**********************************************
	Camera.h

	Interface for all camera classes
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include "Input.h"

//-----------------------------------------------------------------------------
// ICamera interface
//-----------------------------------------------------------------------------

/* MISSING class*/