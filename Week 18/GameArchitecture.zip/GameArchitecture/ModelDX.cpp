/**********************************************
	ModelDX.cpp

	Implementation of model class for DirectX
***********************************************/

#include "DefinesDX.h" // General definitions for DirectX files
#include "ModelDX.h"   // Declaration of this class

#include "CImportXFile.h" // Class to load meshes (taken from a full graphics engine)

///////////////////////////////
// Constructors / Destructors

// Model constructor
CModelDX::CModelDX()
{
	// Initialise member variables
	m_VertexBuffer = NULL;
	m_NumVertices = 0;
	m_VertexSize = 0;
	m_pVertexDeclaration = NULL;

	m_IndexBuffer = NULL;
	m_NumIndices = 0;

	m_HasGeometry = false;

	m_Material.Ambient = m_Material.Diffuse = D3DXCOLOR( 1, 1, 1, 1 );
	m_Material.Specular = m_Material.Emissive = D3DXCOLOR( 0, 0, 0, 1 );
	m_Material.Power = 0.0f;
	m_Texture = 0;

	m_Position = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	m_Rotation = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	m_Scale = 1.0f;
}

// Model destructor
CModelDX::~CModelDX()
{
	ReleaseResources();
}

// Release resources used by model
void CModelDX::ReleaseResources()
{
	// Using a DirectX helper macro to simplify code here - look it up in Defines.h
	SAFE_RELEASE( m_IndexBuffer );
	SAFE_RELEASE( m_VertexBuffer );
	SAFE_RELEASE( m_pVertexDeclaration );
	m_HasGeometry = false;
}


/////////////////////////////
// Setters

void CModelDX::SetPosition( float x, float y, float z )
{
	m_Position = D3DXVECTOR3( x, y, z );
}

void CModelDX::SetRotation( float x, float y, float z )
{
	m_Rotation = D3DXVECTOR3( x, y, z );
}

void CModelDX::SetScale( float scale )
{
	m_Scale = scale;
}

// Point the model in a given direction, assumes ZXY rotation order
void CModelDX::SetDirection( float x, float y, float z )
{
	// A little geometry to convert a direction vector to X and Y rotations, sets Z rotation to 0
	float len = sqrt( x*x + z*z );
	if (len > 0.0005f)
	{
		m_Rotation.x = -atan2f( y, len );
		m_Rotation.y = atan2f( x, z );
		m_Rotation.z = 0.0f;
	}
	else
	{
		m_Rotation.x = ToRadians((y > 0.0f) ? -90.0f : 90.0f);
		m_Rotation.y = m_Rotation.z = 0.0f;
	}
	return;
}


/////////////////////////////
// Model Loading / Creation

// Load the model geometry from a file. This model class only supports a single material 
// per model. Real world models often use several materials for different parts of the
// geometry. This function only reads the geometry using the first material in the file,
// so multi-material models will load but will have parts missing
bool CModelDX::Load( const string& fileName )
{
	// Release any existing geometry
	ReleaseResources();

	// Use CImportXFile class (from another application) to load the given file
	// The import code is wrapped in the namespace 'gen'
	gen::CImportXFile mesh;
	if (mesh.ImportFile( fileName.c_str() ) != gen::kSuccess)
	{
		return false;
	}

	// Get first sub-mesh from loaded file (specify no tangents required, left-handed system)
	gen::SSubMesh subMesh;
	if (mesh.GetSubMesh( 0, &subMesh, false, true ) != gen::kSuccess)
	{
		return false;
	}

	// Create vertex element list & declaration
	unsigned int iElt = 0;
	unsigned int iOffset = 0;
	m_VertexElts[iElt].Stream = 0;
	m_VertexElts[iElt].Offset = iOffset;
	m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT3;
	m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
	m_VertexElts[iElt].Usage = D3DDECLUSAGE_POSITION;
	m_VertexElts[iElt].UsageIndex = 0;
	iOffset += 12;
	++iElt;
	if (subMesh.hasNormals)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT3;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_NORMAL;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 12;
		++iElt;
	}
	if (subMesh.hasTangents)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT3;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_TANGENT;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 12;
		++iElt;
	}
	if (subMesh.hasTextureCoords)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_FLOAT2;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_TEXCOORD;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 8;
		++iElt;
	}
	if (subMesh.hasVertexColours)
	{
		m_VertexElts[iElt].Stream = 0;
		m_VertexElts[iElt].Offset = iOffset;
		m_VertexElts[iElt].Type = D3DDECLTYPE_D3DCOLOR;
		m_VertexElts[iElt].Method = D3DDECLMETHOD_DEFAULT;
		m_VertexElts[iElt].Usage = D3DDECLUSAGE_COLOR;
		m_VertexElts[iElt].UsageIndex = 0;
		iOffset += 4;
		++iElt;
	}
	D3DVERTEXELEMENT9 endElt = D3DDECL_END();
	memcpy( &m_VertexElts[iElt], &endElt, sizeof(D3DVERTEXELEMENT9) );
	m_VertexSize = D3DXGetDeclVertexSize( m_VertexElts, 0 );
	g_pd3dDevice->CreateVertexDeclaration( m_VertexElts, &m_pVertexDeclaration );

	// Get vertex FVF - a description of vertex elements when not using shaders
	D3DXFVFFromDeclarator( m_VertexElts, &m_VertexFVF ); // DirectX helper function for this

	// Create the vertex buffer
	m_NumVertices = subMesh.numVertices;
	unsigned int bufferSize = m_NumVertices * m_VertexSize;
    if (FAILED(g_pd3dDevice->CreateVertexBuffer( bufferSize, D3DUSAGE_WRITEONLY, 0,
                                                 D3DPOOL_DEFAULT, &m_VertexBuffer, NULL )))
    {
        return false;
    }

    // "Lock" the vertex buffer so we can write to it
    void* bufferData;
    if (FAILED(m_VertexBuffer->Lock( 0, bufferSize, (void**)&bufferData, 0 )))
	{
        return false;
	}

	// Copy the vertex data from the sub-mesh
	memcpy( bufferData, subMesh.vertices, bufferSize );

	// Unlock the vertex buffer again so it can be used for rendering
    m_VertexBuffer->Unlock();


    // Create the index buffer - assuming 2-byte (WORD) index data
	m_NumIndices = static_cast<unsigned int>(subMesh.numFaces) * 3;
	bufferSize = m_NumIndices * sizeof(WORD);
    if (FAILED(g_pd3dDevice->CreateIndexBuffer( bufferSize, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                                D3DPOOL_DEFAULT, &m_IndexBuffer, NULL )))
    {
        return false;
    }

    // "Lock" the index buffer so we can write to it
    if (FAILED(m_IndexBuffer->Lock( 0, bufferSize, (void**)&bufferData, 0 )))
	{
        return false;
	}

	// Copy the vertex data from the sub-mesh
	memcpy( bufferData, subMesh.faces, bufferSize );

	// Unlock the index buffer again so it can be used for rendering
    m_IndexBuffer->Unlock();

	m_HasGeometry = true;
	return true;
}


/////////////////////////////
// Model texture / material

// Set material colour and specular power (set 0 power for no specular highlights)
void CModelDX::SetMaterial( float r, float g, float b, float specularPower )
{
	// Set ambient and diffuse colour (of front and back faces)
	m_Material.Ambient = m_Material.Diffuse = D3DXCOLOR( r, g, b, 1 );

	if (specularPower == 0)
	{
		// No specular light - set it to black
		m_Material.Specular = D3DXCOLOR( 0, 0, 0, 1 );
		m_Material.Power = 0.0f;
	}
	else
	{
		// Using specular light - set it to white (allows light colour to reflect without tint)
		m_Material.Specular = D3DXCOLOR( 1, 1, 1, 1 );
		m_Material.Power = specularPower;
	}
}


// Load a single texture for the whole model (ignores textures in model file)
// Returns true on success
bool CModelDX::LoadTexture( const string& fileName )
{
	// Add extension used for textures on this device
	string fullFileName = fileName + ".jpg";

	// Use DirectX helper function to parse and import texture file
	return (SUCCEEDED(D3DXCreateTextureFromFile( g_pd3dDevice, fullFileName.c_str(), &m_Texture )));
}


/////////////////////////////
// Model Usage

// Prepare model world matrix for rendering
void CModelDX::PrepareWorldMatrix()
{
	// Build the matrix for the model from its position, rotation and scaling
	D3DXMATRIXA16 MatScale, MatX, MatY, MatZ, MatTrans;
	D3DXMatrixScaling( &MatScale, m_Scale, m_Scale, m_Scale );
	D3DXMatrixRotationX( &MatX, m_Rotation.x );
	D3DXMatrixRotationY( &MatY, m_Rotation.y );
	D3DXMatrixRotationZ( &MatZ, m_Rotation.z );
	D3DXMatrixTranslation( &MatTrans, m_Position.x, m_Position.y, m_Position.z );
	m_Matrix = MatScale * MatZ * MatX * MatY * MatTrans;
	
	// Send world matrix to DirectX (not using shaders)
	g_pd3dDevice->SetTransform( D3DTS_WORLD, &m_Matrix );
}

// Prepare model material and texture for rendering
void CModelDX::PrepareMaterialTexture()
{
    g_pd3dDevice->SetTexture( 0, m_Texture );
	g_pd3dDevice->SetMaterial( &m_Material );
}

// Render the model
void CModelDX::Render()
{
	// Don't render if no geometry
	if (!m_HasGeometry)
	{
		return;
	}

	// Prepare for rendering
	PrepareWorldMatrix();
	PrepareMaterialTexture();

	// Tell DirectX the vertex buffer to use and indicate its type (using the FVF code)
	g_pd3dDevice->SetStreamSource( 0, m_VertexBuffer, 0, m_VertexSize );
	//g_pd3dDevice->SetVertexDeclaration( m_pVertexDeclaration ); // When using shaders
	g_pd3dDevice->SetFVF( m_VertexFVF ); // When not using shaders

	// Now tell DirectX the index buffer to use
	g_pd3dDevice->SetIndices( m_IndexBuffer );


	// Draw the primitives from the vertex buffer - a triangle list
	g_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,  // Primitive type - usually tri-list or strip
										0,                   // Offset to add to all indices (0 in simple cases)
										0,                   // Minimum index used (allows for optimisation) 
										m_NumVertices,       // Range of vertices refered to, effectively =
															 //     maximum index - minimum index + 1
										0,                   // Position to start at in index buffer
										m_NumIndices / 3 );  // Number of primitives to render (triangles)
}


// Control the model using keys
void CModelDX::Control( EKeyCode turnUp, EKeyCode turnDown,
					  EKeyCode turnLeft, EKeyCode turnRight,  
					  EKeyCode turnCW, EKeyCode turnCCW,
					  EKeyCode moveForward, EKeyCode moveBackward )
{
	if (KeyHeld( turnDown ))
	{
		m_Rotation.x += RotSpeed;
	}
	if (KeyHeld( turnUp ))
	{
		m_Rotation.x -= RotSpeed;
	}
	if (KeyHeld( turnRight ))
	{
		m_Rotation.y += RotSpeed;
	}
	if (KeyHeld( turnLeft ))
	{
		m_Rotation.y -= RotSpeed;
	}
	if (KeyHeld( turnCW ))
	{
		m_Rotation.z += RotSpeed;
	}
	if (KeyHeld( turnCCW ))
	{
		m_Rotation.z -= RotSpeed;
	}

	// Local Z movement - move in the direction of the Z axis, get axis from world matrix
	if (KeyHeld( moveForward ))
	{
		m_Position.x += m_Matrix._31 * MoveSpeed;
		m_Position.y += m_Matrix._32 * MoveSpeed;
		m_Position.z += m_Matrix._33 * MoveSpeed;
	}
	if (KeyHeld( moveBackward ))
	{
		m_Position.x -= m_Matrix._31 * MoveSpeed;
		m_Position.y -= m_Matrix._32 * MoveSpeed;
		m_Position.z -= m_Matrix._33 * MoveSpeed;
	}
}
