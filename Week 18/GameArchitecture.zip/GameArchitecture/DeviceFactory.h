/**********************************************
	DeviceFactory.h

	Factory function to create CDevice objects
***********************************************/

#include "Device.h" // Device interface class

// List of supported device types
enum EDeviceType
{
	DirectX,
	OpenGL,
};

// Create a CDevice object of the given type
/*MISSING prototype*/