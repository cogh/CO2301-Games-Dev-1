/**********************************************
	LightDX.cpp

	Implementation of point light class for
	DirectX
	For fixed pipeline lights (no shaders)
***********************************************/

#include <string>
using namespace std;

#include "DefinesDX.h" // General definitions for DirectX files
#include "LightDX.h"   // Declaration of this class

///////////////////////////////
// Constructors / Destructors

// Pass light's number, position, colour and brightness. May specify if a model should be
// shown for the light. Defaults to white light at origin with a model
CLightDX::CLightDX( int number, float x, float y, float z,
			        float r, float g, float b,
				    float bright,  bool hasModel )
{
	// Set light number & type
	m_Number = number;

	// Load model if requested
	if (hasModel)
	{
		m_Model = new CModelDX;
		if (!m_Model || !m_Model->Load( "Sphere.x" ))
		{
			// Set no model if problem creating it
			delete m_Model;
			m_Model = NULL;
		}
	}
	else
	{
		// No model needed
		m_Model = NULL;
	}

	// Initialise light settings
	// Use of member functions will also set model position
	ZeroMemory( &m_Light, sizeof(D3DLIGHT9) );
	m_Light.Type = D3DLIGHT_POINT;
	SetPosition( x, y, z );
	SetColour( r, g, b );
	SetBrightness( bright );
}


/////////////////////////////
// Setters

void CLightDX::SetPosition( float x, float y, float z )
{
	m_Light.Position = D3DXVECTOR3( x, y, z ); // Set light position
	if (m_Model)
	{
		m_Model->SetPosition( x, y, z ); // Set model position
	}
}

void CLightDX::SetColour( float r, float g, float b )
{
	m_Light.Ambient = D3DXCOLOR( 0.0f, 0.0f, 0.0f, 1.0f ); // Lights emit no ambient (ambient independent of lights)
	m_Light.Diffuse = m_Light.Specular = D3DXCOLOR( r, g, b, 1.0f ); // Set light colour
	if (m_Model)
	{
		m_Model->SetMaterial( r, g, b ); // Set model colour
	}
}

void CLightDX::SetBrightness( float bright )
{
	m_Light.Attenuation0 = 1.0f;
	m_Light.Attenuation1 = 3.0f / bright;
	m_Light.Attenuation2 = 0.0f;
	m_Light.Range = bright * 4.0f;
	if (m_Model)
	{
		m_Model->SetScale( sqrtf(bright) / 100.0f ); // Set model size
	}
}


///////////////////////////////
// Light Usage

// Enable the light
void CLightDX::Enable()
{
    // Send the light structure to DirectX and enable
    g_pd3dDevice->SetLight( m_Number, &m_Light );
    g_pd3dDevice->LightEnable( m_Number, true );
}

// Disable the light
void CLightDX::Disable()
{
	g_pd3dDevice->LightEnable( m_Number, false );
}

// Render any light model for this light
void CLightDX::Render()
{
	if (m_Model)
	{
		m_Model->Render();
	}
}

// Control the light using keys
void CLightDX::Control( EKeyCode moveForward, EKeyCode moveBackward,
                      EKeyCode moveLeft, EKeyCode moveRight,
                      EKeyCode moveUp, EKeyCode moveDown )
{
	// All movement in world space
	if (KeyHeld( moveRight ))
	{
		m_Light.Position.x += MoveSpeed;
	}
	if (KeyHeld( moveLeft ))
	{
		m_Light.Position.x -= MoveSpeed;
	}
	if (KeyHeld( moveUp ))
	{
		m_Light.Position.y += MoveSpeed;
	}
	if (KeyHeld( moveDown ))
	{
		m_Light.Position.y -= MoveSpeed;
	}
	if (KeyHeld( moveForward ))
	{
		m_Light.Position.z += MoveSpeed;
	}
	if (KeyHeld( moveBackward ))
	{
		m_Light.Position.z -= MoveSpeed;
	}

	// Set position & direction for API and model
	SetPosition( m_Light.Position.x, m_Light.Position.y, m_Light.Position.z );
}
