/**********************************************
	Device.h

	Interface for all device classes
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include <windows.h>

// Interfaces used for the render device
#include "Model.h"  // Model interface
#include "Camera.h" // Camera interface
#include "Light.h"  // Light interface

//-----------------------------------------------------------------------------
// IDevice interface
//-----------------------------------------------------------------------------

// Implementation classes will inherit from this interface
class IDevice
{
/////////////////////////////
// Public member functions
public:

	///////////////////////////////
	// Constructors / Destructors

	// Don't need a constructor for a pure interface (no member variables)

	// Must always have a virtual destructor when there are other virtual functions
	virtual ~IDevice() {} // However, nothing to do for an interface


	/////////////////////////////
	// Device initialisation

	// All functions are virtual and pure (= 0 at end - means no implementation for this class)
	// Can't directly create an object of this class (e.g. myDevice = new CDevice; // Error)
	// Can only create inherited classes (e.g. CCameraDX). Use factory function to do this

	// Initialise device in the given window
	virtual bool Startup( HWND hWnd ) = 0;

	// Uninitialise device
	virtual void Shutdown() = 0;


	/////////////////////////////
	// Game loop support

	// Set the overall ambient lighting for the scene
	virtual void SetAmbientLight( float r, float g, float b ) = 0;

	// Begin rendering the scene into the back-buffer, returns true on success
	virtual bool BeginScene() = 0;

	// Clear the back buffer with given colour, also clear z buffer / stencil
	virtual void Clear( float r, float g, float b ) = 0;

	// Finish rendering the scene
	virtual void EndScene() = 0;

	// Copy/flip the back-buffer contents to the display (front-buffer)
	virtual void DisplayScene() = 0;


	/////////////////////////////
	// Resource factories

	// Factories to create cameras, models and lights of the same type as the device (DX or GL)
	// Pass same parameters as the object constructors
	virtual ICamera* CreateCamera( float x = 0.0f, float y = 0.0f, float z = 0.0f,
	                               float rx = 0.0f, float ry = 0.0f, float rz = 0.0f, 
	                               float n = 0.1f, float f = 10000.0f ) = 0;
	virtual IModel* CreateModel() = 0;
	virtual ILight* CreateLight( int number, float x = 0.0f, float y = 0.0f, float z = 0.0f,
	                             float r = 1.0f, float g = 1.0f, float b = 1.0f,  
			                     float bright = 100.0f,  bool hasModel = true ) = 0;


	/////////////////////////////
	// No member variables
};
