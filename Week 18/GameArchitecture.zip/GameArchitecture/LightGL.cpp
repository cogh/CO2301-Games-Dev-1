/*******************************************
	LightGL.cpp

	Implementation of point light class
	for OpenGL
********************************************/

#include <math.h>
#include <string>
using namespace std;

#include "DefinesGL.h" // General definitions for OpenGL files
#include "LightGL.h"   // Declaration of this class


///////////////////////////////
// Constructors / Destructors

// Pass light's number, position, colour and brightness. May specify if a model should be
// shown for the light. Defaults to white light at origin with a model
CLightGL::CLightGL( int number, float x, float y, float z,
			        float r, float g, float b,
				    float bright,  bool hasModel )
{
	// Light numbers are stored using special OpenGL constants
	const GLenum glLights[] = { GL_LIGHT0, GL_LIGHT1, GL_LIGHT2, GL_LIGHT3, 
	                            GL_LIGHT4, GL_LIGHT5, GL_LIGHT6, GL_LIGHT7 };
	
	// Set light number & type
	m_Number = glLights[number];

	// Load model if requested
	if (hasModel)
	{
		m_Model = new CModelGL;
		if (!m_Model || !m_Model->Load( "Sphere.x" ))
		{
			// Set no model if problem creating it
			delete m_Model;
			m_Model = NULL;
		}
	}
	else
	{
		// No model needed
		m_Model = NULL;
	}

	// Initialise light settings
	// Use of member functions will also set model position
	SetPosition( x, y, z );
	SetColour( r, g, b );
	SetBrightness( bright );
}


/////////////////////////////
// Setters

// Note that all z positions and x/y rotations negated for right-handed system

void CLightGL::SetPosition( float x, float y, float z )
{
	m_Position = Vector3( x, y, -z ); // Store light position

	// OpenGL position - 4th element is 1 to indicate *not* a directional light
	Vector4 glPos = Vector4( x, y, -z, 1.0f );
	glLightfv( m_Number, GL_POSITION, &glPos.x );

	if (m_Model)
	{
		m_Model->SetPosition( x, y, z ); // Set model position
	}
}

void CLightGL::SetColour( float r, float g, float b )
{
	// OpenGL colours
	ColourRGBA ambient( 0.0f, 0.0f, 0.0f, 1.0f ); // Lights emit no ambient (ambient independent of lights)
	glLightfv( m_Number, GL_AMBIENT, &ambient.r );
	ColourRGBA colour( r, g, b, 1.0f );
	glLightfv( m_Number, GL_DIFFUSE, &colour.r );
	glLightfv( m_Number, GL_SPECULAR, &colour.r );
	if (m_Model)
	{
		m_Model->SetMaterial( r, g, b ); // Set model colour
	}
}

void CLightGL::SetBrightness( float bright )
{
	glLightf( m_Number, GL_CONSTANT_ATTENUATION, 1.0f );
	glLightf( m_Number, GL_LINEAR_ATTENUATION, 3.0f / bright );
	glLightf( m_Number, GL_QUADRATIC_ATTENUATION, 0.0f );
	if (m_Model)
	{
		m_Model->SetScale( sqrtf(bright) / 100.0f ); // Set model size
	}
}


///////////////////////////////
// Light Usage

// Enable the light
void CLightGL::Enable()
{
	glEnable( m_Number );
}

// Disable the light
void CLightGL::Disable()
{
	glDisable( m_Number );
}

// Render any light model for this light
void CLightGL::Render()
{
	if (m_Model)
	{
		m_Model->Render();
	}
}

// Control the light using keys
void CLightGL::Control( EKeyCode moveForward, EKeyCode moveBackward,
                        EKeyCode moveLeft, EKeyCode moveRight,
                        EKeyCode moveUp, EKeyCode moveDown )
{
	// The right-handed matrices of OpenGL effectively reverse the Z-axis, so any controls
	// that change z coordinates must be reversed (e.g. forward<->backward)

	// All movement in world space
	if (KeyHeld( moveRight ))
	{
		m_Position.x += MoveSpeed;
	}
	if (KeyHeld( moveLeft ))
	{
		m_Position.x -= MoveSpeed;
	}
	if (KeyHeld( moveUp ))
	{
		m_Position.y += MoveSpeed;
	}
	if (KeyHeld( moveDown ))
	{
		m_Position.y -= MoveSpeed;
	}
	if (KeyHeld( moveForward ))
	{
		m_Position.z -= MoveSpeed;
	}
	if (KeyHeld( moveBackward ))
	{
		m_Position.z += MoveSpeed;
	}

	// Set position for API and model
	SetPosition( m_Position.x, m_Position.y, -m_Position.z );
}
