/**********************************************
	CameraGL.cpp

	Implementation of camera class for OpenGL
***********************************************/

#include "DefinesGL.h" // General definitions for OpenGL files
#include "CameraGL.h"  // Declaration of this class

///////////////////////////////
// Constructors / Destructors

// Constructor
CCameraGL::CCameraGL( float posX, float posY, float posZ,
				      float rotX, float rotY, float rotZ,
				      float nearClip, float farClip )
{
	SetPosition( posX, posY, posZ );
	SetRotation( rotX, rotY, rotZ );
	SetNearFarClip( nearClip, farClip );
}


/////////////////////////////
// Setters

// Note that all z positions and x/y rotations negated for right-handed system

void CCameraGL::SetPosition( float x, float y, float z )
{
	m_Position = Vector3( x, y, -z );
}

void CCameraGL::SetRotation( float x, float y, float z )
{
	m_Rotation = Vector3( -x, -y, z );
}

void CCameraGL::SetNearFarClip( float nearClip, float farClip )
{
	m_NearClip = nearClip;
	m_FarClip = farClip;
}


///////////////////////////////
// Camera Usage

// Setup view and projection matrices for the camera
void CCameraGL::SetViewProjMatrices()
{
    // Switch to building the projection matrix
    glMatrixMode( GL_PROJECTION ); 
    glLoadIdentity(); // Start with the identity matrix

	// Build a perspective projection matrix - almost identical to the DirectX code (D3DXMatrixPerspectiveFovLH)
    gluPerspective( 45.0, 1.33, m_NearClip, m_FarClip); // Field of view, viewport aspect ratio,
	                                                    // near and far clip distances

	// OpenGL uses a combined world/view matrix (it calls it the model/view matrix). Switch to this
	// matrix and begin to accumulate the matrices needed to build it. The matrices are accumulated
	// in reverse order, so the camera view matrix is added first (and the model's world matrix later)
	// The implication is that if we rebuild the camera matrices then we must also rebuild the model's
	// world matrices - this usually happens in any case
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity(); // Start with the identity matrix

	// Accumulate the view matrix (in reverse order from DirectX)
	glRotatef( -m_Rotation.z, 0.0f, 0.0f, 1.0f ); // -"- z axis
	glRotatef( -m_Rotation.x, 1.0f, 0.0f, 0.0f ); // Rotation around x axis
	glRotatef( -m_Rotation.y, 0.0f, 1.0f, 0.0f ); // -"- y axis
	glTranslatef( -m_Position.x, -m_Position.y, -m_Position.z );  // Translation

	// Request a copy of the accumulated view matrix (only used for the keyboard controls)
	glGetFloatv( GL_MODELVIEW_MATRIX, &m_MatView._11 );
}


// Control the camera using keys
void CCameraGL::Control( EKeyCode turnUp, EKeyCode turnDown,
                         EKeyCode turnLeft, EKeyCode turnRight,  
                         EKeyCode moveForward, EKeyCode moveBackward,
                         EKeyCode moveLeft, EKeyCode moveRight )
{
	// The right-handed matrices of OpenGL effectively reverse the Z-axis, so any controls
	// that change z coordinates must be reversed (e.g. forward<->backward)
	if (KeyHeld( turnDown ))
	{
		m_Rotation.x -= RotSpeed;
	}
	if (KeyHeld( turnUp ))
	{
		m_Rotation.x += RotSpeed;
	}
	if (KeyHeld( turnRight ))
	{
		m_Rotation.y -= RotSpeed;
	}
	if (KeyHeld( turnLeft ))
	{
		m_Rotation.y += RotSpeed;
	}

	// Local X movement - move in the direction of the X axis, get axis from view matrix
	if (KeyHeld( moveRight )) 
	{
		m_Position.x += m_MatView._11 * MoveSpeed;
		m_Position.y += m_MatView._21 * MoveSpeed;
		m_Position.z += m_MatView._31 * MoveSpeed;
	}
	if (KeyHeld( moveLeft ))
	{
		m_Position.x -= m_MatView._11 * MoveSpeed;
		m_Position.y -= m_MatView._21 * MoveSpeed;
		m_Position.z -= m_MatView._31 * MoveSpeed;
	}

	// Local Z movement - move in the direction of the Z axis, get axis from view matrix
	if (KeyHeld( moveForward ))
	{
		m_Position.x -= m_MatView._13 * MoveSpeed;
		m_Position.y -= m_MatView._23 * MoveSpeed;
		m_Position.z -= m_MatView._33 * MoveSpeed;
	}
	if (KeyHeld( moveBackward ))
	{
		m_Position.x += m_MatView._13 * MoveSpeed;
		m_Position.y += m_MatView._23 * MoveSpeed;
		m_Position.z += m_MatView._33 * MoveSpeed;
	}
}
