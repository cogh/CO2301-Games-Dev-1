/**********************************************
	CameraDX.cpp

	Implementation of camera class for DirectX
***********************************************/

#include "DefinesDX.h" // General definitions for DirectX files
#include "CameraDX.h"  // Declaration of this class

///////////////////////////////
// Constructors / Destructors

// Constructor
CCameraDX::CCameraDX( float posX, float posY, float posZ,
				      float rotX, float rotY, float rotZ,
				      float nearClip, float farClip )
{
	SetPosition( posX, posY, posZ );
	SetRotation( rotX, rotY, rotZ );
	SetNearFarClip( nearClip, farClip );
}


/////////////////////////////
// Setters

void CCameraDX::SetPosition( float x, float y, float z )
{
	m_Position = D3DXVECTOR3( x, y, z );
}

void CCameraDX::SetRotation( float x, float y, float z )
{
	m_Rotation = D3DXVECTOR3( ToRadians(x), ToRadians(y), ToRadians(z) );
}

void CCameraDX::SetNearFarClip( float nearClip, float farClip )
{
	m_NearClip = nearClip;
	m_FarClip = farClip;
}


///////////////////////////////
// Camera Usage

// Setup view and projection matrices for the camera
void CCameraDX::SetViewProjMatrices()
{
     // Set up the view matrix
    D3DXMATRIXA16 MatScale, MatX, MatY, MatZ, MatTrans;
	D3DXMatrixRotationX( &MatX, -m_Rotation.x );
	D3DXMatrixRotationY( &MatY, -m_Rotation.y );
	D3DXMatrixRotationZ( &MatZ, -m_Rotation.z );
	D3DXMatrixTranslation( &MatTrans, -m_Position.x, -m_Position.y, -m_Position.z);
	m_MatView = MatTrans * MatY * MatX * MatZ;
    g_pd3dDevice->SetTransform( D3DTS_VIEW, &m_MatView ); // Send to DirectX (not using shaders here)

    // For the projection matrix, we set up a perspective transform (which
    // transforms geometry from 3D view space to 2D viewport space, with
    // a perspective divide making objects smaller in the distance). To build
    // a perpsective transform, we need the field of view (1/4 pi is common),
    // the aspect ratio, and the near and far clipping planes (which define at
    // what distances geometry should be no longer be rendered).
	D3DXMATRIXA16 matProj;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, 1.33f, m_NearClip, m_FarClip );
    g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj ); // Send to DirectX (not using shaders here)
}


// Control the camera using keys
void CCameraDX::Control( EKeyCode turnUp, EKeyCode turnDown,
                         EKeyCode turnLeft, EKeyCode turnRight,  
                         EKeyCode moveForward, EKeyCode moveBackward,
                         EKeyCode moveLeft, EKeyCode moveRight )
{
	if (KeyHeld( turnDown ))
	{
		m_Rotation.x += RotSpeed;
	}
	if (KeyHeld( turnUp ))
	{
		m_Rotation.x -= RotSpeed;
	}
	if (KeyHeld( turnRight ))
	{
		m_Rotation.y += RotSpeed;
	}
	if (KeyHeld( turnLeft ))
	{
		m_Rotation.y -= RotSpeed;
	}

	// Local X movement - move in the direction of the X axis, get axis from view matrix
	if (KeyHeld( moveRight ))
	{
		m_Position.x += m_MatView._11 * MoveSpeed;
		m_Position.y += m_MatView._21 * MoveSpeed;
		m_Position.z += m_MatView._31 * MoveSpeed;
	}
	if (KeyHeld( moveLeft ))
	{
		m_Position.x -= m_MatView._11 * MoveSpeed;
		m_Position.y -= m_MatView._21 * MoveSpeed;
		m_Position.z -= m_MatView._31 * MoveSpeed;
	}

	// Local Z movement - move in the direction of the Z axis, get axis from view matrix
	if (KeyHeld( moveForward ))
	{
		m_Position.x += m_MatView._13 * MoveSpeed;
		m_Position.y += m_MatView._23 * MoveSpeed;
		m_Position.z += m_MatView._33 * MoveSpeed;
	}
	if (KeyHeld( moveBackward ))
	{
		m_Position.x -= m_MatView._13 * MoveSpeed;
		m_Position.y -= m_MatView._23 * MoveSpeed;
		m_Position.z -= m_MatView._33 * MoveSpeed;
	}
}
