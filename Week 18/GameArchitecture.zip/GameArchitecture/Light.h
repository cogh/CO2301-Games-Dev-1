/**********************************************
	Light.h

	Interface for all point light classes
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include "Input.h"

//-----------------------------------------------------------------------------
// ILight interface
//-----------------------------------------------------------------------------

// Implementation classes will inherit from this interface
class ILight
{
/////////////////////////////
// Public member functions
public:

	///////////////////////////////
	// Constructors / Destructors

	// Don't need a constructor for a pure interface (no member variables)

	// Must always have a virtual destructor when there are other virtual functions
	virtual ~ILight() {} // However, nothing to do for an interface


	/////////////////////////////
	// Setters

	// All functions are virtual and pure (= 0 at end - means no implementation for this class)
	// Can't directly create an object of this class (e.g. myLight = new CLight; // Error)
	// Can only create inherited classes (e.g. CCameraDX) - use the CDevice class to do this

	virtual void SetPosition( float x, float y, float z ) = 0;
	virtual void SetColour( float r, float g, float b ) = 0;
	virtual void SetBrightness( float bright ) = 0;


	/////////////////////////////
	// Light Usage

	// Enable the light
	virtual void Enable() = 0;
	
	// Disable the light
	virtual void Disable() = 0;

	// Render any light model for this light
	virtual void Render() = 0;

	// Control the light with keys
	virtual void Control( EKeyCode moveForward, EKeyCode moveBackward,
                          EKeyCode moveLeft, EKeyCode moveRight,
                          EKeyCode moveUp, EKeyCode moveDown ) = 0;


	/////////////////////////////
	// No member variables
};

