/*******************************************
	DefinesGL.h

	General definitions for OpenGL files
********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include <windows.h>

// Standard OpenGL header files - included with Visual Studio
#include <GL/gl.h>
#include <GL/glu.h>
#include "glExt.h" // OpenGL extensions - allows use of features from later versions (file stored locally)

//-----------------------------------------------------------------------------
// Types
//-----------------------------------------------------------------------------
// Define simple vector, matrix and colour structures for OpenGL
// Variable names match DirectX structures for simplicity

struct Vector3
{
	Vector3() {} // Default constructor
	Vector3( float ix, float iy, float iz ) { x = ix; y = iy; z = iz; } // Simple constructor
	float x, y, z;
};

struct Vector4
{
	Vector4() {} // Default constructor
	Vector4( float ix, float iy, float iz, float iw ) { x = ix; y = iy; z = iz; w = iw; } // Simple constructor
	float x, y, z, w;
};

struct Matrix4x4
{
	float _11, _12, _13, _14;
	float _21, _22, _23, _24;
	float _31, _32, _33, _34;
	float _41, _42, _43, _44;
};

struct ColourRGBA
{
	ColourRGBA() {} // Default constructor
	ColourRGBA( float ir, float ig, float ib, float ia ) { r = ir; g = ig; b = ib; a = ia;} // Simple constructor
	float r, g, b, a;
};


//-----------------------------------------------------------------------------
// Movement / rotation definitions
//-----------------------------------------------------------------------------

// Angular helper functions to convert from degrees to radians and back
const float Pi = 3.14159f;
inline float ToRadians( float deg ) { return deg * Pi / 180.0f; }
inline float ToDegrees( float rad ) { return rad * 180.0f / Pi; }

// Move speed constants
const float MoveSpeed = 0.6f;
const float RotSpeed = 1.5f; // Angles in degrees in OpenGL
