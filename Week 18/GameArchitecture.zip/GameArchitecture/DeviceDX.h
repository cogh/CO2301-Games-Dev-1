/**********************************************
	DeviceDX.h

	Declaration of device class for DirectX
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include <d3d9.h>  // DirectX headers
#include <d3dx9.h>

#include "Device.h" // Base (interface) class definition

//-----------------------------------------------------------------------------
// DirectX device class defintition
//-----------------------------------------------------------------------------

// Inherits from interface class - providing implementation for DirectX
class CDeviceDX : public IDevice
{
/////////////////////////////
// Public member functions
public:

	// No constructors or destructors used - Startup/Shutdown functions used instead


	/////////////////////////////
	// Direct3D initialisation

	// Initialise Direct3D in the given window
	bool Startup( HWND hWnd );

	// Uninitialise Direct3D
	void Shutdown();


	/////////////////////////////
	// Game loop support

	// Set the overall ambient lighting for the scene
	void SetAmbientLight( float r, float g, float b );

	// Begin rendering the scene into the back-buffer, returns true on success
	bool BeginScene();

	// Clear the back buffer with given colour, also clear z buffer
	void Clear( float r, float g, float b );

	// Finish rendering the scene
	void EndScene();

	// Copy/flip the back-buffer contents to the display (front-buffer)
	void DisplayScene();


	/////////////////////////////
	// Resource factories

	// Factories to create cameras, models and lights of the same type as the device (DX or GL)
	// Pass similar parameters to the object constructors
	ICamera* CreateCamera( float posX = 0.0f, float posY = 0.0f, float posZ = 0.0f,
	                       float rotX = 0.0f, float rotY = 0.0f, float rotZ = 0.0f, 
	                       float nearClip = 0.1f, float farClip = 10000.0f );
	IModel* CreateModel();
	ILight* CreateLight( int number, float x = 0.0f, float y = 0.0f, float z = 0.0f,
	                     float r = 1.0f, float g = 1.0f, float b = 1.0f,  
			             float bright = 100.0f,  bool hasModel = true );


/////////////////////////////
// Private member variables
private:

	// Direct3D interface - used to create the global D3DDevice
	LPDIRECT3D9 m_pD3D;
};
