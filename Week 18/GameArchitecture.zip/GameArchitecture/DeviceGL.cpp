/*******************************************
	OpenGL.cpp

	Simple OpenGL renderer
********************************************/

#include "DefinesGL.h" // General definitions for OpenGL files

// Implementation classes that this device can create
#include "ModelGL.h"  // OpenGL Model
#include "CameraGL.h" // OpenGL Camera
#include "LightGL.h"  // OpenGL Light

#include "DeviceGL.h" // Declaration of this class

// OpenGL doesn't need a global variable like DirectX since it is state based. This
// makes for a cleaner architecture but can be a problem - any part of the code
// can access and alter device state, which can lead to mix-ups or bugs


//-----------------------------------------------------------------------------
// OpenGL initialisation
//-----------------------------------------------------------------------------

// Setup OpenGL in given window. Identifies suitable pixel format (colour & z bit-depth)
// for rendering to suit the window. Then sets up a *Rendering Context* using the given
// window and this pixel format (effectively a rendering buffer). Then OpenGL is set to
// use this as the current rendering context. Differs from DirectX setup in that there
// is no device to create - but in fact the current rendering context operates rather
// like a "globally defined" device
bool CDeviceGL::Startup( HWND hWnd )
{
	// Get the windows device context. This is a Windows handle used for most drawing, it is
	// used frequently in the setup to link the OpenGL rendering context to the actual window
	m_hWnd = hWnd;
	m_hDC = GetDC( m_hWnd );

	// First set the OpenGL viewport to the size of the window we created
	RECT clientRect;
	GetClientRect( m_hWnd, &clientRect );
	glViewport( 0, 0, clientRect.right, clientRect.bottom );

	// Now we need to find the pixel format to match the window we have created. We provide
	// the pixel format we would like in a PIXELFORMATDESCRIPTOR, then ask GL to get the best
	// available match using the ChoosePixelFormat function
	PIXELFORMATDESCRIPTOR desiredFormat; // Our desired pixel format
	memset(&desiredFormat, 0, sizeof(PIXELFORMATDESCRIPTOR));
    desiredFormat.nSize      = sizeof(PIXELFORMATDESCRIPTOR);
    desiredFormat.nVersion   = 1; // Must be set to 1
    desiredFormat.iPixelType = PFD_TYPE_RGBA; // RGB colours or paletted (legacy)
    desiredFormat.cColorBits = 32; // Total bits for pixel colour (32 suggests R8G8B8A8)
	desiredFormat.cDepthBits = 16; // Total bits for pixel depth values
	
	// Various flags available - here indicating OpenGL drawing (rather than native windows drawing),
	// windowed mode and double buffer (i.e. = a front buffer and a back buffer in DirectX speak)
    desiredFormat.dwFlags    = PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW | PFD_DOUBLEBUFFER;

	// Now get the nearest supported pixel format to the one we have set up
	GLuint iNearestFormat = ChoosePixelFormat( m_hDC, &desiredFormat ); // Return value is a (1-based) index
	                                                                    // into the available pixel formats

	// Quit if no supported format was available
	if( iNearestFormat == 0 )
	{
		return false;
	}

	// Now get the full specification for the returned nearest pixel format
	PIXELFORMATDESCRIPTOR nearestFormat;
	DescribePixelFormat( m_hDC, iNearestFormat, sizeof(nearestFormat), &nearestFormat );

	// Check our own requirements on the returned format
	if( nearestFormat.cDepthBits < desiredFormat.cDepthBits ) // Ensure enough depth bits
	{
		return false;
	}

	// Use this nearest pixel format (need to pass both format index and structure)
	if (!SetPixelFormat( m_hDC, iNearestFormat, &nearestFormat))
	{
		return false;
	}

	// Get the OpenGL rendering context for the window and make it current
	m_hRC = wglCreateContext( m_hDC );
	wglMakeCurrent( m_hDC, m_hRC );
	
	// Finally set some rendering states - mostly self explanatory
    glEnable( GL_DEPTH_TEST );
	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );
	glEnable( GL_LIGHTING );

	// Enable correct specular with textures (OpenGL 1.2 and above only)
	//glLightModeli( GL_LIGHT_MODEL_COLOR_CONTROL,GL_SEPARATE_SPECULAR_COLOR );
	
	return true;
}


// Uninitialise OpenGL
void CDeviceGL::Shutdown()
{
	// Release OpenGL and windows interfaces
	if( m_hRC != NULL )
	{
		wglMakeCurrent( NULL, NULL );
		wglDeleteContext( m_hRC );
		m_hRC = NULL;
	}

	if( m_hDC != NULL )
	{
		ReleaseDC( m_hWnd, m_hDC );
		m_hDC = NULL;
	}
}


//-----------------------------------------------------------------------------
// Game loop support
//-----------------------------------------------------------------------------

// Set the overall ambient lighting for the scene
void CDeviceGL::SetAmbientLight( float r, float g, float b )
{
	ColourRGBA ambient( r, g, b, 1.0f );
	glLightModelfv( GL_LIGHT_MODEL_AMBIENT, &ambient.r );
}


// Begin rendering the scene into the back-buffer, returns true on success
bool CDeviceGL::BeginScene()
{
	// Nothing to do for OpenGL
    return true;
}

// Clear the back buffer with given colour, also clear z buffer / stencil
void CDeviceGL::Clear( float r, float g, float b )
{
	glClearColor( r, g, b, 1.0f );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );
}

// Finish rendering the scene
void CDeviceGL::EndScene()
{
	// Nothing to do for OpenGL
}

// Copy/flip the back-buffer contents to the display (front-buffer)
void CDeviceGL::DisplayScene()
{
	SwapBuffers( m_hDC );
}


//-----------------------------------------------------------------------------
// Resource factories
//-----------------------------------------------------------------------------

// Factories to create cameras, models and lights of the same type as the device (DX or GL)
// Pass same parameters as the object constructors
ICamera* CDeviceGL::CreateCamera( float posX, float posY, float posZ,
	                              float rotX, float rotY, float rotZ, 
	                              float nearClip, float farClip )
{
	return new CCameraGL( posX, posY, posZ,  rotX, rotY, rotZ,  nearClip, farClip );
}

IModel* CDeviceGL::CreateModel()
{
	return new CModelGL();
}

ILight* CDeviceGL::CreateLight( int number, float x, float y, float z,
	                            float r, float g, float b,  
			                    float bright,  bool hasModel )
{
	return new CLightGL( number,  x, y, z,  r, g, b,  bright,  hasModel );
}
