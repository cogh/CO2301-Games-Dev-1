/**********************************************
	DeviceGL.h

	Declaration of device class for OpenGL
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include "Device.h"    // Base (interface) class definition

//-----------------------------------------------------------------------------
// DirectX device class defintition
//-----------------------------------------------------------------------------

// Inherits from interface class - providing implementation for OpenGL
class CDeviceGL : public IDevice
{
/////////////////////////////
// Public member functions
public:

	// No constructors or destructors used - Startup/Shutdown functions used instead


	/////////////////////////////
	// OpenGL initialisation

	// Initialise OpenGL in the given window
	bool Startup( HWND hWnd );

	// Uninitialise OpenGL
	void Shutdown();


	/////////////////////////////
	// Game loop support

	// Set the overall ambient lighting for the scene
	void SetAmbientLight( float r, float g, float b );

	// Begin rendering the scene into the back-buffer, returns true on success
	bool BeginScene();

	// Clear the back buffer with given colour, also clear z buffer / stencil
	void Clear( float r, float g, float b );

	// Finish rendering the scene
	void EndScene();

	// Copy/flip the back-buffer contents to the display (front-buffer)
	void DisplayScene();


	/////////////////////////////
	// Resource factories

	// Factories to create cameras, models and lights of the same type as the device (DX or GL)
	// Pass similar parameters to the object constructors
	ICamera* CreateCamera( float posX = 0.0f, float posY = 0.0f, float posZ = 0.0f,
	                       float rotX = 0.0f, float rotY = 0.0f, float rotZ = 0.0f, 
	                       float nearClip = 0.1f, float farClip = 10000.0f );
	IModel* CreateModel();
	ILight* CreateLight( int number, float x = 0.0f, float y = 0.0f, float z = 0.0f,
	                     float r = 1.0f, float g = 1.0f, float b = 1.0f,  
			             float bright = 100.0f,  bool hasModel = true );


/////////////////////////////
// Private member variables
private:

	// Windows interface
	HWND  m_hWnd; // Window handle
	HDC   m_hDC;  // Window device context

	// OpenGL interface
	HGLRC m_hRC;  // OpenGL rendering context
};
