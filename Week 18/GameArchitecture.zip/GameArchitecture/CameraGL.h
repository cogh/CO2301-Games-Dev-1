/**********************************************
	CameraGL.h

	Declaration of camera class for OpenGL
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include "DefinesGL.h" // General definitions for OpenGL files
#include "Camera.h"    // Base (interface) class definition

//-----------------------------------------------------------------------------
// OpenGL Camera Class Defintition
//-----------------------------------------------------------------------------

// Inherits from interface class - providing implementation for OpenGL
class CCameraGL : public ICamera
{
/////////////////////////////
// Public member functions
public:

	///////////////////////////////
	// Constructors / Destructors

	// Constructor
	CCameraGL( float posX = 0.0f, float posY = 0.0f, float posZ = 0.0f,
	           float rotX = 0.0f, float rotY = 0.0f, float rotZ = 0.0f, 
	           float nearClip = 0.1f, float farClip = 10000.0f );


	/////////////////////////////
	// Setters

	void SetPosition( float x, float y, float z );
	void SetRotation( float x, float y, float z );
	void SetNearFarClip( float nearClip, float farClip );


	/////////////////////////////
	// Camera Usage

	// Setup view and projection matrices for the camera
	void SetViewProjMatrices();

	// Controls the camera - uses the current view matrix for local movement
	void Control( EKeyCode turnUp, EKeyCode turnDown,
	              EKeyCode turnLeft, EKeyCode turnRight,  
	              EKeyCode moveForward, EKeyCode moveBackward,
	              EKeyCode moveLeft, EKeyCode moveRight );


/////////////////////////////
// Private member variables
private:

	// Postition and rotations for the camera (using DirectX vector types)
	Vector3   m_Position;
	Vector3   m_Rotation;

	// Near and far clip plane distances
	float     m_NearClip;
	float     m_FarClip;

	// Current view matrix
	Matrix4x4 m_MatView;
};

