/**********************************************
	DirectX.cpp

	Implementation of device class for DirectX
***********************************************/

#include "DefinesDX.h" // General definitions for DirectX files

// Implementation classes that this device can create
#include "ModelDX.h"  // DirectX Model
#include "CameraDX.h" // DirectX Camera
#include "LightDX.h"  // DirectX Light

#include "DeviceDX.h" // Declaration of this class


//-----------------------------------------------------------------------------
// DirectX global variable
//-----------------------------------------------------------------------------

/***| INFO |*******************************************************************
// Can't make the rendering device a CDeviceDX member variable, since the other
// DX classes need to access it. In this case it is left as a global - better
// solutions include:
// - Pass it as a parameter to created models, cameras & lights
// - Pass a CDevice* as a parameter to models, cameras & lights & use a getter
// - Pass a CDevice* to models, cameras & lights and have them call CDevice 
//   member functions for DirectX device work
******************************************************************************/
LPDIRECT3DDEVICE9  g_pd3dDevice = NULL;


//-----------------------------------------------------------------------------
// D3D initialisation
//-----------------------------------------------------------------------------

// Initialise Direct3D in given window
bool CDeviceDX::Startup( HWND hWnd )
{
    // Create the D3D object.
    m_pD3D = Direct3DCreate9( D3D_SDK_VERSION );
	if (!m_pD3D)
	{
        return false;
	}

    // Set up the structure used to create the D3DDevice
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE; // Wait for vertical sync
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;                    // Use desktop pixel format (windowed mode)
    d3dpp.BackBufferCount = 1;
    d3dpp.EnableAutoDepthStencil = TRUE;         // Create depth buffer (Z)
    d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8; // 24-bit Z buffer + 8-bit stencil buffer

    // Create the D3DDevice
    if (FAILED(m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                     D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                     &d3dpp, &g_pd3dDevice )))
    {
        return false;
    }

	// Turn on tri-linear filtering for texture
    g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    g_pd3dDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );

	// Enable specular lighting
	g_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, TRUE );

	return true;
}


// Uninitialise D3D
void CDeviceDX::Shutdown()
{
	// Release D3D interfaces
    SAFE_RELEASE( g_pd3dDevice );
    SAFE_RELEASE( m_pD3D );
}


//-----------------------------------------------------------------------------
// Game loop support
//-----------------------------------------------------------------------------

// Render the overall ambient lighting for the scene
void CDeviceDX::SetAmbientLight( float r, float g, float b )
{
	D3DXCOLOR ambient( r, g, b, 1.0f );
	g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, ambient );
}


// Begin rendering the scene into the back-buffer, returns true on success
bool CDeviceDX::BeginScene()
{
    return SUCCEEDED(g_pd3dDevice->BeginScene());
}

// Clear the back buffer with given colour, also clear z buffer / stencil
void CDeviceDX::Clear( float r, float g, float b )
{
	D3DXCOLOR background( r, g, b, 1.0f );
	g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL,
	                     background, 1.0f, 0 );
}

// Finish rendering the scene
void CDeviceDX::EndScene()
{
	g_pd3dDevice->EndScene();
}

// Copy/flip the back-buffer contents to the display (front-buffer)
void CDeviceDX::DisplayScene()
{
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}


//-----------------------------------------------------------------------------
// Resource factories
//-----------------------------------------------------------------------------

// Factories to create cameras, models and lights of the same type as the device (DX or GL)
// Pass similar parameters to object constructors
ICamera* CDeviceDX::CreateCamera( float posX, float posY, float posZ,
	                              float rotX, float rotY, float rotZ, 
	                              float nearClip, float farClip )
{
	return new CCameraDX( posX, posY, posZ,  rotX, rotY, rotZ,  nearClip, farClip );
}

IModel* CDeviceDX::CreateModel()
{
	return new CModelDX();
}

ILight* CDeviceDX::CreateLight( int number, float x, float y, float z,
	                            float r, float g, float b,  
			                    float bright,  bool hasModel )
{
	return new CLightDX( number,  x, y, z,  r, g, b,  bright,  hasModel );
}
