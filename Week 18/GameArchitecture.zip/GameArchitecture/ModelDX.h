/**********************************************
	ModelDX.h

	Declaration of model class for DirectX
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include <string>
using namespace std;

#include "DefinesDX.h" // General definitions for DirectX files
#include "Model.h"     // Base (interface) class definition

//-----------------------------------------------------------------------------
// DirectX Model Class
//-----------------------------------------------------------------------------

// Inherits from interface class - providing implementation for DirectX
class CModelDX : public IModel
{
/////////////////////////////
// Public member functions
public:

	///////////////////////////////
	// Constructors / Destructors

	// Constructor
	CModelDX();

	// Destructor
	~CModelDX();

	// Release resources used by model
	void ReleaseResources();


	/////////////////////////////
	// Setters

	void SetPosition( float x, float y, float z );
	void SetRotation( float x, float y, float z );
    void SetScale( float scale );

	// Point the model in a given direction, assumes ZXY rotation order
	void SetDirection( float x, float y, float z );


	/////////////////////////////
	// Model loading

	// Load the model geometry from a file
	bool Load( const string& fileName );


	/////////////////////////////
	// Model texture / material

	// Set material colour and specular power (set 0 power for no specular highlights)
	void SetMaterial( float r, float g, float b, float specularPower = 0.0f );

	// Load a single texture for the whole model (ignores textures in model file)
	// Returns true on success
	bool LoadTexture( const string& fileName );


	/////////////////////////////
	// Model Usage

	// Render the model
	void Render();
	
	// Control the model using keys
	void Control( EKeyCode turnUp, EKeyCode turnDown,
				  EKeyCode turnLeft, EKeyCode turnRight,  
				  EKeyCode turnCW, EKeyCode turnCCW,
				  EKeyCode moveForward, EKeyCode moveBackward );


/////////////////////////////
// Private support functions
private:

	// Prepare model world matrix for rendering
	void PrepareWorldMatrix();

	// Prepare model material and texture for rendering
	void PrepareMaterialTexture();


/////////////////////////////
// Private member variables
private:

	// Vertex data for the model stored in a vertex buffer and the number / size of
	// the vertices in the buffer
	LPDIRECT3DVERTEXBUFFER9 m_VertexBuffer;
	unsigned int            m_NumVertices;

	// Description of the elements in a single vertex (position, normal etc.)
	// Using both FVF (legacy) and vertex declaration (shader) styles
	DWORD                   m_VertexFVF;  // FVF for fixed pipeline (legacy, no shader)
	D3DVERTEXELEMENT9       m_VertexElts[MAX_FVF_DECL_SIZE];
    LPDIRECT3DVERTEXDECLARATION9 m_pVertexDeclaration; // Vertex declaration for shaders
	unsigned int            m_VertexSize; // Size of vertex calculated from contained elements

	// Index data for the model stored in a index buffer and the number of
	// indices in the buffer
	LPDIRECT3DINDEXBUFFER9  m_IndexBuffer;
	unsigned int            m_NumIndices;

	// Does this model have any geometry to render
	bool                    m_HasGeometry;

	// Material and texture used for this model - materials only relevant when not using shaders
	D3DMATERIAL9       m_Material; // Defaults to white material
	LPDIRECT3DTEXTURE9 m_Texture;  // Defaults to no texture

	// Positions, rotations and scaling for the model
	D3DXVECTOR3   m_Position;
	D3DXVECTOR3   m_Rotation;
	float         m_Scale;

	// World matrix for the model - built from the above
	D3DXMATRIX m_Matrix;
};
