/*******************************************
	MainApp.cpp

	Multi-API renderer supporting DirectX
	and OpenGL
********************************************/

#include <math.h>
#include <windows.h>

// Interfaces used for renderer
#include "Device.h" // Render device interface
#include "Model.h"  // Model interface
#include "Camera.h" // Camera interface
#include "Light.h"  // Light interface

#include "DeviceFactory.h" // Factory function to create the main CDevice object

#include "Input.h"    // Input support
#include "Resource.h" // Resource file (used to add icon for application)


//-----------------------------------------------------------------------------
// Constants
//-----------------------------------------------------------------------------

const int NumLights = 2;
const float LightOrbit = 15.0f; // Controls orbiting light
const float LightSpeed = 0.01f; // -"-


//*****************************************************************************
// Interface class objects
//*****************************************************************************

// Render device - main class that controls the graphics API (DirectX or OpenGL)
// as well as allowing the creation of models, cameras and lights suitable for
// that API. This is an interface class - the object must be created with a 
// factory function
IDevice* RenderDevice;

// Camera - an interface class, the object must be created with the render device above
ICamera* MainCamera;

// Models - interface class, objects created with the render device above
IModel* Teapot  = NULL;
IModel* Ground = NULL;

// Lights - interface class, objects created with the render device above
ILight* Lights[NumLights];


//-----------------------------------------------------------------------------
// Scene management
//-----------------------------------------------------------------------------

// Creates the scene geometry
bool SceneSetup()
{
	// Create camera - use device object to create camera of correct type (DX or GL)
	MainCamera = /*MISSING*/;
	MainCamera->SetPosition( -20.0f, 50.0f, 110.0f );
	MainCamera->SetRotation( 20.0f, 165.0f, 0.0f );
	MainCamera->SetNearFarClip( 0.1f, 10000.0f );


	// Create and load models - use device object to create models of correct type (DX or GL)
	Teapot = RenderDevice->CreateModel();
	Ground = RenderDevice->CreateModel();
	if (!Teapot->Load( "Teapot.x" ) || !Ground->Load( "Hills.x" ))
	{
		return false;  // Return on failure
	}
	if (!Ground->LoadTexture( "Grass" ) || !Teapot->LoadTexture( "Stone" )) // File extensions added by device specific code
	{
		return false;  // Return on failure
	}
	Teapot->SetPosition( 10.0f, 20.0f, 20.0f );
	Teapot->SetMaterial( 1.0f, 0.6f, 0.3f, 0 ); // Make teapot orange and matte
	Ground->SetMaterial( 0.5f, 0.8f, 0.4f, 0 );  // Make ground green and matte

    // Set up lights - use device object to create lights of correct type (DX or GL)
	Lights[0] = RenderDevice->CreateLight( 0,  LightOrbit,15, 0,  1,1.0f,1.0f,   100 ); 
	Lights[1] = RenderDevice->CreateLight( 1,  -30,       30,60,  1,0.9f,0.2f,  1000 ); 

	return true;
}

// Release everything in the scene
void SceneShutdown()
{
	for (int light = NumLights - 1; light >= 0; --light)
	{
		delete Lights[light];
		Lights[light] = 0;
	}
	delete Ground;
	Ground = 0;
	delete Teapot;
	Teapot = 0;
	delete MainCamera;
	MainCamera = 0;
}


//-----------------------------------------------------------------------------
// Game loop functions
//-----------------------------------------------------------------------------

// Render the models in the scene with given camera
void RenderModels( ICamera* camera )
{
	// Set ambient lighting
	RenderDevice->SetAmbientLight( 0.3f, 0.3f, 0.3f );

	// Enable each light
	for (int light = 0; light < NumLights; ++light)
	{
		Lights[light]->Enable();
	}

	// Render each model
	Ground->Render();
	Teapot->Render();
}


// Render scene lights with given camera
// This does not mean calculate lighting - just draw a model for each light
void RenderLights( ICamera* camera )
{
	// Set maximum ambient lighting - fully lit always
	RenderDevice->SetAmbientLight( 1.0f, 1.0, 1.0f ); // White ambient

	// Disable individual lights - lights don't affect themselves
	for (int light = 0; light < NumLights; ++light)
	{
		Lights[light]->Disable();
	}

	// Render each light
	for (int light = 0; light < NumLights; ++light)
	{
		Lights[light]->Render();
	}
}

// Render the scene into the back-buffer
void RenderScene()
{
    // Begin rendering the scene
    if (RenderDevice->BeginScene())
    {
		// Clear the back buffer to the background colour (and clear z buffer)
		RenderDevice->Clear( 0.3f, 0.3f, 0.3f );

		// Render scene elements
		MainCamera->SetViewProjMatrices();
		RenderModels( MainCamera );
		RenderLights( MainCamera );

		// Finished rendering the scene
        RenderDevice->EndScene();
    }

	// Display the rendered scene
	RenderDevice->DisplayScene();
}


// Update the scene between rendering
void UpdateScene()
{
	// Move the camera with keys
	MainCamera->Control( Key_Up, Key_Down, Key_Left, Key_Right, Key_W, Key_S, Key_A, Key_D );

	// Move the teapot with keys
	Teapot->Control( Key_I, Key_K, Key_J, Key_L, Key_U, Key_O, Key_Period, Key_Comma );

	// First light follows an orbit
	static float Rotate = 0.0f;
	Lights[0]->SetPosition( cosf(Rotate) * LightOrbit + 10.0f, 20.0f,
	                        sinf(Rotate) * LightOrbit + 20.0f );
	Rotate -= LightSpeed;

	// Second light can be controlled
	Lights[1]->Control( Key_Numpad8, Key_Numpad2, Key_Numpad4, Key_Numpad6, Key_Numpad3, Key_Numpad1 );
}


//-----------------------------------------------------------------------------
// Windows functions
//-----------------------------------------------------------------------------

// Window message handler
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_DESTROY:
            PostQuitMessage( 0 );
            return 0;

		case WM_KEYDOWN:
			KeyDownEvent( static_cast<EKeyState>(wParam) );
			break;

		case WM_KEYUP:
			KeyUpEvent( static_cast<EKeyState>(wParam) );
			break;
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}


// Windows main function
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    // Register the window class (adding our own icon to this window)
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
                      GetModuleHandle(NULL), LoadIcon( hInst, MAKEINTRESOURCE(IDI_TL) ),
					  LoadCursor( NULL, IDC_ARROW ), NULL, NULL,
                      "GameArchitecture", NULL };
    RegisterClassEx( &wc );

    // Create the application's window
	HWND hWnd = CreateWindow( "GameArchitecture", "CO2301 Games Development 1: Game Architecture",
                              WS_OVERLAPPEDWINDOW, 100, 100, 1024, 768,
                              NULL, NULL, wc.hInstance, NULL );


	//************************************************************************
	// Use a factory function to create a render device of a particular type
	//************************************************************************
	/*MISSING - initialise RenderDevice*/

    // Validate and initialize render device
    if (RenderDevice && RenderDevice->Startup( hWnd ))
    {
        // Prepare the scene
        if (SceneSetup())
        {
            // Show the window
            ShowWindow( hWnd, SW_SHOWDEFAULT );
            UpdateWindow( hWnd );

            // Enter the message loop
            MSG msg;
            ZeroMemory( &msg, sizeof(msg) );
            while( msg.message != WM_QUIT )
            {
                if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
                {
                    TranslateMessage( &msg );
                    DispatchMessage( &msg );
                }
                else
				{
					// Render and update the scene
                    RenderScene();
					UpdateScene();
					if (KeyHeld( Key_Escape ))
					{
						DestroyWindow( hWnd );
					}
				}
            }
        }
	    SceneShutdown();
    }
	/*MISSING*/->Shutdown();

	UnregisterClass( "GameArchitecture", wc.hInstance );
    return 0;
}
