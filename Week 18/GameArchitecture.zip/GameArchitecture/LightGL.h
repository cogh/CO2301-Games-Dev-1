/*******************************************
	LightGL.h

	Declaration of point light class for
	OpenGL
********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include "DefinesGL.h" // General definitions for OpenGL files
#include "ModelGL.h"   // Model class - no need to use interface class here
#include "Light.h"     // Base (interface) class definition

//-----------------------------------------------------------------------------
// Light class defintition
//-----------------------------------------------------------------------------

// Inherits from interface class - providing implementation for OpenGL
class CLightGL : public ILight
{
/////////////////////////////
// Public member functions
public:

	///////////////////////////////
	// Constructors / Destructors

	// Pass light's number, position, colour and brightness. May specify if a model should be
	// shown for the light. Defaults to white light at origin with a model
	CLightGL( int number, float x = 0.0f, float y = 0.0f, float z = 0.0f,
	          float r = 1.0f, float g = 1.0f, float b = 1.0f,  
			  float bright = 100.0f,  bool hasModel = true );

	~CLightGL()
	{
		delete m_Model;
	}


	/////////////////////////////
	// Data access

	// Setters
	void SetPosition( float x, float y, float z );
	void SetColour( float r, float g, float b );
	void SetBrightness( float bright );


	/////////////////////////////
	// Light Usage

	// Enable the light
	void Enable();
	
	// Disable the light
	void Disable();

	// Render any light model for this light
	void Render();

	// Control the light with keys
	void Control( EKeyCode moveForward, EKeyCode moveBackward,
                  EKeyCode moveLeft, EKeyCode moveRight,
                  EKeyCode moveUp, EKeyCode moveDown );


/////////////////////////////
// Private member variables
private:

	// Light number - each light has a unique number - OpenGL uses special constants
	GLenum     m_Number;

	// Light settings
	Vector3    m_Position;

	// Optional model for the light - no need to use interface class here
	CModelGL*  m_Model;
};

