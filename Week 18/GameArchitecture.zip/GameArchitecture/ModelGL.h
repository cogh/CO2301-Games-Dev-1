/**********************************************
	ModelGL.h

	Declaration of model class for OpenGL
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include <string>
using namespace std;

#include "DefinesGL.h" // General definitions for OpenGL files
#include "Model.h"     // Base (interface) class definition

//-----------------------------------------------------------------------------
// OpenGL Model Class
//-----------------------------------------------------------------------------

// Inherits from interface class - providing implementation for OpenGL
class CModelGL : public IModel
{
/////////////////////////////
// Public member functions
public:

	///////////////////////////////
	// Constructors / Destructors

	// Constructor
	CModelGL();

	// Destructor
	~CModelGL();

	// Release resources used by model
	void ReleaseResources();


	/////////////////////////////
	// Setters

	void SetPosition( float x, float y, float z );
	void SetRotation( float x, float y, float z );
    void SetScale( float scale );

	// Point the model in a given direction, assumes ZXY rotation order
	void SetDirection( float x, float y, float z );


	/////////////////////////////
	// Model loading

	// Load the model geometry from a file
	bool Load( const string& fileName );


	/////////////////////////////
	// Model texture / material

	// Set material colour and specular power (set 0 power for no specular highlights)
	void SetMaterial( float r, float g, float b, float specularPower = 0.0f );

	// Load a single texture for the whole model (ignores textures in model file)
	// Returns true on success
	bool LoadTexture( const string& fileName );


	/////////////////////////////
	// Model Usage

	// Render the model
	void Render();
	
	// Control the model using keys
	void Control( EKeyCode turnUp, EKeyCode turnDown,
				  EKeyCode turnLeft, EKeyCode turnRight,  
				  EKeyCode turnCW, EKeyCode turnCCW,
				  EKeyCode moveForward, EKeyCode moveBackward );


/////////////////////////////
// Private support functions
private:

	// Prepare model world matrix for rendering
	void PrepareWorldMatrix();

	// Prepare model material and texture for rendering
	void PrepareMaterialTexture();


/////////////////////////////
// Private member variables
private:

	// Vertex data for the model stored in a dynamic array and the number / size of
	// the vertices in the buffer
	void*           m_Vertices;     // Void pointer as vertex type can be customised
	unsigned int    m_NumVertices;
	GLenum          m_VertexFormat; // OpenGL constant for vertex format
	unsigned int    m_VertexSize;

	// Index data for the model stored in a dynamic array and the number of
	// indices in the buffer
	unsigned short* m_Indices;
	unsigned int    m_NumIndices;

	// Does this model have any geometry to render
	bool            m_HasGeometry;


	// Material used for this model
	ColourRGBA m_Colour;
	float      m_SpecularPower;
	GLuint     m_Texture;  // Defaults to no texture


	// Positions, rotations and scaling for the model
	Vector3   m_Position;
	Vector3   m_Rotation;
	float     m_Scale;

	// World matrix for the model - built from the above
	Matrix4x4 m_Matrix;
};
