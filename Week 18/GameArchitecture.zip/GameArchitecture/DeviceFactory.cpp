/**********************************************
	DeviceFactory.cpp

	Factory function to create CDevice objects
***********************************************/

// Supported device classes, each inherits from CDevice
#include "DeviceDX.h" // DirectX device class
#include "DeviceGL.h" // OpenGL device class

#include "DeviceFactory.h" // Factory declarations

// Create a CDevice object of the given type
/*MISSING function*/