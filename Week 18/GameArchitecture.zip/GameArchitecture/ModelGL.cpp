/**********************************************
	ModelGL.cpp

	Implementation of model class for OpenGL
***********************************************/

#include "DefinesGL.h" // General definitions for OpenGL files
#include "ModelGL.h"   // Declaration of this class

#include "CImportXFile.h" // Class to load meshes (taken from a full graphics engine)

///////////////////////////////
// Constructors / Destructors

// Model constructor
CModelGL::CModelGL()
{
	// Initialise member variables
	m_Vertices = NULL;
	m_NumVertices = 0;
	m_VertexSize = 0;

	m_Indices = NULL;
	m_NumIndices = 0;

	m_HasGeometry = false;

	m_Colour = ColourRGBA( 1.0f, 1.0f, 1.0f, 1.0f );
	m_SpecularPower = 0.0f;
	m_Texture = -1;

	m_Position = Vector3( 0.0f, 0.0f, 0.0f );
	m_Rotation = Vector3( 0.0f, 0.0f, 0.0f );
	m_Scale = 1.0f;
}

// Model destructor
CModelGL::~CModelGL()
{
	ReleaseResources();
}

// Release resources used by model
void CModelGL::ReleaseResources()
{
	if (m_Texture != -1) glDeleteTextures( 1, &m_Texture );
	delete[] m_Indices;
	delete[] m_Vertices;
	m_HasGeometry = false;
}


/////////////////////////////
// Setters

// Note that all z positions and x/y rotations negated for right-handed system

void CModelGL::SetPosition( float x, float y, float z )
{
	m_Position = Vector3( x, y, -z );
}

void CModelGL::SetRotation( float x, float y, float z )
{
	m_Rotation = Vector3( -x, -y, z );
}

void CModelGL::SetScale( float scale )
{
	m_Scale = scale;
}

// Point the model in a given direction, assumes ZXY rotation order
void CModelGL::SetDirection( float x, float y, float z )
{
	// A little geometry to convert a direction vector to X and Y rotations, sets Z rotation to 0
	float len = sqrt( x*x + z*z );
	if (len > 0.0005f)
	{
		// Angles in degrees for OpenGL
		m_Rotation.x = ToDegrees( atan2f( y, -len ) );
		m_Rotation.y = ToDegrees( -atan2f( -x, -z ) );
		m_Rotation.z = 0.0f;
	}
	else
	{
		m_Rotation.x = ((y > 0.0f) ? -90.0f : 90.0f);
		m_Rotation.y = m_Rotation.z = 0.0f;
	}
	return;
}


/////////////////////////////
// Model Loading / Creation

// Load the model geometry from a file. This model class only supports a single material 
// per model. Real world models often use several materials for different parts of the
// geometry. This function only reads the geometry using the first material in the file,
// so multi-material models will load but will have parts missing
bool CModelGL::Load( const string& fileName )
{
	// Release any existing geometry
	ReleaseResources();

	// Use CImportXFile class (from another application) to load the given file
	// The import code is wrapped in the namespace 'gen'
	gen::CImportXFile mesh;
	if (mesh.ImportFile( fileName.c_str() ) != gen::kSuccess)
	{
		return false;
	}

	// Get first sub-mesh from loaded file (specify no tangents required, right-handed system)
	gen::SSubMesh subMesh;
	if (mesh.GetSubMesh( 0, &subMesh, false, false ) != gen::kSuccess)
	{
		return false;
	}

	// OpenGL vertex format constants and sizes
	const GLenum glVertexFormats[] = { GL_V3F,     GL_C4UB_V3F, GL_T2F_V3F,     0, 
	                                   GL_N3F_V3F, 0,           GL_T2F_N3F_V3F, 0 };
	const GLenum glVertexSizes[] = { 12, 16, 20, 0,  24, 0, 32, 0 };

	// Calculate vertex format and size based on mesh data
	int formatIndex = (subMesh.hasVertexColours ? 1 : 0) | 
	                  (subMesh.hasTextureCoords ? 2 : 0) |
	                  (subMesh.hasNormals ? 4 : 0);
	m_VertexFormat = glVertexFormats[formatIndex];
	m_VertexSize = glVertexSizes[formatIndex];
	if (m_VertexFormat == 0) // 0 indicates an unsupported format
    {
        return false;
    }

	// Create the vertex array (as an array of bytes)
	m_NumVertices = subMesh.numVertices;
	unsigned int vertexArraySize = m_NumVertices * m_VertexSize;
	m_Vertices = new char[vertexArraySize];
    if (!m_Vertices)
	{
        return false;
	}

	// Copy the vertex data from the sub-mesh
	// Copy the vertex data
    memcpy( m_Vertices, subMesh.vertices, vertexArraySize );


    // Create the index array - assuming 2-byte index data
	m_NumIndices = static_cast<unsigned int>(subMesh.numFaces) * 3;
	m_Indices = new unsigned short[m_NumIndices];
    if (!m_Indices)
    {
		delete[] m_Vertices;
        return false;
    }

	// Copy the index data from the sub-mesh
	memcpy( m_Indices, subMesh.faces, m_NumIndices * sizeof(unsigned short) );

	m_HasGeometry = true;
	return true;
}


/////////////////////////////
// Model texture / material

// Set material colour and specular power (set 0 power for no specular highlights)
void CModelGL::SetMaterial( float r, float g, float b, float specularPower )
{
	m_Colour = ColourRGBA( r, g, b, 1.0f );
	m_SpecularPower = specularPower;
}


// Load a single texture for the whole model (ignores textures in model file)
// Returns true on success
bool CModelGL::LoadTexture( const string& fileName )
{
	// Add extension used for textures on this device
	string fullFileName = fileName + ".raw";

	// Open texture file
	FILE* file = fopen( fullFileName.c_str(), "rb" );
	if ( file == NULL )
	{
		return false;
	}

	// Load texture data into temporary buffer. For simplicity, assuming textures are RAW 512x512 textures.
	// Would have to parse other file types or use an OpenGL extension
	unsigned int width = 512;
	unsigned int height = 512;
	char* data = new char[width * height * 3];
	fread( data, width * height * 3, 1, file );
	fclose( file );

	// Create 1 texture and select it for use in the next few statements
	glGenTextures( 1, &m_Texture );
	glBindTexture( GL_TEXTURE_2D, m_Texture );

	// Modulate texture with material colour of polygon (modulate = multiplicative)
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	// OpenGL requires texture filtering and addressing set up with the texture, rather than at render time
	// Filtering - use nearest mip-map when texture is small (MIN), use first mip-map when it is large (MAX)
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

	// Set up wrapping mode (texture addressing mode in DirectX)
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );

	// Build mip-maps
	gluBuild2DMipmaps( GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, data );

	// Free temporary buffer used to load texture
	free( data );

	return true;
}


/////////////////////////////
// Model Usage

// Prepare model world matrix for rendering
void CModelGL::PrepareWorldMatrix()
{
	// OpenGL uses a combined world/view matrix (it calls it the model/view matrix) that is built
	// by repeatedly applying matrices to it. We assume that the camera's view matrix has already
	// been built during camera setup.
	// Switch to this matrix, push it's current state (containing just the view matrix) and
	// continue to accumulate the matrices needed for this model's world matrix
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();

	// Accumulate the model's world matrix (in reverse order from DirectX)
	glTranslatef( m_Position.x, m_Position.y, m_Position.z );  // Translation
	glRotatef( m_Rotation.y, 0.0f, 1.0f, 0.0f ); // Rotation around y axis
	glRotatef( m_Rotation.x, 1.0f, 0.0f, 0.0f ); // -"- x axis
	glRotatef( m_Rotation.z, 0.0f, 0.0f, 1.0f ); // -"- z axis
	glScalef( m_Scale, m_Scale, m_Scale );  // Scaling 
}

// Prepare model material and texture for rendering
void CModelGL::PrepareMaterialTexture()
{
	// Set ambient and diffuse material colour (of front and back faces)
	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, &m_Colour.r );
	if (m_SpecularPower == 0.0f)
	{
		// Material has no specular light - set its specular colour to black
		ColourRGBA black( 0.0f, 0.0f, 0.0f, 1.0f );
		glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR, &black.r );
	}
	else
	{
		// Material uses specular light - set to white (allows light colour to reflect without tint)
		ColourRGBA white( 1.0f, 1.0f, 1.0f, 1.0f );
		glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR, &white.r );
		glMaterialf( GL_FRONT_AND_BACK, GL_SHININESS, m_SpecularPower );
	}

	// Enable/disable texturing depending on whether texture loaded and select texture for model
	if (m_Texture != -1)
	{
		glEnable( GL_TEXTURE_2D );
		glBindTexture( GL_TEXTURE_2D, m_Texture );
	}
	else
	{
		glDisable( GL_TEXTURE_2D );
	}
}

// Render the model
void CModelGL::Render()
{
	// Don't render if no geometry
	if (!m_HasGeometry)
	{
		return;
	}

	// Prepare for rendering
	PrepareWorldMatrix();
	PrepareMaterialTexture();

	// Set the model's vertex array as the source arrays for rendering. The vertex format
	// constant was m_VertexFormat was set up in the Load function above.
	// Similar to the DirectX functions SetStreamSource & SetFVF/SetVertexDeclaration
	glInterleavedArrays( m_VertexFormat, 0, m_Vertices );

	// Draw a set of indexed elements (primitives) - OpenGL can render a much wider range of
	// primitives including quads, arbritary polygons, line loops etc.
	// Otherwise this is equivalent to the DirectX functions SetIndices & DrawIndexedPrimitive
	glDrawElements( GL_TRIANGLES, m_NumIndices, GL_UNSIGNED_SHORT, m_Indices );

	// Pop the camera's view matrix for the next model
	glPopMatrix();
}


// Control the model using keys
void CModelGL::Control( EKeyCode turnUp, EKeyCode turnDown,
					  EKeyCode turnLeft, EKeyCode turnRight,  
					  EKeyCode turnCW, EKeyCode turnCCW,
					  EKeyCode moveForward, EKeyCode moveBackward )
{
	// The right-handed matrices of OpenGL effectively reverse the Z-axis, so any controls
	// that change z coordinates must be reversed (e.g. forward<->backward)
	if (KeyHeld( turnDown ))
	{
		m_Rotation.x -= RotSpeed;
	}
	if (KeyHeld( turnUp ))
	{
		m_Rotation.x += RotSpeed;
	}
	if (KeyHeld( turnRight ))
	{
		m_Rotation.y -= RotSpeed;
	}
	if (KeyHeld( turnLeft ))
	{
		m_Rotation.y += RotSpeed;
	}
	if (KeyHeld( turnCW ))
	{
		m_Rotation.z += RotSpeed;
	}
	if (KeyHeld( turnCCW ))
	{
		m_Rotation.z -= RotSpeed;
	}

	// Local Z movement - move in the direction of the Z axis, get axis from world matrix
	if (KeyHeld( moveForward ))
	{
		m_Position.x -= m_Matrix._31 * MoveSpeed;
		m_Position.y -= m_Matrix._32 * MoveSpeed;
		m_Position.z -= m_Matrix._33 * MoveSpeed;
	}
	if (KeyHeld( moveBackward ))
	{
		m_Position.x += m_Matrix._31 * MoveSpeed;
		m_Position.y += m_Matrix._32 * MoveSpeed;
		m_Position.z += m_Matrix._33 * MoveSpeed;
	}
}
