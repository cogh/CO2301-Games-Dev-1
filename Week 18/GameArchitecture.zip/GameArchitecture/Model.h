/**********************************************
	Model.h

	Interface for all model classes
***********************************************/

#pragma once // Prevent file being included more than once (would cause errors)

#include <string>
using namespace std;

#include "Input.h"

//-----------------------------------------------------------------------------
// IModel interface 
//-----------------------------------------------------------------------------

// Implementation classes will inherit from this interface
class IModel
{
/////////////////////////////
// Public member functions
public:

	///////////////////////////////
	// Constructors / Destructors

	// Don't need a constructor for a pure interface (no member variables)

	// Must always have a virtual destructor when there are other virtual functions
	virtual ~IModel() {} // However, nothing to do for an interface


	// All functions are virtual and pure (= 0 at end - means no implementation for this class)
	// Can't directly create an object of this class (e.g. myModel = new CModel; // Error)
	// Can only create inherited classes (e.g. CCameraDX) - use the CDevice class to do this

	// Release resources used by model
	virtual void ReleaseResources() = 0;


	/////////////////////////////
	// Setters

	virtual void SetPosition( float x, float y, float z ) = 0;
	virtual void SetRotation( float x, float y, float z ) = 0;
    virtual void SetScale( float scale ) = 0;

	// Point the model in a given direction, assumes ZXY rotation order
	virtual void SetDirection( float x, float y, float z ) = 0;


	/////////////////////////////
	// Model loading

	// Load the model geometry from a file
	virtual bool Load( const string& fileName ) = 0;


	/////////////////////////////
	// Model texture / material

	// Set material colour and specular power (set 0 power for no specular highlights)
	virtual void SetMaterial( float r, float g, float b, float specularPower = 0.0f ) = 0;

	// Load a single texture for the whole model (ignores textures in model file)
	// Returns true on success
	virtual bool LoadTexture( const string& fileName ) = 0;


	/////////////////////////////
	// Model Usage

	// Render the model
	virtual void Render() = 0;
	
	// Control the model using keys
	virtual void Control( EKeyCode turnUp, EKeyCode turnDown,
				          EKeyCode turnLeft, EKeyCode turnRight,  
				          EKeyCode turnCW, EKeyCode turnCCW,
				          EKeyCode moveForward, EKeyCode moveBackward ) = 0;


	/////////////////////////////
	// No member variables
};
